#!/usr/bin/env python3
"""Audit the V6 release archives and the exact offline HTML delivered to users.

Geometry and actual-browser behavior are verified by separate independent suites;
this audit checks that the same worker/data/renderer and reports were packaged.
"""
from __future__ import annotations

import argparse
import base64
import gzip
import hashlib
from html.parser import HTMLParser
import json
from pathlib import Path, PurePosixPath
import re
import stat
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
DATA_IDS = ('panelData', 'modelData', 'contextData', 'bridgeData', 'workerData')
CONTROLS = ('widthInput', 'widthSlider', 'lengthInput', 'ratioLock', 'ratioInput',
            'applySizeBtn', 'moveUp', 'moveDown', 'moveLeft', 'moveRight',
            'moveCenter', 'moveStep', 'selectionSummary', 'vRect', 'vTrim')


def sha(value):
    return hashlib.sha256(value).hexdigest()


class Document(HTMLParser):
    def __init__(self, text):
        super().__init__(convert_charrefs=False)
        self.elements, self.payloads = {}, {}
        self.active = None
        self.feed(text)
        self.close()

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        identity = attrs.get('id')
        if identity:
            self.elements.setdefault(identity, []).append(attrs)
        if tag == 'script' and identity in DATA_IDS:
            self.active = (identity, [])

    def handle_data(self, text):
        if self.active:
            self.active[1].append(text)

    def handle_endtag(self, tag):
        if tag == 'script' and self.active:
            identity, parts = self.active
            self.payloads.setdefault(identity, []).append(''.join(parts))
            self.active = None


class Audit:
    def __init__(self):
        self.checks = []

    def check(self, name, condition, detail=None):
        result = {'name': name, 'passed': bool(condition)}
        if detail is not None:
            result['detail'] = detail
        self.checks.append(result)
        return bool(condition)

    def guard(self, name, fn):
        try:
            return fn()
        except Exception as exc:
            self.check(name, False, f'{type(exc).__name__}: {exc}')
            return None


def audit_docs(audit, text, label):
    compact = re.sub(r'\s+', '', text).replace(',', '').replace('，', '')
    audit.check(label+': positive independent dimensions',
                any(x in compact for x in ('正数', '正整数', '大于0')) and
                any(x in compact for x in ('长宽', '宽度和长度', '宽度、长度', '宽和长')) and
                any(x in compact for x in ('独立', '自由输入')))
    audit.check(label+': width1500 ceiling removed', bool(re.search(
        r'(?:取消|去掉|移除|不再|没有|不限).{0,50}1500|1500.{0,50}(?:取消|去掉|移除|不再|限制)', compact)))
    audit.check(label+': optional arbitrary ratio explained', '比例' in compact and
                any(x in compact for x in ('自定义', '自定', '自由输入')) and
                any(x in compact for x in ('可选', '默认关闭', '不勾选', '自由模式')))
    audit.check(label+': orange selected and red peers,1mm size groups',
                '橘色' in compact and '红色' in compact and
                any(x in compact for x in ('1mm', '1毫米')) and '同尺寸' in compact)
    audit.check(label+': retains roof and distinguishes surface layout from flat stock',
                any(x in compact for x in ('保留原屋面', '保留屋面', '保留原曲面', '原屋面起伏', '原有起伏')) and
                any(x in compact for x in ('四边', '曲面矩形', '随形矩形')) and
                any(x in compact for x in ('平直', '平面长方形', '下料', '欧氏')) and
                any(x in compact for x in ('边界', '修边', '外轮廓')))
    audit.check(label+': resource limit explained', any(x in compact for x in ('50万', '500000', '板数过多', '资源保护')))


def audit_app(audit, content, label, refs):
    text = content.decode('utf-8')
    doc = Document(text)
    audit.check(label+': complete HTML', '<!doctype html>' in text.lower() and '</html>' in text.lower())
    audit.check(label+': no unresolved development placeholders', '<!-- EMBED_DATA -->' not in text and not re.search(r'/\*\s*RENDERER_V\d+\s*\*/', text))
    audit.check(label+': identical to built app and manifest hash', content == refs['app'] and sha(content) == refs['manifest']['html_sha256'])
    audit.check(label+': no external JS or stylesheet dependencies', not re.search(r'<script\b[^>]*\bsrc\s*=|<link\b[^>]*\bhref\s*=\s*[\"\']https?://', text, re.I))
    audit.check(label+': all controls present once', all(len(doc.elements.get(x, [])) == 1 for x in CONTROLS))
    width = doc.elements.get('widthInput', [{}])[0]
    length = doc.elements.get('lengthInput', [{}])[0]
    slider = doc.elements.get('widthSlider', [{}])[0]
    audit.check(label+': width input has no1500/500 fabrication clamp', width.get('type') == 'number' and width.get('min') == '1' and 'max' not in width and width.get('step') == '1' and width.get('value') == '1000', width)
    audit.check(label+': length independent, no old cap', length.get('type') == 'number' and length.get('min') == '1' and 'max' not in length and length.get('step') == '1' and length.get('value') == '3000', length)
    audit.check(label+': slider is auxiliary and expands to typed width', slider.get('min') == '1' and slider.get('max') != '1500' and 'function syncWidthSlider(w)' in text and 'Math.ceil(w/1000)*2000' in text)
    audit.check(label+': free sizing defaults and optional ratio', 'checked' not in doc.elements.get('ratioLock', [{}])[0] and 'disabled' in doc.elements.get('ratioInput', [{}])[0] and 'ratioLocked:false,ratio:null' in text and 'function parseRatio(' in text)
    audit.check(label+': normalWidth validates positive numerical range, no500/1500 clamp', "function normalWidth(value){let n=Number(value);if(!Number.isFinite(n)||n<=0||n>1e9)" in text and 'Math.max(500,Math.min(1500' not in text)
    audit.check(label+': exact same size group helper and displayed counts', "function panelSizeKey(p){return mm(p.width_m)+' × '+mm(p.length_m)}" in text and 'function selectionStats()' in text and '其他同尺寸' in text and '同尺寸总数（含选中）' in text)
    audit.check(label+': independent size groups and orange/red GPU colors', 'selectedSizeIndex' in text and 'panelSizesA, panelSizesB' in text and 'C = vec3(.91, .16, .14)' in text and 'C = vec3(1., .53, .12)' in text and 'selectedSizeIndex > -.5 ? sameSize : familyMatches' in text)
    audit.check(label+': V6 renderer delivered verbatim', refs['renderer'].decode('utf-8') in text)
    audit.check(label+': independent W/L passed unchanged to worker', 'widthMm:w,lengthMm:l,model:' in text)
    audit.check(label+': exported directional W/L and optional ratio mode', "mode:a.ratioLocked?'ratio':'free'" in text and 'max_width_m:Math.min(w,l),max_length_m:Math.max(w,l)' in text and 'nominal_width_m:w,nominal_length_m:l' in text and 'min_width_mm:1,max_width_mm:1e9' in text)
    audit.check(label+': exported shape and bend metadata', "panel_study_version:'v6-flexible'" in text and 'layout_shape:p.layout_shape,is_surface_rectangle:p.is_surface_rectangle,needs_bend:!!p.needs_bend' in text)
    audit.check(label+': saves V6 and accepts V5 projects', "format:'roof-panel-project-6'" in text and "['roof-panel-project-6','roof-panel-project-5'].includes(p.format)" in text)
    audit.check(label+': five payload elements present exactly once', all(len(doc.payloads.get(x, [])) == 1 for x in DATA_IDS))
    decoded = {}
    for name in DATA_IDS:
        values = doc.payloads.get(name, [])
        if len(values) != 1:
            continue
        raw = audit.guard(label+': decode '+name, lambda: base64.b64decode(re.sub(r'\s+', '', values[0]), validate=True))
        if raw is None:
            continue
        if name in ('panelData', 'modelData', 'contextData'):
            raw = audit.guard(label+': decompress '+name, lambda raw=raw: gzip.decompress(raw))
        if raw is None:
            continue
        audit.check(label+': complete nonempty payload '+name, bool(raw), {'bytes':len(raw), 'sha256':sha(raw)})
        decoded[name] = json.loads(raw) if name in ('panelData', 'modelData') else raw
    study = decoded.get('panelData')
    if isinstance(study, dict):
        selected = next((c for c in study.get('candidates', []) if c.get('id') == study.get('recommended_id')), None)
        audit.check(label+': actual default geometry identical to generated file', study.get('candidates') == refs['default'].get('candidates'))
        audit.check(label+':1000x3000 default, free positive sizing', bool(selected) and selected['nominal_width_m'] == 1 and selected['nominal_length_m'] == 3 and study['sizing_rule']['min_width_mm'] == 1 and study['sizing_rule']['max_width_mm'] == 1000000000 and study['sizing_rule']['mode'] == 'free' and study['sizing_rule']['ratio_locked'] is False)
        audit.check(label+': original roof UV/instances/center unchanged', study['layout']['source_uv'] == refs['uv']['uv'] and study['instances'] == refs['model']['instances'] and study['center'] == refs['model']['center'])
        if selected:
            summary = selected['summary']
            audit.check(label+': default counts sum and center interior allfour-sided', summary['surface_rectangle_panel_count']+summary['boundary_trim_panel_count'] == summary['panel_count'] and summary['center_interior_rectangle_panel_count'] == summary['center_interior_panel_count'] > 0)
            audit.check(label+': balanced per-row rectangles and explicit boundary trims', selected['grid']['layout'] == 'row_balanced_surface_rectangles' and len(selected['grid']['u_cuts_by_row']) > 1 and all(p['layout_shape'] == ('surface_rectangle' if p['is_surface_rectangle'] else 'boundary_trim') for p in selected['panels']))
        audit.check(label+': default regenerated with delivered worker', study['validation_generation']['worker_sha256'] == sha(refs['worker']))
    audit.check(label+': original source mesh/all8transforms identical', decoded.get('modelData') == refs['embedded_model'] and len(refs['embedded_model']['instances']) == 8)
    audit.check(label+': original background unchanged', decoded.get('contextData') == refs['context'])
    audit.check(label+': delivered worker matches source/manifest', decoded.get('workerData') == refs['worker'] and sha(refs['worker']) == refs['manifest']['worker_sha256'])
    worker = decoded.get('workerData', b'').decode('utf-8')
    audit.check(label+': worker independent positive widths and lengths', all(s in worker for s in ('Number.isInteger(data.widthMm)', 'data.widthMm < 1', 'data.widthMm > 1e9', 'Number.isInteger(data.lengthMm)', 'data.lengthMm < 1', '.solve(data.widthMm, data.lengthMm)')) and 'data.widthMm < 500' not in worker and 'data.widthMm > 1500' not in worker)
    audit.check(label+': worker resource guard retained', 'MAX_WORLD_PANELS = 500000' in worker)
    audit.check(label+': embedded Ruby identical and V6 layer', decoded.get('bridgeData') == refs['bridge'] and 'RP_V6自由尺寸铝板_中心矩形'.encode() in refs['bridge'])
    ruby = refs['bridge'].decode('utf-8')
    audit.check(label+': Ruby V6 dimensions and legacy mode recognized', "if v6 || v5" in ruby and 'width>=1.0 && width<=1.0e9' in ruby and 'length>=1.0 && length<=1.0e9' in ruby and "mode==(locked ? 'ratio' : 'free')" in ruby and "v4=data['panel_study_version']" in ruby)


def safe_member(info):
    name = info.filename
    p = PurePosixPath(name)
    return bool(name) and not p.is_absolute() and '..' not in p.parts and '\\' not in name and not re.match(r'^[A-Za-z]:', name) and not stat.S_ISLNK(info.external_attr >> 16)


def audit_zip(audit, path, refs):
    label = path.name
    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        audit.check(label+': safe relative paths and no symlinks', all(safe_member(i) for i in z.infolist()))
        audit.check(label+': no duplicate entries and valid ZIP CRC', len(names) == len(set(names)) and z.testzip() is None)
        htmls = [x for x in names if x.lower().endswith('.html')]
        audit.check(label+': exactly one runnable root app.html', htmls == ['app.html'], htmls)
        if 'app.html' in names:
            audit_app(audit, z.read('app.html'), label, refs)
        docs = [x for x in names if PurePosixPath(x).name in ('使用说明.md', '打开说明.txt')]
        audit.check(label+': user guides included', bool(docs))
        audit_docs(audit, '\n'.join(z.read(x).decode('utf-8-sig') for x in docs), label+' docs')
        for name in names:
            base = PurePosixPath(name).name
            if base in ('panel-worker.js','renderer-v6.js','sketchup_bridge.rb','modelData.json','source_uv_complete.json','context_lite.bin.gz','default-study.json','build_manifest.json','dynamic_geometry_validation.json','browser_validation.json','bridge_numeric_validation.json'):
                audit.check(label+': packaged source/report identity '+base, z.read(name) == (ROOT/base).read_bytes())
        if path.name.endswith('_full.zip'):
            audit.check(label+': development template is non-runnable text', '技术复算/app.template.html.txt' in names)
            samples = [x for x in names if PurePosixPath(x).name == '1102e_V6自由尺寸分隔.json']
            audit.check(label+': browser exported2500x6000 example included', len(samples) == 1)
            if samples:
                raw = z.read(samples[0]); sample = json.loads(raw); rule = sample['sizing_rule']; ps = sample['panels']
                audit.check(label+': sample identical to actual export', raw == (ROOT/'1102e_V6自由尺寸分隔.json').read_bytes())
                audit.check(label+': sample is V6 free2500x6000 with no1500 fabrication cap', sample.get('panel_study_version') == 'v6-flexible' and sample['nominal_width_m'] == 2.5 and sample['nominal_length_m'] == 6 and sample['max_width_m'] == 2.5 and sample['max_length_m'] == 6 and rule['min_width_mm'] == 1 and rule['max_width_mm'] == 1e9 and rule['mode'] == 'free' and rule['ratio'] is None)
                audit.check(label+': sample has4456pieces with realwidth above1500', len(ps) == 4456 and any(p['width_m'] > 1.5 for p in ps))
                audit.check(label+': sample rectangle/boundary/bend metadata retained', all(p['layout_shape'] in ('surface_rectangle','boundary_trim') and p['is_surface_rectangle'] == (p['layout_shape'] == 'surface_rectangle') and isinstance(p['needs_bend'], bool) for p in ps))
    return {'file':path.name, 'bytes':path.stat().st_size, 'sha256':sha(path.read_bytes()), 'entries':len(names)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--app-only', action='store_true')
    parser.add_argument('--output', type=Path, default=ROOT/'delivery_validation_v6.json')
    args = parser.parse_args()
    audit = Audit()
    refs = {name:(ROOT/file).read_bytes() for name,file in (('app','app.html'),('worker','panel-worker.js'),('renderer','renderer-v6.js'),('bridge','sketchup_bridge.rb'))}
    refs.update({name:json.loads((ROOT/file).read_text()) for name,file in (('manifest','build_manifest.json'),('model','modelData.json'),('uv','source_uv_complete.json'),('default','default-study.json'))})
    refs['context'] = gzip.decompress((ROOT/'context_lite.bin.gz').read_bytes())
    refs['embedded_model'] = dict(refs['model'], variants={'0':refs['model']['variants']['0']})
    for file in ('modelData.json','source_uv_complete.json','context_lite.bin.gz'):
        audit.check('source unchanged from V5: '+file, (ROOT/file).read_bytes() == (ROOT.parent/'roof-panel-studio-v5'/file).read_bytes())
    for file in ('roof_panels_flexible_v6.html','1102e_V6可调尺寸工作台.html'):
        audit.check('built standalone alias identity: '+file, (ROOT/file).read_bytes() == refs['app'])
    audit.guard('built app audit', lambda:audit_app(audit, refs['app'], 'builtapp', refs))
    archives = []
    if not args.app_only:
        reports = {name:json.loads((ROOT/file).read_text()) for name,file in (('geometry','dynamic_geometry_validation.json'),('browser','browser_validation.json'),('bridge','bridge_numeric_validation.json'),('selection','v6_selection_validation.json'),('guards','resource_guard_validation.json'))}
        audit.check('independent geometry suite passed', reports['geometry'].get('all_passed') is True)
        audit.check('geometry report finalworker identity', reports['geometry'].get('worker_sha256') == sha(refs['worker']))
        audit.check('actual browser suite passed with no external requests/errors', reports['browser'].get('passed',0) > 0 and not reports['browser'].get('errors') and not reports['browser'].get('external_requests'))
        audit.check('actual browser report finalworker/HTML identity', reports['browser'].get('worker_sha256') == sha(refs['worker']) and reports['browser'].get('html_sha256') == sha(refs['app']))
        audit.check('actual exported bridge numeric checks passed', reports['bridge'].get('all_passed') is True and reports['bridge'].get('export_sha256') == sha((ROOT/'1102e_V6自由尺寸分隔.json').read_bytes()))
        audit.check('bridge report finalRuby identity', reports['bridge'].get('bridge_sha256') == sha(refs['bridge']))
        audit.check('renderer size mapping suite passed', reports['selection'].get('passed') is True)
        audit.check('resource guards passed with finalworker', reports['guards'].get('passed') is True and reports['guards'].get('worker_sha256') == sha(refs['worker']))
        release = ROOT/'releases'
        audit.guard('released single HTML audit', lambda:audit_app(audit, (release/'roof_panels_flexible_v6.html').read_bytes(), 'releasedstandalone', refs))
        checksums = json.loads((release/'checksums.json').read_text())
        names = [i['file'] for i in checksums]
        audit.check('release manifest unique complete filenames', len(names) == len(set(names)) and set(names) == {p.name for p in release.iterdir() if p.is_file() and p.name != 'checksums.json'})
        for item in checksums:
            name = item['file']; safe = PurePosixPath(name).name == name and '\\' not in name
            audit.check('release manifest safe filename '+name, safe)
            if safe:
                content = (release/name).read_bytes()
                audit.check('release manifest SHA/size '+name, len(content) == item['bytes'] and sha(content) == item['sha256'])
        for path in (release/'roof_panels_flexible_v6_web.zip', release/'roof_panels_flexible_v6_full.zip'):
            result = audit.guard('archive '+path.name, lambda path=path:audit_zip(audit,path,refs))
            if result:
                archives.append(result)
    report = {'format':'roof-panel-v6-delivery-validation-1','all_passed':bool(audit.checks) and all(x['passed'] for x in audit.checks), 'app_only':args.app_only,'worker_sha256':sha(refs['worker']),'html_sha256':sha(refs['app']),'archives':archives,'checks':audit.checks}
    args.output.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    failed = [x for x in audit.checks if not x['passed']]
    print(json.dumps({'all_passed':report['all_passed'],'checks':len(audit.checks),'failed':failed,'report':str(args.output)},ensure_ascii=False))
    return 0 if report['all_passed'] else 1


if __name__ == '__main__':
    sys.exit(main())
