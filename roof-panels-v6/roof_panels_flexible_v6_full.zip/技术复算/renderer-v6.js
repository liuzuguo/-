/* V6 roof renderer: keep one template mesh on the GPU and reuse it for all roofs.
 * Geometry is rebuilt only when the candidate changes; view and filter changes
 * are uniforms, including picking IDs for the individual model instances. */
class Renderer {
  constructor() {
    const canvas = $('model');
    const gl = this.gl = canvas.getContext('webgl', {
      antialias: true, preserveDrawingBuffer: true, alpha: false
    });
    if (!gl) throw Error('当前浏览器未启用 WebGL，请使用 Chrome 或 Edge 打开。');
    const vertex = `
      precision highp float;
      attribute vec3 position, normal, contextColor;
      attribute vec4 panelData;
      attribute vec2 panelColors;
      attribute vec4 panelSizesA, panelSizesB;
      uniform mat4 mvp, model;
      uniform mat3 normalMatrix;
      uniform vec3 palette[12], roofColor;
      uniform float background, mode, colorMode, mirrored, instanceBase;
      uniform float selectedIndex, selectedSizeIndex, instanceIndex, filterFamily, filterMirrorMask, isolate;
      varying vec3 N, C, P;
      vec3 paletteColor(float i) {
        if (i < .5) return palette[0];
        if (i < 1.5) return palette[1];
        if (i < 2.5) return palette[2];
        if (i < 3.5) return palette[3];
        if (i < 4.5) return palette[4];
        if (i < 5.5) return palette[5];
        if (i < 6.5) return palette[6];
        if (i < 7.5) return palette[7];
        if (i < 8.5) return palette[8];
        if (i < 9.5) return palette[9];
        if (i < 10.5) return palette[10];
        return palette[11];
      }
      void main() {
        if (background > .5) {
          N = normal;
          C = contextColor * .55 + .32;
          P = vec3(0.);
          gl_Position = mvp * vec4(position, 1.);
          return;
        }
        float panelIndex = instanceBase + panelData.x;
        float id = panelIndex + 1.;
        P = vec3(mod(id, 256.), mod(floor(id / 256.), 256.), floor(id / 65536.)) / 255.;
        N = normalMatrix * normal;
        if (N.z < 0.) N = -N;
        bool mirrorMatch = filterMirrorMask > 2.5 ||
          (mirrored < .5 && mod(filterMirrorMask, 2.) > .5) ||
          (mirrored > .5 && filterMirrorMask > 1.5);
        float sizeIndex;
        if (instanceIndex < .5) sizeIndex = panelSizesA.x;
        else if (instanceIndex < 1.5) sizeIndex = panelSizesA.y;
        else if (instanceIndex < 2.5) sizeIndex = panelSizesA.z;
        else if (instanceIndex < 3.5) sizeIndex = panelSizesA.w;
        else if (instanceIndex < 4.5) sizeIndex = panelSizesB.x;
        else if (instanceIndex < 5.5) sizeIndex = panelSizesB.y;
        else if (instanceIndex < 6.5) sizeIndex = panelSizesB.z;
        else sizeIndex = panelSizesB.w;
        bool sameSize = selectedSizeIndex > -.5 && abs(sizeIndex - selectedSizeIndex) < .5;
        bool familyMatches = filterFamily < -.5 ||
          (abs(panelData.y - filterFamily) < .5 && mirrorMatch);
        // Selecting any plate uses its dimension group, across geometry types and
        // handedness. Isolation follows that group as well.
        bool matches = selectedSizeIndex > -.5 ? sameSize : familyMatches;
        C = vec3(.84, .85, .82);
        if (colorMode > .5 && colorMode < 1.5)
          C = paletteColor(mix(panelColors.x, panelColors.y, mirrored));
        else if (colorMode > 1.5 && colorMode < 2.5) C = roofColor;
        else if (colorMode > 2.5 && colorMode < 3.5)
          C = panelData.z > .5 ? vec3(.76, .58, .38) : vec3(.51, .68, .56);
        else if (colorMode > 3.5)
          C = panelData.w > .5 ? vec3(.87, .34, .16) : vec3(.68, .76, .67);
        if (!matches) C = vec3(.79, .82, .75);
        if (sameSize) C = vec3(.91, .16, .14);
        if (abs(panelIndex - selectedIndex) < .5) C = vec3(1., .53, .12);
        if (mode > .5 && mode < 1.5) C = vec3(.20, .24, .21);
        gl_Position = mvp * model * vec4(position, 1.);
        if (isolate > .5 && !matches) gl_Position = vec4(2., 2., 2., 1.);
      }`;
    const precision = gl.getShaderPrecisionFormat(gl.FRAGMENT_SHADER, gl.HIGH_FLOAT);
    const fragment = `
      precision ${precision && precision.precision ? 'highp' : 'mediump'} float;
      varying vec3 N, C, P;
      uniform float mode, lineOpacity;
      void main() {
        if (mode > 1.5) { gl_FragColor = vec4(P, 1.); return; }
        if (mode > .5) { gl_FragColor = vec4(C, lineOpacity); return; }
        float light = .64 + .36 * abs(dot(normalize(N), normalize(vec3(-.35, -.65, 1.))));
        gl_FragColor = vec4(C * light, 1.);
      }`;
    const program = this.program = gl.createProgram();
    for (const [kind, source] of [[gl.VERTEX_SHADER, vertex], [gl.FRAGMENT_SHADER, fragment]]) {
      const shader = gl.createShader(kind);
      gl.shaderSource(shader, source);
      gl.compileShader(shader);
      if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
        const reason = gl.getShaderInfoLog(shader);
        gl.deleteShader(shader);
        throw Error('三维着色器编译失败：' + reason);
      }
      gl.attachShader(program, shader);
      gl.deleteShader(shader);
    }
    gl.linkProgram(program);
    if (!gl.getProgramParameter(program, gl.LINK_STATUS))
      throw Error('三维渲染初始化失败：' + gl.getProgramInfoLog(program));
    this.attrs = {};
    for (const name of ['position', 'normal', 'panelData', 'panelColors', 'panelSizesA', 'panelSizesB', 'contextColor'])
      this.attrs[name] = gl.getAttribLocation(program, name);
    this.uniforms = {};
    for (const name of ['mvp', 'model', 'normalMatrix', 'palette[0]', 'roofColor',
      'background', 'mode', 'lineOpacity', 'colorMode', 'mirrored', 'instanceBase', 'selectedIndex',
      'selectedSizeIndex', 'instanceIndex', 'filterFamily', 'filterMirrorMask', 'isolate'])
      this.uniforms[name] = gl.getUniformLocation(program, name);
    gl.enable(gl.DEPTH_TEST);
    gl.disable(gl.BLEND);
    this.context = this.buf(ctxData, 9);
    this.rebuild();
    if (typeof ResizeObserver !== 'undefined') {
      this.resizeObserver = new ResizeObserver(() => { dirty = true; });
      this.resizeObserver.observe(canvas);
    }
    canvas.addEventListener('webglcontextlost', event => {
      event.preventDefault();
      this.contextLost = true;
    });
    canvas.addEventListener('webglcontextrestored', () => {
      // Reloading an entirely offline page also restores all embedded model data.
      if (typeof toast === 'function') toast('三维显卡上下文已恢复，请刷新页面重新载入模型。');
    });
    this.loop();
  }

  buf(array, stride = 20) {
    const gl = this.gl, buffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
    gl.bufferData(gl.ARRAY_BUFFER, array, gl.STATIC_DRAW);
    return { buffer, count: array.length / stride, bytes: array.byteLength, stride };
  }

  dispose(mesh) { if (mesh) this.gl.deleteBuffer(mesh.buffer); }

  normalTransform(m) {
    const a = m[0], b = m[1], c = m[2], d = m[4], e = m[5], f = m[6],
      g = m[8], h = m[9], i = m[10];
    const determinant = a * (e * i - f * h) - d * (b * i - c * h) + g * (b * f - c * e);
    const scale = Math.abs(determinant) > 1e-15 ? 1 / determinant : 1;
    return new Float32Array([
      (e * i - f * h) * scale, (f * g - d * i) * scale, (d * h - e * g) * scale,
      (h * c - b * i) * scale, (a * i - c * g) * scale, (b * g - a * h) * scale,
      (b * f - c * e) * scale, (c * d - a * f) * scale, (a * e - b * d) * scale
    ]);
  }

  sizeKey(panel) {
    // Keep this identical to the statistics table: dimensions rounded upward to
    // one millimetre, not the selected geometry type or nominal input size.
    return typeof panelSizeKey === 'function' ? panelSizeKey(panel) :
      `${mm(panel.width_m)} × ${mm(panel.length_m)}`;
  }

  selectionState() {
    const key = selected ? this.sizeKey(selected) : null;
    const group = key === null ? null : this.sizeGroups?.get(key);
    const scope = $('roof').value;
    const count = group ? (scope === 'all' ? group.count : group.roofs[scope] || 0) : 0;
    const includesSelected = !!selected && (scope === 'all' || selected.roof_id === scope);
    return { key, group: group ? group.index : -1, count,
      others: Math.max(0, count - (includesSelected ? 1 : 0)), selectedIndex: selected ? selected.index : -1 };
  }

  getHighlightState() {
    const state = this.selectionState(), matchingIndices = [], redIndices = [];
    const scope = $('roof').value;
    if (state.group >= 0) for (const panel of world) {
      if (scope !== 'all' && panel.roof_id !== scope) continue;
      // Read the actual ID columns used by the GPU, not a parallel size test.
      if (this.sizeGroupIds[panel.instance][panel.template] !== state.group) continue;
      matchingIndices.push(panel.index);
      if (panel.index !== state.selectedIndex) redIndices.push(panel.index);
    }
    return {selectedIndex: state.selectedIndex, sizeKey: state.key,
      group: state.group, count: matchingIndices.length, matchingIndices, redIndices};
  }

  rebuild() {
    if (!candidate || !candidate.panels || !world.length) return;
    if (this.sourceCandidate === candidate && this.sourcePanels === candidate.panels) {
      dirty = true;
      return;
    }
    const panels = candidate.panels, panelCount = panels.length;
    const families = this.families = new Map();
    for (const panel of panels)
      if (!families.has(String(panel.type_id))) families.set(String(panel.type_id), families.size);
    const typeMatches = this.typeMatches = new Map();
    const sizeGroups = this.sizeGroups = new Map();
    // Eight small per-template ID columns support different actual instance
    // dimensions without duplicating the triangle positions or normals.
    const sizeGroupIds = this.sizeGroupIds = Array.from({length: 8},
      () => new Float32Array(panelCount).fill(-1));
    const paletteIndices = [new Float32Array(panelCount), new Float32Array(panelCount)];
    const colorSeen = [new Uint8Array(panelCount), new Uint8Array(panelCount)];
    const instances = this.instances = original.instances.map((instance, index) => {
      const model = new Float32Array(instance.matrix);
      model[12] -= original.center[0];
      model[13] -= original.center[1];
      model[14] -= original.center[2] || 0;
      return { model, normal: this.normalTransform(instance.matrix), mirrored: det(instance.matrix) < 0 ? 1 : 0,
        base: index * panelCount, index, roof: 'ABCD'[Math.floor(index / 2)], roofIndex: Math.floor(index / 2) };
    });
    for (const panel of world) {
      const sizeKey = this.sizeKey(panel);
      let sizeGroup = sizeGroups.get(sizeKey);
      if (!sizeGroup) {
        sizeGroup = {index: sizeGroups.size, count: 0, roofs: {A:0, B:0, C:0, D:0}};
        sizeGroups.set(sizeKey, sizeGroup);
      }
      sizeGroup.count++;
      sizeGroup.roofs[panel.roof_id] = (sizeGroup.roofs[panel.roof_id] || 0) + 1;
      sizeGroupIds[panel.instance][panel.template] = sizeGroup.index;
      const mirror = instances[panel.instance].mirrored, ti = panel.template;
      if (!colorSeen[mirror][ti]) {
        paletteIndices[mirror][ti] = panel.colorIndex || 0;
        colorSeen[mirror][ti] = 1;
      }
      let match = typeMatches.get(panel.type_id);
      if (!match) {
        match = { family: families.get(String(panels[ti].type_id)), mask: 0 };
        typeMatches.set(panel.type_id, match);
      }
      match.mask |= 1 << mirror;
    }
    // Both palette variants remain valid for models with only one handedness.
    for (let i = 0; i < panelCount; i++) {
      if (!colorSeen[0][i]) paletteIndices[0][i] = paletteIndices[1][i];
      if (!colorSeen[1][i]) paletteIndices[1][i] = paletteIndices[0][i];
    }
    let triangleVertices = 0, lineVertices = 0;
    const fallbackEdges = new Map();
    for (let pi = 0; pi < panelCount; pi++) {
      const panel = panels[pi];
      triangleVertices += panel.faces.length * 3;
      if (panel.outlines) {
        for (const ring of panel.outlines) lineVertices += ring.length * 2;
      } else {
        const edges = new Map();
        for (const face of panel.faces) for (let k = 0; k < 3; k++) {
          const a = face[k], b = face[(k + 1) % 3], key = a < b ? a + ',' + b : b + ',' + a;
          const edge = edges.get(key);
          if (edge) edge.count++; else edges.set(key, { a, b, count: 1 });
        }
        const boundary = [];
        for (const edge of edges.values()) if (edge.count === 1) boundary.push(edge);
        fallbackEdges.set(pi, boundary);
        lineVertices += boundary.length * 2;
      }
    }
    const triangles = new Float32Array(triangleVertices * 20);
    const lines = new Float32Array(lineVertices * 20);
    let triangleOffset = 0, lineOffset = 0;
    const write = (target, offset, vertex, nx, ny, nz, pi, family, curve, small) => {
      target[offset] = vertex[0]; target[offset + 1] = vertex[1]; target[offset + 2] = vertex[2];
      target[offset + 3] = nx; target[offset + 4] = ny; target[offset + 5] = nz;
      target[offset + 6] = pi; target[offset + 7] = family;
      target[offset + 8] = curve; target[offset + 9] = small;
      target[offset + 10] = paletteIndices[0][pi]; target[offset + 11] = paletteIndices[1][pi];
      for (let instance = 0; instance < 8; instance++)
        target[offset + 12 + instance] = sizeGroupIds[instance][pi];
      return offset + 20;
    };
    for (let pi = 0; pi < panelCount; pi++) {
      const panel = panels[pi], vertices = panel.vertices;
      const family = families.get(String(panel.type_id)), curve = curved(panel) ? 1 : 0,
        small = panel.area_m2 < .05 ? 1 : 0;
      for (const face of panel.faces) {
        const a = vertices[face[0]], b = vertices[face[1]], c = vertices[face[2]];
        const ux = b[0] - a[0], uy = b[1] - a[1], uz = b[2] - a[2],
          vx = c[0] - a[0], vy = c[1] - a[1], vz = c[2] - a[2];
        let nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
        const length = Math.hypot(nx, ny, nz) || 1;
        nx /= length; ny /= length; nz /= length;
        triangleOffset = write(triangles, triangleOffset, a, nx, ny, nz, pi, family, curve, small);
        triangleOffset = write(triangles, triangleOffset, b, nx, ny, nz, pi, family, curve, small);
        triangleOffset = write(triangles, triangleOffset, c, nx, ny, nz, pi, family, curve, small);
      }
      if (panel.outlines) {
        for (const ring of panel.outlines) for (let j = 0; j < ring.length; j++) {
          lineOffset = write(lines, lineOffset, ring[j], 0, 0, 1, pi, family, curve, small);
          lineOffset = write(lines, lineOffset, ring[(j + 1) % ring.length], 0, 0, 1, pi, family, curve, small);
        }
      } else {
        for (const edge of fallbackEdges.get(pi)) {
          lineOffset = write(lines, lineOffset, vertices[edge.a], 0, 0, 1, pi, family, curve, small);
          lineOffset = write(lines, lineOffset, vertices[edge.b], 0, 0, 1, pi, family, curve, small);
        }
      }
    }
    // Upload before releasing the old mesh, so failed allocations keep a usable view.
    const roof = this.buf(triangles), seams = this.buf(lines);
    this.dispose(this.roof); this.dispose(this.lines);
    this.roof = roof; this.lines = seams;
    this.sourceCandidate = candidate; this.sourcePanels = panels;
    this.geometryBytes = roof.bytes + seams.bytes;
    dirty = true;
  }

  setData() { this.sourceCandidate = null; this.rebuild(); }

  attributes(mesh, background) {
    const gl = this.gl, a = this.attrs;
    gl.bindBuffer(gl.ARRAY_BUFFER, mesh.buffer);
    gl.enableVertexAttribArray(a.position);
    gl.enableVertexAttribArray(a.normal);
    gl.vertexAttribPointer(a.position, 3, gl.FLOAT, false, background ? 36 : 80, 0);
    gl.vertexAttribPointer(a.normal, 3, gl.FLOAT, false, background ? 36 : 80, 12);
    if (background) {
      gl.disableVertexAttribArray(a.panelData); gl.vertexAttrib4f(a.panelData, 0, 0, 0, 0);
      gl.disableVertexAttribArray(a.panelColors); gl.vertexAttrib2f(a.panelColors, 0, 0);
      gl.disableVertexAttribArray(a.panelSizesA); gl.vertexAttrib4f(a.panelSizesA, -1, -1, -1, -1);
      gl.disableVertexAttribArray(a.panelSizesB); gl.vertexAttrib4f(a.panelSizesB, -1, -1, -1, -1);
      gl.enableVertexAttribArray(a.contextColor);
      gl.vertexAttribPointer(a.contextColor, 3, gl.FLOAT, false, 36, 24);
    } else {
      gl.enableVertexAttribArray(a.panelData);
      gl.vertexAttribPointer(a.panelData, 4, gl.FLOAT, false, 80, 24);
      gl.enableVertexAttribArray(a.panelColors);
      gl.vertexAttribPointer(a.panelColors, 2, gl.FLOAT, false, 80, 40);
      gl.enableVertexAttribArray(a.panelSizesA);
      gl.vertexAttribPointer(a.panelSizesA, 4, gl.FLOAT, false, 80, 48);
      gl.enableVertexAttribArray(a.panelSizesB);
      gl.vertexAttribPointer(a.panelSizesB, 4, gl.FLOAT, false, 80, 64);
      gl.disableVertexAttribArray(a.contextColor); gl.vertexAttrib3f(a.contextColor, 0, 0, 0);
    }
  }

  pickTarget(width, height) {
    const gl = this.gl;
    if (this.pickBuffer && this.pickWidth === width && this.pickHeight === height) return;
    if (this.pickBuffer) {
      gl.deleteFramebuffer(this.pickBuffer);
      gl.deleteTexture(this.pickTexture);
      gl.deleteRenderbuffer(this.pickDepth);
    }
    this.pickBuffer = gl.createFramebuffer(); this.pickTexture = gl.createTexture();
    this.pickDepth = gl.createRenderbuffer(); this.pickWidth = width; this.pickHeight = height;
    gl.bindTexture(gl.TEXTURE_2D, this.pickTexture);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, width, height, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
    gl.bindRenderbuffer(gl.RENDERBUFFER, this.pickDepth);
    gl.renderbufferStorage(gl.RENDERBUFFER, gl.DEPTH_COMPONENT16, width, height);
    gl.bindFramebuffer(gl.FRAMEBUFFER, this.pickBuffer);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, this.pickTexture, 0);
    gl.framebufferRenderbuffer(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.RENDERBUFFER, this.pickDepth);
    if (gl.checkFramebufferStatus(gl.FRAMEBUFFER) !== gl.FRAMEBUFFER_COMPLETE)
      throw Error('三维点选缓冲区创建失败，请缩小窗口或刷新页面。');
  }

  drawInstances(mesh, primitive, mode) {
    if (!mesh || !mesh.count) return;
    const gl = this.gl, u = this.uniforms, scope = $('roof').value;
    this.attributes(mesh, false);
    gl.uniform1f(u.background, 0); gl.uniform1f(u.mode, mode);
    for (const instance of this.instances) {
      if (scope !== 'all' && scope !== instance.roof) continue;
      gl.uniformMatrix4fv(u.model, false, instance.model);
      gl.uniformMatrix3fv(u.normalMatrix, false, instance.normal);
      gl.uniform1f(u.mirrored, instance.mirrored);
      gl.uniform1f(u.instanceBase, instance.base);
      gl.uniform1f(u.instanceIndex, instance.index);
      gl.uniform3fv(u.roofColor, this.palette.subarray(instance.roofIndex * 3, instance.roofIndex * 3 + 3));
      gl.drawArrays(primitive, 0, mesh.count);
    }
  }

  render(picking = false) {
    if (this.contextLost || !this.roof) return;
    const gl = this.gl, canvas = $('model'), bounds = canvas.getBoundingClientRect();
    const scale = Math.min(typeof devicePixelRatio === 'number' ? devicePixelRatio : 1, 1.5);
    const width = Math.max(1, Math.round(bounds.width * scale)),
      height = Math.max(1, Math.round(bounds.height * scale));
    if (canvas.width !== width || canvas.height !== height) { canvas.width = width; canvas.height = height; }
    if (picking) { this.pickTarget(width, height); gl.bindFramebuffer(gl.FRAMEBUFFER, this.pickBuffer); }
    else gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    gl.viewport(0, 0, width, height);
    if (picking) gl.clearColor(0, 0, 0, 1); else gl.clearColor(.914, .929, .89, 1);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    gl.useProgram(this.program);
    gl.disable(gl.BLEND);
    const u = this.uniforms;
    gl.uniformMatrix4fv(u.mvp, false, matrix(width / height));
    if (!this.palette) {
      this.palette = new Float32Array(36);
      for (let i = 0; i < 12; i++) this.palette.set(rgb(colors[i % colors.length]), i * 3);
    }
    gl.uniform3fv(u['palette[0]'], this.palette);
    const modes = { neutral: 0, type: 1, roof: 2, curve: 3, small: 4 };
    gl.uniform1f(u.colorMode, modes[$('colorMode').value] || 0);
    gl.uniform1f(u.selectedIndex, selected ? selected.index : -1);
    const selection = this.selectionState();
    gl.uniform1f(u.selectedSizeIndex, selection.group);
    const filter = typeFilter && this.typeMatches.get(typeFilter);
    gl.uniform1f(u.filterFamily, filter ? filter.family : -1);
    gl.uniform1f(u.filterMirrorMask, filter ? filter.mask : 3);
    gl.uniform1f(u.isolate, $('isolate').checked && (selection.group >= 0 || filter) ? 1 : 0);
    if (picking) {
      gl.disable(gl.DITHER);
      this.drawInstances(this.roof, gl.TRIANGLES, 2);
      gl.enable(gl.DITHER);
      return;
    }
    if ($('context').checked && this.context.count) {
      this.attributes(this.context, true);
      gl.uniform1f(u.background, 1); gl.uniform1f(u.mode, 0);
      gl.drawArrays(gl.TRIANGLES, 0, this.context.count);
    }
    gl.enable(gl.POLYGON_OFFSET_FILL); gl.polygonOffset(1, 1);
    this.drawInstances(this.roof, gl.TRIANGLES, 0);
    gl.disable(gl.POLYGON_OFFSET_FILL);
    if ($('seams').checked) {
      // At overview scale many real joints fall within the same screen pixel.
      // Fade their ink rather than changing or omitting any geometric joints.
      // The projected module grows when zooming in, restoring clear dark seams.
      const nominalWidth = Math.min(Number(candidate.nominal_width_m)||1,Number(candidate.nominal_length_m)||1);
      const projectedWidth = nominalWidth * height / (2 * Math.tan(Math.PI / 8) * Math.max(1, camera.r));
      const scopeBoost = $('roof').value === 'all' ? 0 : .05;
      this.lineOpacity = Math.max(.11, Math.min(.72, projectedWidth * .065 + scopeBoost));
      gl.uniform1f(u.lineOpacity, this.lineOpacity);
      gl.enable(gl.BLEND);
      gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
      gl.depthMask(false);
      this.drawInstances(this.lines, gl.LINES, 1);
      gl.depthMask(true);
      gl.disable(gl.BLEND);
    }
  }

  pick(x, y) {
    const gl = this.gl, canvas = $('model'), bounds = canvas.getBoundingClientRect();
    if (!bounds.width || !bounds.height || this.contextLost) return -1;
    this.render(true);
    const pixel = new Uint8Array(4), px = Math.min(canvas.width - 1, Math.max(0,
      Math.floor((x - bounds.left) / bounds.width * canvas.width))),
      py = Math.min(canvas.height - 1, Math.max(0,
        Math.floor((bounds.bottom - y) / bounds.height * canvas.height)));
    gl.readPixels(px, py, 1, 1, gl.RGBA, gl.UNSIGNED_BYTE, pixel);
    const index = pixel[0] + pixel[1] * 256 + pixel[2] * 65536 - 1;
    if (index >= 0 && index < world.length) {
      selected = world[index]; typeFilter = selected.type_id;
      renderDetail(); renderTable(); this.rebuild();
    }
    dirty = true; this.render();
    return index;
  }

  loop() {
    this.frame = requestAnimationFrame(() => this.loop());
    if (dirty && !this.contextLost) { dirty = false; this.render(); }
  }
}
