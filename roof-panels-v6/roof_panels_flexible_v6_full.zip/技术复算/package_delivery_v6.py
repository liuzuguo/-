"""Package the tested V6 system; no unpopulated HTML templates are runnable."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib
import json
import shutil

ROOT = Path(__file__).resolve().parent
OUT = ROOT/'releases'


def package():
    geometry = json.loads((ROOT/'dynamic_geometry_validation.json').read_text())
    browser = json.loads((ROOT/'browser_validation.json').read_text())
    bridge = json.loads((ROOT/'bridge_numeric_validation.json').read_text())
    build = json.loads((ROOT/'build_manifest.json').read_text())
    assert geometry['all_passed'] and bridge['all_passed'] and not browser['errors']
    worker_hash = hashlib.sha256((ROOT/'panel-worker.js').read_bytes()).hexdigest()
    assert geometry['worker_sha256'] == build['worker_sha256'] == worker_hash
    assert build['html_sha256'] == hashlib.sha256((ROOT/'app.html').read_bytes()).hexdigest()
    assert browser['worker_sha256'] == worker_hash
    assert browser['html_sha256'] == build['html_sha256']
    assert bridge['worker_sha256'] == worker_hash
    assert bridge['export_sha256'] == hashlib.sha256((ROOT/'1102e_V6自由尺寸分隔.json').read_bytes()).hexdigest()
    default = json.loads((ROOT/'default-study.json').read_text())['candidates'][0]
    count = default['summary']['panel_count']
    rectangles = default['summary']['surface_rectangle_panel_count']
    trims = default['summary']['boundary_trim_panel_count']
    OUT.mkdir(exist_ok=True)
    guide = f'''# 1102e 屋面铝板 V6 · 自由尺寸、同尺寸联选、中心四边分格

解压后用新版 Edge 或 Chrome 打开根目录 **app.html**。屋面、建筑背景、计算程序和 SketchUp 导入脚本全部内嵌，下载后可离线使用。单独 HTML 与 ZIP 中的 app.html 完全一致。

## 尺寸调节

宽度已取消原 500–1500 mm 范围，长、宽均可分别输入正数，按 1 mm 取整。支持 2500×6000、5000×3000、400×6000 等尺寸。滑块范围随输入自动扩展，输入框不会回退到 1500 mm。

默认不锁比例。需要联动时勾选“锁定长宽比”，输入 `2.5`、`5:2`、`4:5` 等正比例，表示长度÷宽度；改宽带动长，改长带动宽。取消勾选恢复独立输入。点击“应用尺寸”后真实重算屋面分格、统计及导出。

数值保护范围为 1–1,000,000,000 mm，不是加工规格限制。预计超过 500,000 块的极小尺寸会提示调整，保留上一次成功模型。

## 点选与同尺寸数量

- 单击三维板件或统计表中的一行：选中板为**橘色**，当前屋顶范围内其余同尺寸板为**红色**。
- 同尺寸按“实际短边上界×实际长边上界，上取整到 1 mm”的尺寸组匹配，包含不同形状和左右镜像板；不是只查同一板型，也不是所有输入了相同设定值的板。
- 模型角标和右侧详情同时显示：同尺寸总数（含选中）、红色其他板数。详情另列全部屋顶同尺寸总数。
- 切换“全部屋顶 A–D”或某一屋顶，显示位置及数量随范围更新。“仅显示选中同尺寸板”隔离该尺寸组，“取消选中及高亮”恢复查看。

相同尺寸组不等于可以使用同一加工模具；几何板型统计仍单独保留。

## 向中心的分格

采用保留原屋面起伏的**连续四边随形长方格**。沿放射方向分条，横带分别调整条数，向收拢端减少窄条；横带之间允许 T 形错缝。原模型内部三角面和斜折线保留在一块曲面/折弯板内部，不再把中心内部切成三角碎板。

这是四边的曲面分格，并非每块都是平直欧氏长方形。原屋面双曲起伏和折弯形状保持不变。为完整保留原外轮廓，外沿和角部仍保留明确标注的修边板；不会将修边异形板冒充长方形板。

默认 1000×3000 mm：全屋面 {count:,} 块，其中四边随形分格 {rectangles:,} 块、外轮廓修边 {trims:,} 块。中心内部所有板均为完整四边格。界面和逐板 CSV、JSON 均区分“四边随形长方格”和“外轮廓修边板”，跨原折线的板标记保留折弯几何。

## 移动、保存和导出

保留模型上下左右平移、长按、1/5/10 m 步长、回中、单屋顶顶视、截图。平移只改变视图，不改变模型的导出坐标。

保存方案记录长、宽、自定义比例、锁定状态和视图；可恢复 V6 方案，也可读取 V5 方案参数后按 V6 分格重算。旧 V5 成果包仍保留。

CSV、JSON、DAE 均使用当前应用的尺寸及屋顶范围。完整包中的 `示例_2500x6000_自由模式` 为 2500×6000 mm 的实际导出；网页默认仍是 1000×3000 mm。SketchUp JSON 导入脚本支持 V6 自由宽度，并兼容旧 V3/V4/V5。导入到新分组和 `RP_V6自由尺寸铝板_中心矩形` 图层，原模型和旧分隔不自动删除。

## 校核与尺寸口径

原模型坐标、曲面每个源三角面的完整覆盖、无重叠、全部实例的真实面积、两方向尺寸、四边分格及外轮廓修边均经过独立数值校核。原屋面净面积约 41,612.70 m²。浏览器校核包含大于 1500 mm 的宽度、比例联动、真实橘色/红色像素和数量、保存恢复、移动和导出。

设定尺寸是两方向分格的上界，曲面收分和修边导致实际尺寸可能更小；尺寸组使用实际板件几何上界。未计算加工展开、板缝、折边、搭接、板厚、龙骨和开孔，不能直接作为下料数据。跨源折线的板需要相应折弯或曲面成形。

桥接已做 Ruby 语法和逐板数值预检，本环境未安装 SketchUp，未在 SketchUp Pro 2018 内实机运行。
'''
    (OUT/'使用说明.md').write_text(guide)
    (OUT/'打开说明.txt').write_text('1102e 屋面铝板 V6\n\n解压后用新版 Edge 或 Chrome 打开 app.html。\n长、宽均可自由输入正数，按1mm取整；已取消1500mm宽度上限。\n可选比例锁：2.5、5:2等，长宽双向联动。\n点选橘色板，其余同尺寸板红色，同时显示数量。\n中心为保留原起伏的四边随形分格；原外轮廓仍保留修边板。\n保留模型移动、保存和统计导出。\n', encoding='utf-8-sig')
    shutil.copyfile(ROOT/'app.html', OUT/'roof_panels_flexible_v6.html')
    for source, name in [('1102e_V6同尺寸联选预览.png','roof_panels_flexible_v6_preview.png'),
                         ('1102e_V6中心四边分格预览.png','roof_panels_flexible_v6_center.png'),
                         ('1102e_V6比例锁预览.png','roof_panels_flexible_v6_ratio.png')]:
        shutil.copyfile(ROOT/source, OUT/name)
    basic = {'app.html':ROOT/'app.html','使用说明.md':OUT/'使用说明.md',
             '打开说明.txt':OUT/'打开说明.txt','sketchup_bridge.rb':ROOT/'sketchup_bridge.rb',
             'SKETCHUP使用说明.md':ROOT/'SKETCHUP使用说明.md'}
    files = dict(basic)
    for name in ['1102e_V6自由尺寸分隔.json','1102e_V6自由尺寸分隔.dae','1102e_V6逐板统计.csv']:
        files['示例_2500x6000_自由模式/'+name] = ROOT/name
    for name in ['1102e_V6同尺寸联选预览.png','1102e_V6中心四边分格预览.png','1102e_V6比例锁预览.png']:
        files[name] = ROOT/name
    technical = ['panel-worker.js','renderer-v6.js','app.template.html.txt','build_delivery.py',
                 'package_delivery_v6.py','default-study.json','modelData.json','source_uv_complete.json',
                 'context_lite.bin.gz','context_lite.meta.json','worker_generate.mjs','planar_rectangle.py',
                 'validate_dynamic_geometry_v6.py','dynamic_geometry_validation.json','browser_smoke_v6.py',
                 'browser_validation.json','build_manifest.json','validate_bridge_numeric_v6.py',
                 'bridge_numeric_validation.json','bridge_legacy_validation.json','bridge_syntax_validation.json',
                 'v6_selection_validate.mjs','v6_selection_validation.json',
                 'validate_resource_guards_v6.mjs','resource_guard_validation.json',
                 'v6_validator_negative_control.json','validate_delivery_v6.py']
    for name in technical:
        files['技术复算/'+name] = ROOT/name
    for p in sorted((ROOT/'validation_reports').glob('*')):
        if p.is_file() and (p.name.endswith('_report.json') or p.suffix=='.md'):
            files['技术复算/validation_reports/'+p.name] = p
    files['技术复算/geometry-requirements.txt'] = ROOT.parent/'roof-panel-studio-v3/geometry-requirements.txt'
    for suffix, contents in [('web',basic), ('full',files)]:
        path = OUT/f'roof_panels_flexible_v6_{suffix}.zip'
        with ZipFile(path, 'w', ZIP_DEFLATED, compresslevel=9) as archive:
            for name, origin in contents.items():
                assert origin.is_file(), origin
                archive.write(origin,name)
        with ZipFile(path) as archive:
            assert archive.testzip() is None
    manifest=[]
    for path in sorted(OUT.iterdir()):
        if path.is_file() and path.name!='checksums.json':
            manifest.append({'file':path.name,'bytes':path.stat().st_size,
                             'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
    (OUT/'checksums.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
    print(json.dumps(manifest,ensure_ascii=False,indent=2))


if __name__ == '__main__':
    package()
