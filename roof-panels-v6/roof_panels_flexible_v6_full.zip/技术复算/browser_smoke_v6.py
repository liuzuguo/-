"""Actual offline browser integration, GPU selection pixels and downloads for V6."""
from pathlib import Path
from functools import partial
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
import threading
import json, csv, io, math, hashlib
import xml.etree.ElementTree as ET
from playwright.sync_api import sync_playwright, expect

ROOT = Path(__file__).resolve().parent
PORT = 8052


class QuietHandler(SimpleHTTPRequestHandler):
    def log_message(self, *args):
        pass


PICK_VISIBLE = r"""() => {
  const t=ROOF_PANEL_TEST, gl=t.gl, c=document.getElementById('model');
  renderer.render(true);
  const pixels=new Uint8Array(c.width*c.height*4);
  gl.readPixels(0,0,c.width,c.height,gl.RGBA,gl.UNSIGNED_BYTE,pixels);
  const region=new Map();
  const idAt=(x,y)=>{let i=(y*c.width+x)*4;return pixels[i]+256*pixels[i+1]+65536*pixels[i+2]-1};
  for(let y=3;y<c.height-3;y++)for(let x=3;x<c.width-3;x++){
    let index=idAt(x,y);if(index<0||index>=t.world.length)continue;
    let item=region.get(index);if(!item){item={index,count:0,score:-1};region.set(index,item)}
    item.count++;
    let score=0;for(let yy=-2;yy<=2;yy++)for(let xx=-2;xx<=2;xx++)if(idAt(x+xx,y+yy)===index)score++;
    if(score>item.score){item.score=score;item.x=x;item.y=y}
  }
  const groups=new Map();
  for(const item of region.values()){
    if(item.score<16)continue;
    let key=t.panelSizeKey(t.world[item.index]);if(!groups.has(key))groups.set(key,[]);
    groups.get(key).push(item);
  }
  const choices=Array.from(groups,([key,items])=>({key,items:items.sort((a,b)=>b.score-a.score||b.count-a.count),types:new Set(items.map(p=>t.world[p.index].type_id)).size})).filter(g=>g.items.length>=3).sort((a,b)=>b.types-a.types||b.items.length-a.items.length);
  if(!choices.length)throw Error('No group has 3 visible interior plate pixels');
  const result=choices[0], r=c.getBoundingClientRect();
  for(const item of result.items){item.clientX=r.left+(item.x+.5)/c.width*r.width;item.clientY=r.bottom-(item.y+.5)/c.height*r.height}
  renderer.render();return result;
}"""

READ_COLORS = r"""items => {
  renderer.render();const gl=ROOF_PANEL_TEST.gl;
  return items.map(item=>{let p=new Uint8Array(4);gl.readPixels(item.x,item.y,1,1,gl.RGBA,gl.UNSIGNED_BYTE,p);return {index:item.index,pixel:Array.from(p)}})
}"""


def main():
    checks=[]; errors=[]; external=[]; pixel_evidence=[]
    server=ThreadingHTTPServer(('127.0.0.1',PORT),partial(QuietHandler,directory=str(ROOT)))
    threading.Thread(target=server.serve_forever,daemon=True).start()
    def passed(message):
        checks.append(message);print('PASS:',message,flush=True)
    try:
        with sync_playwright() as p:
            browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'])
            page=browser.new_page(viewport={'width':1780,'height':1220},device_scale_factor=1)
            page.set_default_timeout(120000)
            page.on('pageerror',lambda e:errors.append(str(e)))
            page.on('request',lambda r:external.append(r.url) if not r.url.startswith(('http://127.0.0.1','blob:','data:')) else None)
            page.goto(f'http://127.0.0.1:{PORT}/app.html');page.wait_for_function('window.ROOF_PANEL_TEST')
            def wait(w,l):
                page.wait_for_function('([w,l])=>!ROOF_PANEL_TEST.computing&&Math.round(ROOF_PANEL_TEST.candidate.nominal_width_m*1000)===w&&Math.round(ROOF_PANEL_TEST.candidate.nominal_length_m*1000)===l',arg=[w,l])
            def request(w,l,options=None):
                return page.evaluate('([w,l,o])=>ROOF_PANEL_TEST.requestSize(w,l,o).then(c=>!!c)',[w,l,options or {}])
            def counts():
                return page.evaluate('({world:ROOF_PANEL_TEST.world.length,declared:ROOF_PANEL_TEST.candidate.summary.panel_count,rectangles:ROOF_PANEL_TEST.candidate.panels.filter(p=>p.is_surface_rectangle).length,templates:ROOF_PANEL_TEST.candidate.panels.length})')
            default=counts();assert default['world']==default['declared'] and default['rectangles']>0 and page.evaluate('ROOF_PANEL_TEST.candidate.summary.surface_rectangle_panel_count+ROOF_PANEL_TEST.candidate.summary.boundary_trim_panel_count===ROOF_PANEL_TEST.world.length')
            expect(page.locator('#mCheck')).to_have_text('通过')
            assert not page.locator('#ratioLock').is_checked()
            assert not page.locator('#widthInput').get_attribute('max')
            passed('default V6 loads complete four-sided surface cells with explicit outline trims; width input has no 1500mm maximum')

            page.locator('#widthInput').fill('2500');page.locator('#lengthInput').fill('6000');page.locator('#applySizeBtn').click();wait(2500,6000)
            assert page.locator('#widthInput').input_value()=='2500'
            expect(page.locator('#mCheck')).to_have_text('通过')
            large_count=counts()['world'];assert large_count>0 and large_count!=default['world']
            assert float(page.locator('#widthSlider').get_attribute('max'))>=2500
            assert request(400,6000);wait(400,6000)
            assert page.locator('#widthInput').input_value()=='400'
            expect(page.locator('#mCheck')).to_have_text('通过')
            assert request(5000,3000);wait(5000,3000)
            assert page.evaluate('ROOF_PANEL_TEST.sizing.widthMm')==5000
            assert request(2500,6000);wait(2500,6000)
            passed('actual width2500,5000 and400 independently regenerate meshes without old upper or lower clamp')

            page.locator('#ratioLock').check();wait(2500,6000)
            page.locator('#ratioInput').fill('5:2');page.locator('#ratioInput').press('Enter');wait(2500,6250)
            page.locator('#lengthInput').fill('8000');page.locator('#lengthInput').press('Enter');wait(3200,8000)
            assert page.locator('#widthInput').input_value()=='3200'
            page.locator('#ratioInput').fill('4:5');page.locator('#ratioInput').press('Enter');wait(3200,2560)
            before=page.evaluate('ROOF_PANEL_TEST.candidate.id')
            page.locator('#ratioInput').fill('1:0');page.locator('#ratioInput').press('Enter');expect(page.locator('#sizeStatus')).to_contain_text('比例')
            assert page.evaluate('ROOF_PANEL_TEST.candidate.id')==before
            page.locator('#ratioLock').uncheck();wait(3200,2560)
            page.locator('#lengthInput').fill('6000');page.locator('#lengthInput').press('Enter');wait(3200,6000)
            assert page.locator('#widthInput').input_value()=='3200'
            passed('arbitrary ratio lock links bidirectionally above1500 and below1; unlocking restores independent dimensions')

            assert request(2500,6000)
            with page.expect_download() as dl:page.locator('#saveBtn').click()
            free=ROOT/'test_free_project_v6.json';dl.value.save_as(free)
            saved=json.loads(free.read_text());assert saved['format']=='roof-panel-project-6' and saved['width_mm']==2500 and not saved['ratio_locked']
            assert request(1000,3000)
            page.locator('#projectFile').set_input_files(str(free));wait(2500,6000)
            assert request(3200,8000,{'ratioLocked':True,'ratio':2.5,'ratioText':'5:2'})
            with page.expect_download() as dl:page.locator('#saveBtn').click()
            locked=ROOT/'test_ratio_project_v6.json';dl.value.save_as(locked)
            assert request(2500,6000)
            page.locator('#projectFile').set_input_files(str(locked));wait(3200,8000)
            assert page.locator('#ratioLock').is_checked() and page.locator('#ratioInput').input_value()=='5:2'
            page.screenshot(path=str(ROOT/'1102e_V6比例锁预览.png'),full_page=True)
            old=dict(saved);old.update(format='roof-panel-project-5',width_mm=1000,length_mm=3000)
            legacy=ROOT/'test_legacy_v5_project.json';legacy.write_text(json.dumps(old))
            page.locator('#projectFile').set_input_files(str(legacy));wait(1000,3000)
            assert page.evaluate('ROOF_PANEL_TEST.candidate.summary.center_interior_rectangle_panel_count===ROOF_PANEL_TEST.candidate.summary.center_interior_panel_count')
            passed('V6 free/locked projects save and restore new widths; legacyV5 project recomputes with V6 layout')

            result=page.evaluate('async()=>{let a=ROOF_PANEL_TEST.requestSize(2500,5000);let b=ROOF_PANEL_TEST.requestSize(2500,6000);await Promise.all([a,b]);return ROOF_PANEL_TEST.sizing}')
            assert result['widthMm']==2500 and result['lengthMm']==6000
            old_id=page.evaluate('ROOF_PANEL_TEST.candidate.id')
            assert not request(0,6000);assert page.evaluate('ROOF_PANEL_TEST.candidate.id')==old_id
            assert not request(-2,6000);assert not request(2500,0)
            assert request(2500,6000,{'ratioText':'12:5'})
            passed('latest size pair wins; zero and negative dimensions retain the last valid model')

            page.locator('#roof').select_option('all');page.locator('#topBtn').click()
            page.locator('#context').uncheck();page.locator('#seams').uncheck()
            visible=page.evaluate(PICK_VISIBLE)
            primary=visible['items'][0];page.mouse.click(primary['clientX'],primary['clientY'])
            assert page.evaluate('ROOF_PANEL_TEST.selected.index')==primary['index']
            state=page.evaluate('({stats:ROOF_PANEL_TEST.selectionStats(),highlight:ROOF_PANEL_TEST.highlight,expected:ROOF_PANEL_TEST.world.filter(p=>ROOF_PANEL_TEST.panelSizeKey(p)===ROOF_PANEL_TEST.panelSizeKey(ROOF_PANEL_TEST.selected)).map(p=>p.index),types:[...new Set(ROOF_PANEL_TEST.world.filter(p=>ROOF_PANEL_TEST.panelSizeKey(p)===ROOF_PANEL_TEST.panelSizeKey(ROOF_PANEL_TEST.selected)).map(p=>p.type_id))]})')
            assert state['highlight']['matchingIndices']==state['expected']
            assert state['stats']['count']==len(state['expected']) and state['stats']['others']==len(state['expected'])-1
            assert len(state['types'])>=2
            expect(page.locator('#selectionSummary')).to_contain_text(str(state['stats']['others']))
            colors=page.evaluate(READ_COLORS,visible['items'][:4])
            orange=colors[0]['pixel'];assert orange[0]>orange[1]*1.4 and orange[1]>orange[2]*2,colors
            for sample in colors[1:3]:
                red=sample['pixel'];assert red[0]>red[1]*3 and red[0]>red[2]*3,colors
            pixel_evidence.append({'scope':'all','visible_group':visible,'colors':colors,'stats':state['stats'],'geometry_types':state['types']})
            page.locator('#seams').check()
            page.wait_for_function('getComputedStyle(document.getElementById("toast")).display==="none"')
            page.screenshot(path=str(ROOT/'1102e_V6同尺寸联选预览.png'),full_page=True)
            passed('actual click gives orange selected plate plus red same-size peers across types; GPU pixels and quantities agree')

            page.locator('#isolate').check()
            isolated=page.evaluate('(()=>{renderer.render(true);let gl=ROOF_PANEL_TEST.gl,c=document.getElementById("model"),a=new Uint8Array(c.width*c.height*4),found=new Set();gl.readPixels(0,0,c.width,c.height,gl.RGBA,gl.UNSIGNED_BYTE,a);for(let i=0;i<a.length;i+=4){let id=a[i]+a[i+1]*256+a[i+2]*65536-1;if(id>=0)found.add(id)}renderer.render();return {found:[...found],allowed:ROOF_PANEL_TEST.highlight.matchingIndices}})()')
            assert isolated['found'] and set(isolated['found'])<=set(isolated['allowed'])
            page.locator('#isolate').uncheck();page.locator('#clearFilter').click()
            assert page.evaluate('ROOF_PANEL_TEST.selected') is None
            expect(page.locator('#selectionSummary')).to_be_hidden()
            page.locator('#bySize').click();page.locator('#tableBody tr').first.click()
            assert page.evaluate('ROOF_PANEL_TEST.highlight.count===ROOF_PANEL_TEST.selectionStats().count')
            page.locator('#clearFilter').click()
            passed('size-group isolation hides all unmatched plates; clear and statistics-row selection update both colors and count')

            for roof in ['A','D']:
                page.locator('#roof').select_option(roof);page.locator('#singleTopBtn').click()
                r=page.locator('#model').bounding_box();page.mouse.click(r['x']+r['width']*.52,r['y']+r['height']*.52)
                info=page.evaluate('({selected:ROOF_PANEL_TEST.selected&&ROOF_PANEL_TEST.selected.roof_id,stats:ROOF_PANEL_TEST.selectionStats(),highlight:ROOF_PANEL_TEST.highlight,expected:ROOF_PANEL_TEST.world.filter(p=>p.roof_id===document.getElementById("roof").value&&ROOF_PANEL_TEST.panelSizeKey(p)===ROOF_PANEL_TEST.panelSizeKey(ROOF_PANEL_TEST.selected)).map(p=>p.index)})')
                assert info['selected']==roof and info['highlight']['matchingIndices']==info['expected']
                assert info['stats']['count']==len(info['expected']) and info['stats']['total']>=info['stats']['count']
                page.locator('#clearFilter').click()
            passed('single-roof A and D picking and same-size quantities respect the current scope and all-roof totals')

            page.locator('#roof').select_option('all');page.locator('#isoBtn').click();page.locator('#seams').check()
            before=page.evaluate('ROOF_PANEL_TEST.camera.pan.slice()');page.locator('#moveRight').click();after=page.evaluate('ROOF_PANEL_TEST.camera.pan.slice()');assert math.dist(before,after)>4.99
            page.locator('#moveCenter').click()
            with page.expect_download() as dl:page.locator('#partsCsvBtn').click()
            csvpath=ROOT/'1102e_V6逐板统计.csv';dl.value.save_as(csvpath)
            rows=list(csv.reader(io.StringIO(csvpath.read_text(encoding='utf-8-sig'))));assert len(rows)-1==large_count
            with page.expect_download() as dl:page.locator('#jsonBtn').click()
            modelpath=ROOT/'1102e_V6自由尺寸分隔.json';dl.value.save_as(modelpath);model=json.loads(modelpath.read_text())
            assert len(model['panels'])==large_count and model['nominal_width_m']==2.5 and model['nominal_length_m']==6
            assert model['panel_study_version']=='v6-flexible' and model['sizing_rule']['min_width_mm']==1 and model['sizing_rule']['max_width_mm']==1e9
            assert not model['sizing_rule']['ratio_locked']
            with page.expect_download() as dl:page.locator('#daeBtn').click()
            dae=ROOT/'1102e_V6自由尺寸分隔.dae';dl.value.save_as(dae)
            assert len(ET.parse(dae).findall('.//{http://www.collada.org/2005/11/COLLADASchema}geometry'))==large_count
            page.locator('#helpBtn').click()
            with page.expect_download() as dl:page.locator('#downloadBridgeBtn').click()
            bridge=ROOT/'test_bridge_v6.rb';dl.value.save_as(bridge);assert bridge.read_bytes()==(ROOT/'sketchup_bridge.rb').read_bytes()
            page.locator('#closeModal').click()
            passed('model movement and actual2500×6000 CSV/JSON/DAE and embedded Ruby downloads match the applied V6 model')

            page.locator('#roof').select_option('A');page.locator('#singleTopBtn').click()
            page.wait_for_function('getComputedStyle(document.getElementById("toast")).display==="none"')
            page.screenshot(path=str(ROOT/'1102e_V6中心四边分格预览.png'),full_page=True)
            shape=page.evaluate('(()=>{let panels=ROOF_PANEL_TEST.candidate.panels,central=panels.filter(p=>p.uv_bounds&&p.uv_bounds[1]<2);return {all:panels.length,rectangles:panels.filter(p=>p.is_surface_rectangle).length,center:central.length,centerRectangles:central.filter(p=>p.is_surface_rectangle).length}})()')
            assert shape['rectangles']>0 and shape['center']>0 and page.evaluate('ROOF_PANEL_TEST.candidate.summary.center_interior_rectangle_panel_count===ROOF_PANEL_TEST.candidate.summary.center_interior_panel_count')
            page.set_viewport_size({'width':390,'height':844})
            assert page.locator('#model').is_visible() and page.locator('#movePad').is_visible()
            page.screenshot(path=str(ROOT/'mobile_v6.png'),full_page=True)
            assert not errors,errors;assert not external,external;assert page.evaluate('ROOF_PANEL_TEST.gl.getError()')==0
            passed('center interior cells remain complete four-sided patches; offline desktop/mobile have no JS,GL or external-request errors')
            browser.close()
        report={'passed':len(checks),'checks':checks,'errors':errors,'external_requests':external,'sample_width_mm':2500,'sample_length_mm':6000,'sample_panels':large_count,'shape_stats':shape,'worker_sha256':hashlib.sha256((ROOT/'panel-worker.js').read_bytes()).hexdigest(),'html_sha256':hashlib.sha256((ROOT/'app.html').read_bytes()).hexdigest(),'gpu_pixel_evidence':pixel_evidence,'delivery_mode_tested':'fully embedded HTML via local HTTP; managed browser disallows file navigation'}
        (ROOT/'browser_validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
    finally:
        server.shutdown();server.server_close()


if __name__=='__main__':
    main()
