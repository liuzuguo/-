"""Independent checks of dynamically generated V6 roof-panel partitions.

This recomputes provenance, UV path bounds, true 3D area and coverage from saved
meshes. It deliberately does not import the generating engine.
"""
from __future__ import annotations
import argparse
import collections
import json
import math
import sys
import time
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'vendor'))
sys.path.insert(0, str(ROOT.parent / 'roof-panel-studio' / 'vendor'))
from shapely.geometry import Point, Polygon, box
from shapely.ops import unary_union
from shapely.strtree import STRtree
from planar_rectangle import feasible_rectangle


def require(test, message):
    if not test:
        raise AssertionError(message)


def cross_vectors(points, faces):
    return np.cross(points[faces[:, 1]]-points[faces[:, 0]],
                    points[faces[:, 2]]-points[faces[:, 0]])


class SourceIndex:
    """Map each clipped triangle back to the original surface, without engine IDs."""
    def __init__(self, points, faces, uv):
        self.points, self.faces, self.uv = points, faces, uv
        self.triangles = points[faces]
        self.uv_triangles = uv[faces]
        self.polygons = [Polygon(p[:, :2]) for p in self.triangles]
        self.tree = STRtree(self.polygons)
        xy = self.triangles[:, :, :2]
        self.xy_matrix = np.stack((xy[:, 1]-xy[:, 0], xy[:, 2]-xy[:, 0]), axis=2)
        self.xy_inverse = np.linalg.inv(self.xy_matrix)
        uv_matrix = np.stack((self.uv_triangles[:, 1]-self.uv_triangles[:, 0],
                              self.uv_triangles[:, 2]-self.uv_triangles[:, 0]), axis=2)
        self.uv_determinants = np.linalg.det(uv_matrix)
        require(np.min(np.abs(self.uv_determinants)) > 1e-10,
                'Source UV contains a degenerate triangle')
        require(bool(np.all(self.uv_determinants > 0) or np.all(self.uv_determinants < 0)),
                'Source UV chart changes orientation or folds over itself')
        xyz_matrix = np.stack((self.triangles[:, 1]-self.triangles[:, 0],
                               self.triangles[:, 2]-self.triangles[:, 0]), axis=2)
        self.jacobian = xyz_matrix @ np.linalg.inv(uv_matrix)
        cr = cross_vectors(points, faces)
        self.normals = cr/np.linalg.norm(cr, axis=1)[:, None]
        self.normals[self.normals[:, 2] < 0] *= -1
        self.cache = {}

    def lookup(self, point):
        key = tuple(np.round(point, 9))
        if key in self.cache:
            return self.cache[key]
        q = np.asarray(point)
        candidates = self.tree.query(Point(q[:2]).buffer(2e-7))
        best = None
        for fi in candidates:
            b = self.xy_inverse[fi] @ (q[:2]-self.triangles[fi, 0, :2])
            bary = np.array([1-b.sum(), b[0], b[1]])
            inside = float(bary.min())
            if inside < -2e-5:
                continue
            expected = bary @ self.triangles[fi]
            error = abs(float(expected[2]-q[2]))
            if error > 2e-6:
                continue
            value = (inside, -error, int(fi), bary @ self.uv_triangles[fi])
            if best is None or value[:2] > best[:2]:
                best = value
        require(best is not None, f'Output vertex is not on source surface: {q.tolist()}')
        result = (best[2], best[3], -best[1])
        self.cache[key] = result
        return result

    def triangle_source(self, triangle):
        q = np.mean(triangle, axis=0)
        candidates = self.tree.query(Point(q[:2]).buffer(2e-7))
        choices = []
        output_normal = np.cross(triangle[1]-triangle[0], triangle[2]-triangle[0])
        output_normal /= np.linalg.norm(output_normal)
        if output_normal[2] < 0:
            output_normal *= -1
        for fi in candidates:
            b = (triangle[:, :2]-self.triangles[fi, 0, :2]) @ self.xy_inverse[fi].T
            bary = np.column_stack((1-b.sum(axis=1), b))
            if bary.min() < -3e-5:
                continue
            expected_z = (bary @ self.triangles[fi])[:, 2]
            height_error = float(np.max(np.abs(expected_z-triangle[:, 2])))
            if height_error > 3e-6:
                continue
            center_bary = bary.mean(axis=0)
            choices.append((float(center_bary.min()),
                            float(output_normal @ self.normals[fi]),
                            -height_error, int(fi)))
        require(bool(choices), 'Saved triangle crosses a source facet or leaves its surface')
        return max(choices)[3]


def validate(source, data):
    require(data.get('unit') == 'm', 'Expected metre units')
    require(isinstance(data.get('candidates'), list) and bool(data['candidates']),
            'No candidate geometry was selected for validation')
    s = source['variants']['0']
    sp = np.asarray(s['vertices'], dtype=float)
    sf = np.asarray(s['faces'], dtype=int)
    uv_value = data.get('layout', {}).get('source_uv')
    if uv_value is None:
        uv_value = data.get('source_uv')
    require(uv_value is not None, 'Missing source UV provenance')
    source_uv = np.asarray(uv_value, dtype=float)
    require(source_uv.shape == (len(sp), 2) and np.isfinite(source_uv).all(),
            'Source UV shape or values invalid')
    index = SourceIndex(sp, sf, source_uv)
    source_cross = cross_vectors(sp, sf)
    source_area = float(np.linalg.norm(source_cross, axis=1).sum()/2)
    source_projection = unary_union(index.polygons)
    source_uv_domain = unary_union([Polygon(t) for t in source_uv[sf]])
    require(source_uv_domain.is_valid, 'Invalid source UV domain')
    face_edge_map = collections.defaultdict(list)
    for fi, face in enumerate(sf):
        for a, b in zip(face, np.roll(face, -1)):
            face_edge_map[tuple(sorted((int(a), int(b))))].append(fi)
    sharp = collections.defaultdict(set)
    threshold = float(data.get('crease_angle_deg', 10))
    for owners in face_edge_map.values():
        if len(owners) == 2:
            a, b = owners
            angle = math.degrees(math.acos(float(np.clip(index.normals[a] @ index.normals[b], -1, 1))))
            if angle > threshold+1e-6:
                sharp[a].add(b)
                sharp[b].add(a)

    visible_duv = source_uv[np.asarray(s['edges'])[:, 1]]-source_uv[np.asarray(s['edges'])[:, 0]]
    original_aligned = np.minimum(np.abs(visible_duv[:, 0]), np.abs(visible_duv[:, 1])) < 1e-6
    require(float(original_aligned.mean()) > .99,
            'UV does not follow the source fan-grid edge directions')

    transforms = []
    world_source_areas = []
    for ins in source['instances']:
        m = np.asarray(ins['matrix'], dtype=float).reshape(4, 4).T
        transforms.append(m)
        wp = sp @ m[:3, :3].T + m[:3, 3]
        world_source_areas.append(float(np.linalg.norm(cross_vectors(wp, sf), axis=1).sum()/2))
    require(len(transforms) == 8, 'Expected eight half-roof instances')

    results = []
    for candidate in data['candidates']:
        started = time.perf_counter()
        nominal_u = float(candidate['nominal_width_m'])
        nominal_v = float(candidate['nominal_length_m'])
        width_limit, length_limit = sorted((nominal_u, nominal_v))
        width_mm = nominal_u * 1000
        length_mm = nominal_v * 1000
        require(math.isfinite(width_mm) and 1 - 1e-8 <= width_mm <= 1e9 + 1e-8,
                f'Nominal width is not a positive supported integer millimetre: {width_mm}')
        require(abs(width_mm - round(width_mm)) < 1e-7,
                f'Nominal width is not an integer millimetre: {width_mm}')
        require(math.isfinite(length_mm) and 1 <= length_mm <= 1e9 and
                abs(length_mm - round(length_mm)) < 1e-7,
                f'Nominal length is not a positive supported integer millimetre: {length_mm}')
        rule = data.get('sizing_rule')
        require(isinstance(rule, dict), 'Missing independent-size V6 sizing rule')
        require(rule.get('nominal_width_mm') == round(width_mm) and
                rule.get('nominal_length_mm') == round(length_mm),
                'Sizing rule does not match directional nominal dimensions')
        require(rule.get('min_width_mm') == 1 and rule.get('max_width_mm') == 1e9,
                'Sizing rule does not use free positive width (numerical guard only)')
        require(type(rule.get('ratio_locked')) is bool, 'Ratio lock must be a boolean')
        ratio_locked = rule['ratio_locked']
        require(rule.get('mode') == ('ratio' if ratio_locked else 'free'),
                'Sizing mode disagrees with the ratio lock')
        ratio = rule.get('ratio')
        if ratio_locked:
            require(isinstance(ratio, (float, int)) and not isinstance(ratio, bool) and
                    math.isfinite(ratio) and ratio > 0,
                    'Locked ratio must be finite and positive')
            require(abs(length_mm-width_mm*ratio) <= .51,
                    'Locked ratio disagrees with integer-mm length rounding')
        else:
            require(ratio is None or (isinstance(ratio, (float, int)) and
                    not isinstance(ratio, bool) and math.isfinite(ratio) and ratio > 0),
                    'Optional unlocked ratio must be null or finite and positive')
        if len(data['candidates']) == 1:
            require(abs(float(data['max_width_m']) - width_limit) < 1e-12 and
                    abs(float(data['max_length_m']) - length_limit) < 1e-12,
                    'Top-level limits do not match the sorted selected dimensions')
            require(abs(float(data['nominal_width_m'])-nominal_u) < 1e-12 and
                    abs(float(data['nominal_length_m'])-nominal_v) < 1e-12,
                    'Top-level directional nominal dimensions changed')
        area = 0.
        shapes = []
        maxw = maxl = max_z_error = max_uv_error = 0.
        maxu = maxv = 0.
        max_stored_width = max_stored_length = 0.
        max_angle = 0.
        triangle_count = seam_edges = aligned_seams = 0
        rectangle_panels = center_panels = center_rectangles = 0
        boundary_trim_panels = center_boundary_trims = 0
        center_interior_panels = center_interior_rectangles = 0
        max_original_boundary_clip_residual = 0.
        panels_crossing_source_crease = 0
        max_rectangle_uv_residual = 0.
        source_uv_low = source_uv.min(axis=0)
        source_uv_high = source_uv.max(axis=0)
        center_v_limit = float(source_uv_low[1] + 2.)
        source_ids_by_panel = []
        uv_spans = []
        triangle_offsets = []
        declared_world_areas = []
        all_e1 = []
        all_e2 = []
        planar_records = []
        type_shapes = {}
        actual_type_counts = collections.Counter()
        below_minimum_pieces = 0
        min_published_width = min_published_length = math.inf
        min_mesh_edge = math.inf
        facet_fragments = collections.defaultdict(list)
        for panel in candidate['panels']:
            label = panel['id']
            points = np.asarray(panel['vertices'], dtype=float)
            faces = np.asarray(panel['faces'], dtype=int)
            puv = np.asarray(panel.get('uv_vertices'), dtype=float)
            require(points.ndim == 2 and points.shape[1] == 3 and np.isfinite(points).all(),
                    f'{label}: invalid 3D vertices')
            require(puv.shape == (len(points), 2) and np.isfinite(puv).all(),
                    f'{label}: invalid UV vertices')
            require(faces.ndim == 2 and faces.shape[1] == 3 and faces.min() >= 0 and faces.max() < len(points),
                    f'{label}: invalid triangle indices')
            cr = cross_vectors(points, faces)
            face_areas = np.linalg.norm(cr, axis=1)/2
            require(face_areas.min() > 1e-12, f'{label}: zero-area triangle')
            actual = float(face_areas.sum())
            require(abs(actual-panel['area_m2']) < 1e-6, f'{label}: reported area mismatch')
            type_id = panel['type_id']
            actual_type_counts[type_id] += 1
            # Independent rigid-shape invariants prevent grouping different
            # shapes merely because their rounded width/length happen to match.
            pairwise = np.sort(np.linalg.norm(points[:, None]-points[None, :], axis=2).ravel())
            invariant = (len(points), len(faces), pairwise, actual, panel['kind'])
            if type_id in type_shapes:
                previous = type_shapes[type_id]
                require(previous[:2] == invariant[:2] and previous[4] == invariant[4],
                        f'{label}: one type contains different topology or processing classes')
                require(np.max(np.abs(previous[2]-pairwise)) < 2e-5 and
                        abs(previous[3]-actual) < 2e-5,
                        f'{label}: one type contains different rigid panel shapes')
            else:
                type_shapes[type_id] = invariant
            area += actual
            triangle_offsets.append(triangle_count)
            triangle_count += len(faces)
            world_values = np.asarray(panel.get('world_areas_m2'), dtype=float)
            require(world_values.shape == (len(transforms),) and
                    np.isfinite(world_values).all() and np.all(world_values > 0),
                    f'{label}: missing or invalid transformed area values')
            declared_world_areas.append(world_values)
            min_mesh_edge = min(min_mesh_edge, float(np.min(np.linalg.norm(
                points[faces] - points[np.roll(faces, -1, axis=1)], axis=2))))
            min_published_width = min(min_published_width, panel['width_m'])
            min_published_length = min(min_published_length, panel['length_m'])
            below_minimum_pieces += int(panel['width_m'] < .5 - 1e-8)
            for v, claimed_uv in zip(points, puv):
                _, expected_uv, z_error = index.lookup(v)
                uv_error = float(np.max(np.abs(expected_uv-claimed_uv)))
                max_z_error = max(max_z_error, z_error)
                max_uv_error = max(max_uv_error, uv_error)
                require(uv_error < 2e-5, f'{label}: UV provenance mismatch {uv_error}')
            source_ids = set()
            for face in faces:
                source_id = index.triangle_source(points[face])
                source_ids.add(source_id)
                facet_fragments[source_id].append(Polygon(points[face, :2]))
            claimed_ids = set(panel.get('source_face_ids', []))
            require(not claimed_ids or source_ids <= claimed_ids,
                    f'{label}: source-face provenance is incomplete')
            if claimed_ids:
                require(min(claimed_ids) >= 0 and max(claimed_ids) < len(sf),
                        f'{label}: invalid source face IDs')
            source_ids_by_panel.append(np.asarray(sorted(source_ids), dtype=int))
            span = np.ptp(puv, axis=0)
            uv_spans.append(span)
            lengths = span*np.linalg.norm(index.jacobian[sorted(source_ids)], axis=1).max(axis=0)
            require(lengths[0] <= nominal_u+2e-6 and lengths[1] <= nominal_v+2e-6,
                    f'{label}: directional surface path exceeds selected U/V sizes {lengths}')
            require(lengths[0] <= panel['surface_u_bound_m']+2e-5 and
                    lengths[1] <= panel['surface_v_bound_m']+2e-5,
                    f'{label}: metadata does not bound directional U/V paths')
            require(panel['surface_u_bound_m'] <= nominal_u+1e-8 and
                    panel['surface_v_bound_m'] <= nominal_v+1e-8,
                    f'{label}: published directional bounds exceed selected U/V limits')
            maxu, maxv = max(maxu, float(lengths[0])), max(maxv, float(lengths[1]))
            bounds = sorted(map(float, lengths))
            require(bounds[0] <= width_limit+2e-6 and bounds[1] <= length_limit+2e-6,
                    f'{label}: recomputed surface path dimensions exceed limits {bounds}')
            for value, name in zip(bounds, ['surface_width_bound_m', 'surface_length_bound_m']):
                require(value <= panel[name]+2e-5,
                        f'{label}: metadata does not bound the surface path {name}')
            require(panel['width_m'] >= bounds[0]-2e-5 and panel['length_m'] >= bounds[1]-2e-5,
                    f'{label}: published dimensions are not conservative')
            require(0 < panel['width_m'] <= width_limit+1e-8 and
                    0 < panel['length_m'] <= length_limit+1e-8,
                    f'{label}: published size exceeds limit')
            maxw, maxl = max(maxw, bounds[0]), max(maxl, bounds[1])
            max_stored_width = max(max_stored_width, panel['width_m'])
            max_stored_length = max(max_stored_length, panel['length_m'])
            crosses_crease = any(sharp[fi] & source_ids for fi in source_ids)
            panels_crossing_source_crease += int(crosses_crease)

            if panel['kind'] == 'planar':
                q = points-points.mean(axis=0)
                _, _, basis = np.linalg.svd(q, full_matrices=False)
                require(feasible_rectangle(q @ basis[:2].T,
                                           width=width_limit, length=length_limit) is not None,
                        f'{label}: cannot fit an orthogonal {width_limit}×{length_limit}m rectangle')
                axes = np.asarray(panel['planar_box_axes'], dtype=float)
                require(axes.shape == (2, 3), f'{label}: missing planar box axes')
                require(np.max(np.abs(axes @ axes.T - np.eye(2))) < 2e-7,
                        f'{label}: saved planar box axes are not orthonormal')
                actual_box = sorted(np.ptp(points @ axes.T, axis=0))
                require(actual_box[0] <= width_limit+2e-6 and
                        actual_box[1] <= length_limit+2e-6,
                        f'{label}: actual planar rectangle exceeds selected dimensions')
                require(actual_box[0] <= panel['planar_box_width_m']+2e-7 and
                        actual_box[1] <= panel['planar_box_length_m']+2e-7,
                        f'{label}: saved planar rectangle is too small')
                planar_records.append((label, points, axes))

            rings = panel['outlines']
            require(bool(rings), f'{label}: missing panel outlines')
            polygon = Polygon(np.asarray(rings[0])[:, :2],
                              [np.asarray(r)[:, :2] for r in rings[1:]])
            require(polygon.is_valid and not polygon.is_empty,
                    f'{label}: invalid projected panel boundary')
            shapes.append(polygon)
            require(len(rings) == 1, f'{label}: surface panel cannot have holes')
            ring_uv = np.asarray([index.lookup(v)[1] for v in rings[0]])
            uv_polygon = Polygon(ring_uv)
            declared = np.asarray(panel['uv_bounds'],dtype=float)
            require(declared.shape == (4,) and np.isfinite(declared).all() and
                    declared[2] > declared[0] and declared[3] > declared[1],
                    f'{label}: invalid parameter rectangle bounds')
            lo, hi = declared[:2], declared[2:]
            require(np.all(puv >= lo-3e-5) and np.all(puv <= hi+3e-5),
                    f'{label}: vertex outside declared parameter rectangle')
            expected_rectangle = box(lo[0], lo[1], hi[0], hi[1])
            require(uv_polygon.is_valid and not uv_polygon.is_empty,
                    f'{label}: invalid UV boundary')
            rectangle_residual = float(uv_polygon.symmetric_difference(expected_rectangle).area)
            rectangle_area = float(expected_rectangle.area)
            max_rectangle_uv_residual = max(max_rectangle_uv_residual, rectangle_residual)
            tolerance = max(1e-8, rectangle_area*1e-7)
            is_rectangle = rectangle_residual < tolerance
            require(type(panel.get('is_surface_rectangle')) is bool and
                    panel['is_surface_rectangle'] == is_rectangle,
                    f'{label}: claimed rectangle classification disagrees with independent UV outline')
            delta = np.roll(ring_uv, -1, axis=0)-ring_uv
            meaningful_delta = delta[np.linalg.norm(delta,axis=1)>1e-8]
            if is_rectangle:
                corners = np.array([[lo[0],lo[1]], [hi[0],lo[1]],
                                    [hi[0],hi[1]], [lo[0],hi[1]]])
                require(all(np.min(np.linalg.norm(ring_uv-corner,axis=1)) < 3e-5 for corner in corners),
                        f'{label}: missing one of four UV rectangle corners')
                require(bool(len(meaningful_delta)) and
                        np.all(np.min(np.abs(meaningful_delta),axis=1) < 3e-5),
                        f'{label}: diagonal panel edge forms an interior triangle or wedge')
                # Intermediate collinear UV points retain actual XYZ mesh bends.
                sides = []
                for edge in meaningful_delta:
                    sides.append((0 if abs(edge[1]) < abs(edge[0]) else 1,
                                  1 if edge[np.argmax(np.abs(edge))] > 0 else -1))
                logical_sides = [side for i,side in enumerate(sides) if i == 0 or side != sides[i-1]]
                if len(logical_sides)>1 and logical_sides[0] == logical_sides[-1]:
                    logical_sides.pop()
                require(len(logical_sides) == 4 and len(set(logical_sides)) == 4,
                        f'{label}: expected four logical UV seam sides, got {logical_sides}')
                rectangle_panels += 1
            else:
                # A nonrectangular plate is allowed solely where the original
                # roof's true outer boundary trims a complete grid rectangle.
                # This forbids calling internal crease triangles boundary trims.
                original_boundary_clip = expected_rectangle.intersection(source_uv_domain)
                clip_residual = float(uv_polygon.symmetric_difference(original_boundary_clip).area)
                max_original_boundary_clip_residual = max(max_original_boundary_clip_residual,clip_residual)
                require(clip_residual < tolerance,
                        f'{label}: interior nonrectangle is not an original-boundary trim; residual {clip_residual}')
                require(uv_polygon.distance(source_uv_domain.boundary) < 3e-5,
                        f'{label}: nonrectangular panel does not touch the original roof boundary')
                boundary_trim_panels += 1
            if lo[1] < center_v_limit-1e-8:
                center_panels += 1
                center_rectangles += int(is_rectangle)
                center_boundary_trims += int(not is_rectangle)
                # Interior center band excludes the narrow physical perimeter.
                if lo[0] >= source_uv_low[0]+1 and hi[0] <= source_uv_high[0]-1:
                    center_interior_panels += 1
                    center_interior_rectangles += int(is_rectangle)
                    require(is_rectangle,f'{label}: center interior is not a full four-sided rectangle')
            seam_edges += len(delta)
            aligned_seams += int(np.sum(np.min(np.abs(delta), axis=1) < 3e-5))
            normals = cr/np.linalg.norm(cr, axis=1)[:, None]
            normals[normals[:, 2] < 0] *= -1
            edges = {}
            for ti, face in enumerate(faces):
                for a, b in zip(face, np.roll(face, -1)):
                    edge = tuple(sorted((int(a), int(b))))
                    if edge in edges:
                        angle = math.degrees(math.acos(float(np.clip(normals[ti] @ normals[edges[edge]], -1, 1))))
                        max_angle = max(max_angle, angle)
                        # V6 intentionally retains the original sharp folds inside
                        # one surface rectangle instead of making triangular cuts.
                        require(angle <= 180.+1e-7, f'{label}: invalid internal crease angle')
                    else:
                        edges[edge] = ti
            all_e1.append(points[faces[:, 1]]-points[faces[:, 0]])
            all_e2.append(points[faces[:, 2]]-points[faces[:, 0]])

        covered = unary_union(shapes)
        uncovered = source_projection.difference(covered).area
        outside = covered.difference(source_projection).area
        overlap = sum(p.area for p in shapes)-covered.area
        require(uncovered < 1e-4 and outside < 1e-4 and abs(overlap) < 1e-4,
                f'{candidate["id"]}: coverage residuals {(uncovered, outside, overlap)}')
        require(abs(area-source_area) < 1e-4, f'{candidate["id"]}: surface area not conserved')
        # Independently verify the actual triangles on every original facet.
        # Checking the outlines alone could otherwise conceal a missing or
        # duplicated triangle inside a correctly drawn panel boundary.
        facet_gap = facet_outside = facet_overlap = 0.
        for fi, original_polygon in enumerate(index.polygons):
            fragments = facet_fragments[fi]
            require(bool(fragments), f'Original source facet {fi} has no output triangles')
            joined = unary_union(fragments)
            facet_gap += original_polygon.difference(joined).area
            facet_outside += joined.difference(original_polygon).area
            facet_overlap += max(0., sum(x.area for x in fragments)-joined.area)
        require(facet_gap < 1e-4 and facet_outside < 1e-4 and facet_overlap < 1e-4,
                f'{candidate["id"]}: actual source-facet coverage residuals '
                f'{(facet_gap, facet_outside, facet_overlap)}')
        require(aligned_seams/max(1, seam_edges) > .99,
                f'{candidate["id"]}: panel seams do not follow original fan UV curves')
        e1, e2 = np.vstack(all_e1), np.vstack(all_e2)
        world_areas = []
        declared_world_areas = np.asarray(declared_world_areas)
        max_panel_world_area_error = 0.
        max_world_width = max_world_length = 0.
        max_world_u = max_world_v = 0.
        max_world_planar_width = max_world_planar_length = 0.
        for k, m in enumerate(transforms):
            matrix = m[:3, :3]
            triangle_world_areas = np.linalg.norm(np.cross(e1 @ matrix.T, e2 @ matrix.T), axis=1)/2
            actual_panel_world_areas = np.add.reduceat(triangle_world_areas, triangle_offsets)
            panel_world_area_error = float(np.max(np.abs(
                actual_panel_world_areas-declared_world_areas[:, k])))
            max_panel_world_area_error = max(max_panel_world_area_error, panel_world_area_error)
            require(panel_world_area_error < 2e-6,
                    f'{candidate["id"]}: per-panel transformed area mismatch for instance {k}')
            wa = float(triangle_world_areas.sum())
            require(abs(wa-world_source_areas[k]) < 1e-4,
                    f'{candidate["id"]}: transformed instance {k} area mismatch')
            world_areas.append(wa)
            jacobian = np.einsum('ij,njk->nik', matrix, index.jacobian)
            norms = np.linalg.norm(jacobian, axis=1)
            for span, ids in zip(uv_spans, source_ids_by_panel):
                directional = list(map(float, span*norms[ids].max(axis=0)))
                require(directional[0] <= nominal_u+2e-6 and directional[1] <= nominal_v+2e-6,
                        f'{candidate["id"]}: transformed directional U/V surface path exceeded')
                max_world_u = max(max_world_u, directional[0])
                max_world_v = max(max_world_v, directional[1])
                wb = sorted(directional)
                max_world_width = max(max_world_width, wb[0])
                max_world_length = max(max_world_length, wb[1])
                require(wb[0] <= width_limit+2e-6 and wb[1] <= length_limit+2e-6,
                        f'{candidate["id"]}: transformed surface path size exceeded')
            for label, points, axes in planar_records:
                wp = points @ matrix.T
                a = matrix @ axes[0]
                a /= np.linalg.norm(a)
                b = matrix @ axes[1]
                b -= a*(a @ b)
                b /= np.linalg.norm(b)
                dims = sorted(np.ptp(wp @ np.stack([a, b]).T, axis=0))
                max_world_planar_width = max(max_world_planar_width, float(dims[0]))
                max_world_planar_length = max(max_world_planar_length, float(dims[1]))
                require(dims[0] <= width_limit+2e-6 and dims[1] <= length_limit+2e-6,
                        f'{label}: transformed planar box exceeds size limit')
        summary = candidate['summary']
        require(summary['panel_count'] == len(candidate['panels'])*len(transforms),
                'Instance panel count mismatch')
        require(summary['surface_rectangle_panel_count'] == rectangle_panels*len(transforms) and
                summary['boundary_trim_panel_count'] == boundary_trim_panels*len(transforms),
                'Summary surface-rectangle or perimeter-trim counts disagree with independent UV outlines')
        require(summary['center_panel_count'] == center_panels*len(transforms) and
                summary['center_rectangle_panel_count'] == center_rectangles*len(transforms) and
                summary['center_interior_panel_count'] == center_interior_panels*len(transforms) and
                summary['center_interior_rectangle_panel_count'] == center_interior_rectangles*len(transforms),
                'Summary center rectangle counts disagree with independently reconstructed boundaries')
        require(summary['needs_bend_panel_count'] == panels_crossing_source_crease*len(transforms),
                'Summary processing count disagrees with retained original source creases')
        require(sum(t['template_count'] for t in candidate['types']) == len(candidate['panels']),
                'Geometry type count mismatch')
        require({t['id']: t['template_count'] for t in candidate['types']} == dict(actual_type_counts),
                'Declared type membership does not match actual panel IDs')
        require(abs(summary['surface_area_m2']-sum(world_areas)) < 1e-4,
                'Summary does not use exact transformed surface area')
        require(abs(summary['max_width_m']-max_stored_width) < 2e-6 and
                abs(summary['max_length_m']-max_stored_length) < 2e-6,
                'Summary maximum dimensions do not match the actual panels')
        require(summary['planar_panel_count'] ==
                sum(p['kind'] == 'planar' for p in candidate['panels'])*len(transforms),
                'Summary planar panel count mismatch')
        require(summary['curved_panel_count'] ==
                sum(p['kind'] != 'planar' for p in candidate['panels'])*len(transforms),
                'Summary curved panel count mismatch')
        require(summary['below_500mm_panel_count'] == below_minimum_pieces*len(transforms),
                'Summary smaller-piece count mismatch')
        require(summary['nominal_width_mm'] == round(width_mm) and
                summary['nominal_length_mm'] == round(length_mm),
                'Summary directional nominal sizes do not match the selected W/L')
        require(abs(summary['selected_max_width_m']-width_limit) < 1e-12 and
                abs(summary['selected_max_length_m']-length_limit) < 1e-12,
                'Summary selected caps do not match sorted geometric dimensions')
        require(summary['max_surface_u_bound_m'] <= nominal_u+1e-8 and
                summary['max_surface_v_bound_m'] <= nominal_v+1e-8 and
                summary['max_surface_u_bound_m'] >= maxu-2e-5 and
                summary['max_surface_v_bound_m'] >= maxv-2e-5,
                'Summary directional surface path maxima are not conservative')
        result = {
            'candidate': candidate['id'], 'passed': True,
            'selected_width_mm': round(width_mm),
            'selected_length_mm': round(length_mm),
            'nominal_length_to_width_ratio': nominal_v/nominal_u,
            'ratio_locked': ratio_locked,
            'requested_ratio': ratio,
            'selected_geometric_width_limit_m': width_limit,
            'selected_geometric_length_limit_m': length_limit,
            'template_panels': len(candidate['panels']), 'full_panels': summary['panel_count'],
            'source_area_m2': source_area, 'output_area_m2': area,
            'area_error_m2': area-source_area,
            'all_instances_source_area_m2': sum(world_source_areas),
            'all_instances_output_area_m2': sum(world_areas),
            'max_panel_transformed_area_error_m2': max_panel_world_area_error,
            'uncovered_projection_m2': uncovered, 'outside_projection_m2': outside,
            'overlap_projection_m2': overlap,
            'source_facet_uncovered_projection_m2': facet_gap,
            'source_facet_outside_projection_m2': facet_outside,
            'source_facet_overlap_projection_m2': facet_overlap,
            'max_recomputed_surface_width_m': maxw,
            'max_recomputed_surface_length_m': maxl,
            'max_recomputed_surface_u_m': maxu,
            'max_recomputed_surface_v_m': maxv,
            'max_world_surface_width_m': max_world_width,
            'max_world_surface_length_m': max_world_length,
            'max_world_surface_u_m': max_world_u,
            'max_world_surface_v_m': max_world_v,
            'max_world_planar_box_width_m': max_world_planar_width,
            'max_world_planar_box_length_m': max_world_planar_length,
            'max_published_width_m': max_stored_width,
            'max_published_length_m': max_stored_length,
            'min_published_width_m': min_published_width,
            'min_published_length_m': min_published_length,
            'min_mesh_edge_m': min_mesh_edge,
            'template_actual_width_below_500mm_count': below_minimum_pieces,
            'full_actual_width_below_500mm_count': below_minimum_pieces*len(transforms),
            'minimum_rule_scope': 'positive integer millimetres; 500mm is a reference statistic only, never an input minimum',
            'max_source_height_error_m': max_z_error,
            'max_source_uv_error': max_uv_error,
            'source_visible_edges_aligned_fraction': float(original_aligned.mean()),
            'source_uv_min_absolute_determinant': float(np.min(np.abs(index.uv_determinants))),
            'source_uv_orientation_consistent': True,
            'independent_rigid_shape_type_groups_checked': len(type_shapes),
            'panel_seams_aligned_to_fan_uv_fraction': aligned_seams/max(1, seam_edges),
            'max_internal_mesh_dihedral_deg': max_angle,
            'panels_crossing_retained_source_crease': panels_crossing_source_crease,
            'uv_four_sided_rectangle_panels': rectangle_panels,
            'uv_four_sided_rectangle_fraction': rectangle_panels/len(candidate['panels']),
            'center_region_v_limit': center_v_limit,
            'center_region_panels': center_panels,
            'center_region_four_sided_rectangle_panels': center_rectangles,
            'boundary_trim_panels': boundary_trim_panels,
            'center_region_boundary_trim_panels': center_boundary_trims,
            'center_interior_panels': center_interior_panels,
            'center_interior_four_sided_rectangle_panels': center_interior_rectangles,
            'center_interior_triangle_or_wedge_panels': center_interior_panels-center_interior_rectangles,
            'max_original_boundary_clip_symmetric_difference': max_original_boundary_clip_residual,
            'max_uv_rectangle_symmetric_difference': max_rectangle_uv_residual,
            'rectangle_scope': 'four-sided source-UV surface rectangles; curved in XYZ, not flat Euclidean fabrication blanks',
            'template_triangles': triangle_count,
            'validation_elapsed_seconds': time.perf_counter()-started,
            'generation': data.get('validation_generation'),
        }
        results.append(result)
        print(json.dumps(result, ensure_ascii=False), flush=True)
    return {'format': 'roof-panel-dynamic-validation-6', 'all_passed': True,
            'candidates': results,
            'manufacturing_status': 'design-study-only; no flat blank development, seam deduction, support or thickness calculation'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data', type=Path, required=True)
    parser.add_argument('--source', type=Path, default=ROOT/'modelData.json')
    parser.add_argument('--output', type=Path, default=ROOT/'geometry_validation.json')
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    try:
        source_path = args.source
        if not source_path.exists() and args.source == ROOT/'modelData.json':
            source_path = ROOT.parent/'roof-panel-studio-v3'/'modelData.json'
        source = json.loads(source_path.read_text())
        data = json.loads(args.data.read_text())
        report = validate(source, data)
    except Exception as error:
        report = {'format': 'roof-panel-dynamic-validation-6', 'all_passed': False,
                  'error': str(error), 'error_type': type(error).__name__}
        args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2))
        raise
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2))
    print('PASS: independent V6 dynamic geometry checks', flush=True)


if __name__ == '__main__':
    main()
