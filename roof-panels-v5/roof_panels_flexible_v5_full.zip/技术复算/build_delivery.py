"""Build the fully embedded adjustable V5 app and offline Blob Worker."""
from pathlib import Path
import base64,gzip,json,hashlib
ROOT=Path(__file__).resolve().parent

def build():
    data=json.loads((ROOT/'default-study.json').read_text())
    data['layout'].update(type='exact-source-curvilinear-fan',description='沿原屋面放射曲线独立输入长宽，可选锁定自定义比例')
    data['format']='roof-panel-study-1'
    data['sizing_rule']={'mode':'free','min_width_mm':500,'max_width_mm':1500,'ratio_locked':False,'ratio':None,'default_width_mm':1000,'default_length_mm':3000}
    model=json.loads((ROOT/'modelData.json').read_text())
    model['variants']={'0':model['variants']['0']}
    compressed={
        'panelData':gzip.compress(json.dumps(data,ensure_ascii=False,separators=(',',':')).encode(),mtime=0),
        'modelData':gzip.compress(json.dumps(model,separators=(',',':')).encode(),mtime=0),
        'contextData':(ROOT/'context_lite.bin.gz').read_bytes(),
    }
    raw={'workerData':(ROOT/'panel-worker.js').read_bytes(),'bridgeData':(ROOT/'sketchup_bridge.rb').read_bytes()}
    blocks=[]
    for name,value in {**compressed,**raw}.items():
        blocks.append('<script type="application/octet-stream" id="'+name+'">'+base64.b64encode(value).decode()+'</script>')
    template=(ROOT/'app.template.html.txt').read_text()
    assert template.count('<!-- EMBED_DATA -->')==1
    assert template.count('/* RENDERER_V5 */')==1
    html=template.replace('<!-- EMBED_DATA -->','\n'.join(blocks)).replace('/* RENDERER_V5 */',(ROOT/'renderer-v5.js').read_text())
    assert '<!-- EMBED_DATA -->' not in html
    for name in [*compressed,*raw]:assert html.count('id="'+name+'"')==1
    for name in ['app.html','roof_panels_flexible_v5.html','1102e_V5可调尺寸工作台.html']:
        p=ROOT/name;p.write_text(html,encoding='utf-8');print(p,p.stat().st_size)
    (ROOT/'build_manifest.json').write_text(json.dumps({'worker_sha256':hashlib.sha256(raw['workerData']).hexdigest(),'html_sha256':hashlib.sha256(html.encode()).hexdigest(),'default_width_mm':1000,'default_length_mm':3000},indent=2))

if __name__=='__main__':build()
