/* Offline, exact-source roof segmentation. No network or external libraries.
 * Constant U follows the supplied fan rays; constant V follows cross rows.
 * All new vertices are affine points on the original source triangles.
 * A nominal size is an upper bound, not an assertion that edge pieces are full.
 */
'use strict';

const EPS = 1e-10;
const CREASE_COS = Math.cos(10 * Math.PI / 180);
// This is a memory/work limit, not a fabrication dimension or aspect ratio.
const MAX_WORLD_PANELS = 500000;
const RESOURCE_ERROR = '尺寸过小，预计板块过多；请增大尺寸后重新计算（单次最多 500,000 块实例板）';
const round = (n, digits) => { const s = 10 ** digits; return Math.round(n * s) / s; };
const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const norm = a => Math.hypot(a[0], a[1], a[2]);
const normalize = a => { const n = norm(a); return n > 0 ? a.map(x => x / n) : [0, 0, 1]; };
const area3 = (a, b, c) => norm(cross(sub(b, a), sub(c, a))) * .5;
const uvKey = p => `${Math.round(p[0] * 1e10)},${Math.round(p[1] * 1e10)}`;

function polygonArea(poly) {
  let a = 0;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) a += poly[j][0] * poly[i][1] - poly[i][0] * poly[j][1];
  return Math.abs(a) * .5;
}

function clipSide(poly, axis, bound, above) {
  if (poly.length < 3) return [];
  const out = [], sign = above ? 1 : -1;
  let a = poly[poly.length - 1], da = (a[axis] - bound) * sign;
  for (const b of poly) {
    const db = (b[axis] - bound) * sign;
    if ((da >= -EPS) !== (db >= -EPS)) {
      const t = da / (da - db), p = [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t];
      p[axis] = bound;
      out.push(p);
    }
    if (db >= -EPS) out.push(b);
    a = b; da = db;
  }
  const clean = [];
  for (const p of out) {
    const last = clean[clean.length - 1];
    if (!last || Math.hypot(p[0] - last[0], p[1] - last[1]) > EPS) clean.push(p);
  }
  if (clean.length > 1 && Math.hypot(clean[0][0] - clean[clean.length - 1][0], clean[0][1] - clean[clean.length - 1][1]) < EPS) clean.pop();
  return clean.length >= 3 ? clean : [];
}

function clipRect(poly, r) {
  let p = clipSide(poly, 0, r[0], true);
  p = clipSide(p, 0, r[2], false);
  p = clipSide(p, 1, r[1], true);
  return clipSide(p, 1, r[3], false);
}

function segmentIntersectsRect(a, b, r) {
  let lo = 0, hi = 1;
  for (let axis = 0; axis < 2; axis++) {
    const mn = r[axis], mx = r[axis + 2], d = b[axis] - a[axis];
    if (Math.abs(d) < 1e-12) {
      if (a[axis] < mn - EPS || a[axis] > mx + EPS) return false;
    } else {
      const p = (mn - a[axis]) / d, q = (mx - a[axis]) / d;
      lo = Math.max(lo, Math.min(p, q)); hi = Math.min(hi, Math.max(p, q));
    }
  }
  return hi - lo > 1e-9 && Math.hypot(b[0] - a[0], b[1] - a[1]) * (hi - lo) > 1e-9;
}

function lowerBound(a, value) {
  let lo = 0, hi = a.length;
  while (lo < hi) { const m = (lo + hi) >>> 1; if (a[m] < value) lo = m + 1; else hi = m; }
  return lo;
}
function upperBound(a, value) {
  let lo = 0, hi = a.length;
  while (lo < hi) { const m = (lo + hi) >>> 1; if (a[m] <= value) lo = m + 1; else hi = m; }
  return lo;
}

/* Full critical-angle search for fitting a fixed orthogonal stock rectangle.
 * Merely choosing the minimum-area hull-edge rectangle would miss diagonal fits.
 */
function feasibleRectangle(points, width, length) {
  const wLimit = width + 1e-8, lLimit = length + 1e-8;
  const angles = [0], pi = Math.PI, mod = a => ((a % pi) + pi) % pi;
  for (let i = 0; i < points.length; i++) for (let j = i + 1; j < points.length; j++) {
    const dx = points[j][0] - points[i][0], dy = points[j][1] - points[i][1], r = Math.hypot(dx, dy);
    if (r > Math.hypot(lLimit, wLimit) + 1e-10) return null;
    if (r < 1e-12) continue;
    const alpha = Math.atan2(dy, dx);
    angles.push(mod(alpha), mod(alpha + pi / 2));
    for (let k = 0; k < 2; k++) {
      const limit = k ? wLimit : lLimit;
      if (r > limit) {
        const center = alpha + (k ? pi / 2 : 0), delta = Math.acos(Math.min(1, Math.max(-1, limit / r)));
        angles.push(mod(center - delta), mod(center + delta));
      }
    }
  }
  angles.sort((a, b) => a - b);
  const candidates = angles.slice();
  for (let i = 0; i < angles.length; i++) candidates.push(mod((angles[i] + (i + 1 < angles.length ? angles[i + 1] : angles[0] + pi)) / 2));
  let best = null;
  for (const angle of candidates) {
    const c = Math.cos(angle), s = Math.sin(angle);
    let u0 = Infinity, u1 = -Infinity, v0 = Infinity, v1 = -Infinity;
    for (const p of points) {
      const u = p[0] * c + p[1] * s, v = -p[0] * s + p[1] * c;
      u0 = Math.min(u0, u); u1 = Math.max(u1, u); v0 = Math.min(v0, v); v1 = Math.max(v1, v);
    }
    const du = u1 - u0, dv = v1 - v0;
    if (du <= lLimit + 1e-10 && dv <= wLimit + 1e-10) {
      const short = Math.min(du, dv), long = Math.max(du, dv), axis = du >= dv ? angle : mod(angle + pi / 2);
      if (!best || short * long < best[0] * best[1] - 1e-14 || (Math.abs(short * long - best[0] * best[1]) < 1e-14 && short + long < best[0] + best[1])) best = [short, long, axis];
    }
  }
  return best;
}

/* Jacobi diagonalization of the symmetric 3x3 point covariance matrix. */
function planeBasis(points) {
  const mean = [0, 0, 0];
  for (const p of points) for (let k = 0; k < 3; k++) mean[k] += p[k] / points.length;
  const a = [[0, 0, 0], [0, 0, 0], [0, 0, 0]], v = [[1, 0, 0], [0, 1, 0], [0, 0, 1]];
  for (const p of points) {
    const d = sub(p, mean);
    for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++) a[i][j] += d[i] * d[j];
  }
  for (let iter = 0; iter < 32; iter++) {
    let p = 0, q = 1;
    if (Math.abs(a[0][2]) > Math.abs(a[p][q])) { p = 0; q = 2; }
    if (Math.abs(a[1][2]) > Math.abs(a[p][q])) { p = 1; q = 2; }
    if (Math.abs(a[p][q]) < 1e-16 * Math.max(1, Math.abs(a[0][0]) + Math.abs(a[1][1]) + Math.abs(a[2][2]))) break;
    const phi = .5 * Math.atan2(2 * a[p][q], a[q][q] - a[p][p]), c = Math.cos(phi), s = Math.sin(phi);
    const app = a[p][p], aqq = a[q][q], apq = a[p][q];
    for (let k = 0; k < 3; k++) if (k !== p && k !== q) {
      const akp = a[k][p], akq = a[k][q];
      a[k][p] = a[p][k] = c * akp - s * akq;
      a[k][q] = a[q][k] = s * akp + c * akq;
    }
    a[p][p] = c * c * app - 2 * s * c * apq + s * s * aqq;
    a[q][q] = s * s * app + 2 * s * c * apq + c * c * aqq;
    a[p][q] = a[q][p] = 0;
    for (let k = 0; k < 3; k++) {
      const vp = v[k][p], vq = v[k][q];
      v[k][p] = c * vp - s * vq; v[k][q] = s * vp + c * vq;
    }
  }
  const order = [0, 1, 2].sort((i, j) => a[j][j] - a[i][i]);
  const basis = order.map(i => normalize([v[0][i], v[1][i], v[2][i]]));
  let deviation = 0;
  for (const p of points) deviation = Math.max(deviation, Math.abs(dot(sub(p, mean), basis[2])) * 1000);
  return { mean, basis, deviation };
}

class NeedsSplit extends Error {
  constructor(message, axis = null) { super(message); this.axis = axis; }
}

class Study {
  constructor(model, progress) {
    this.p = model.vertices; this.f = model.faces; this.uv = model.uv;
    if (!Array.isArray(this.p) || !Array.isArray(this.f) || !Array.isArray(this.uv) || this.uv.length !== this.p.length || !this.f.length) throw new Error('原始屋面或参数网格不完整');
    for (const p of this.p) if (!Array.isArray(p) || p.length !== 3 || !p.every(Number.isFinite)) throw new Error('原始屋面坐标无效');
    for (const p of this.uv) if (!Array.isArray(p) || p.length !== 2 || !p.every(Number.isFinite)) throw new Error('原始屋面 UV 坐标无效');
    this.progress = progress || (() => {});
    this.instances = Array.isArray(model.instances) && model.instances.length ? model.instances : null;
    this.instanceCount = this.instances ? this.instances.length : Number.isInteger(model.instance_count) && model.instance_count > 0 ? model.instance_count : 8;
    this.cofactors = this.instances ? this.instances.map(instance => {
      const m = instance.matrix;
      if (!Array.isArray(m) || m.length !== 16 || !m.every(Number.isFinite)) throw new Error('屋面实例变换矩阵无效');
      const a = [m[0], m[1], m[2]], b = [m[4], m[5], m[6]], c = [m[8], m[9], m[10]];
      return [cross(b, c), cross(c, a), cross(a, b)];
    }) : null;
    this.info = []; this.adj = this.f.map(() => []); this.sharp = this.f.map(() => new Set()); this.sharpCount = 0; this.sourceArea = 0;
    this.umin = Infinity; this.umax = -Infinity; this.vmin = Infinity; this.vmax = -Infinity;
    const edges = new Map();
    for (const uv of this.uv) { this.umin = Math.min(this.umin, uv[0]); this.umax = Math.max(this.umax, uv[0]); this.vmin = Math.min(this.vmin, uv[1]); this.vmax = Math.max(this.vmax, uv[1]); }
    for (let fi = 0; fi < this.f.length; fi++) {
      const face = this.f[fi];
      if (!Array.isArray(face) || face.length !== 3 || !face.every(k => Number.isInteger(k) && k >= 0 && k < this.p.length)) throw new Error('原始三角面索引无效');
      const uv = face.map(k => this.uv[k]), xyz = face.map(k => this.p[k]);
      const a = uv[1][0] - uv[0][0], b = uv[2][0] - uv[0][0], c = uv[1][1] - uv[0][1], d = uv[2][1] - uv[0][1], det = a * d - b * c;
      if (det <= 1e-12) throw new Error('原始参数域三角面退化或方向错误');
      const e = sub(xyz[1], xyz[0]), g = sub(xyz[2], xyz[0]);
      const ju = e.map((x, k) => (x * d - g[k] * c) / det), jv = e.map((x, k) => (-x * b + g[k] * a) / det);
      const cr = cross(e, g), magnitude = norm(cr);
      if (!(magnitude > 1e-12) || !Number.isFinite(magnitude)) throw new Error('原始屋面存在退化三角面');
      const n = normalize(cr);
      if (n[2] < 0) for (let k = 0; k < 3; k++) n[k] *= -1;
      this.sourceArea += magnitude * .5;
      this.info.push({ ju, jv, nu: norm(ju), nv: norm(jv), n,
        lo: [Math.min(uv[0][0], uv[1][0], uv[2][0]), Math.min(uv[0][1], uv[1][1], uv[2][1])],
        hi: [Math.max(uv[0][0], uv[1][0], uv[2][0]), Math.max(uv[0][1], uv[1][1], uv[2][1])] });
      for (let j = 0; j < 3; j++) {
        const x = face[j], y = face[(j + 1) % 3], key = x < y ? `${x},${y}` : `${y},${x}`;
        if (edges.has(key)) {
          const owner = edges.get(key), other = owner.fi;
          if (owner.paired) throw new Error('原屋面存在非流形边');
          owner.paired = true;
          if (dot(n, this.info[other].n) >= CREASE_COS) {
            this.adj[fi].push([other, x, y]); this.adj[other].push([fi, x, y]);
          } else { this.sharp[fi].add(other); this.sharp[other].add(fi); this.sharpCount++; }
        } else edges.set(key, { fi, paired: false });
      }
    }
    this.sourceKnots = Array.from(new Set(this.uv.map(p => p[1]))).sort((a, b) => a - b);
    this.worldArea = this.computeWorldArea();
  }

  computeWorldArea() {
    if (!this.instances) return this.sourceArea * this.instanceCount;
    let area = 0;
    for (const instance of this.instances) {
      const m = instance.matrix;
      if (!Array.isArray(m) || m.length !== 16 || !m.every(Number.isFinite)) throw new Error('屋面实例变换矩阵无效');
      const p = this.p.map(q => [m[0] * q[0] + m[4] * q[1] + m[8] * q[2] + m[12], m[1] * q[0] + m[5] * q[1] + m[9] * q[2] + m[13], m[2] * q[0] + m[6] * q[1] + m[10] * q[2] + m[14]]);
      for (const f of this.f) area += area3(p[f[0]], p[f[1]], p[f[2]]);
    }
    return area;
  }

  lift(fi, uv) {
    const f0 = this.f[fi][0], origin = this.p[f0], chart = this.uv[f0], info = this.info[fi], u = uv[0] - chart[0], v = uv[1] - chart[1];
    return [origin[0] + info.ju[0] * u + info.jv[0] * v, origin[1] + info.ju[1] * u + info.jv[1] * v, origin[2] + info.ju[2] * u + info.jv[2] * v];
  }

  cuts(width, length) {
    const u = [this.umin];
    const knotSet = new Set([this.umin, this.umax]);
    for (const p of this.uv) if (Math.abs(p[0] - Math.round(p[0])) < 1e-8) knotSet.add(Math.round(p[0]));
    const knots = Array.from(knotSet).sort((a, b) => a - b);
    for (let i = 0; i + 1 < knots.length; i++) {
      const a = knots[i], b = knots[i + 1]; let max = 0;
      for (const t of this.info) if (t.hi[0] > a + 1e-8 && t.lo[0] < b - 1e-8) max = Math.max(max, t.nu);
      const n = Math.max(1, Math.ceil((b - a) * max / (width * .98)));
      for (let k = 1; k <= n; k++) u.push(a + (b - a) * k / n);
    }
    const v = [this.vmin]; let minNorm = Infinity;
    for (const t of this.info) minNorm = Math.min(minNorm, t.nv);
    while (v[v.length - 1] < this.vmax - 1e-9) {
      const start = v[v.length - 1]; let low = start, high = Math.min(this.vmax, start + length / minNorm);
      for (let k = 0; k < 45; k++) {
        const end = (low + high) / 2; let max = 0;
        for (const t of this.info) if (t.hi[1] > start + 1e-9 && t.lo[1] < end - 1e-9) max = Math.max(max, t.nv);
        if ((end - start) * max <= length * .98) low = end; else high = end;
      }
      let end = low > this.vmax - 1e-8 ? this.vmax : low;
      for (const knot of this.sourceKnots) if (Math.abs(knot - end) < 1e-7) { end = knot; break; }
      if (end - start < 1e-7) throw new Error('横向网格未推进');
      v.push(end);
      if ((u.length - 1) * (v.length - 1) * this.instanceCount > MAX_WORLD_PANELS) throw new Error(RESOURCE_ERROR);
    }
    return [u, v];
  }

  components(pieces, rect) {
    if (pieces.size < 2) return [pieces];
    const parent = new Map(), members = new Map();
    for (const fi of pieces.keys()) { parent.set(fi, fi); members.set(fi, new Set([fi])); }
    const find = f => { while (f !== parent.get(f)) { parent.set(f, parent.get(parent.get(f))); f = parent.get(f); } return f; };
    for (const fi of pieces.keys()) for (const [other, a, b] of this.adj[fi]) {
      if (other <= fi || !pieces.has(other) || !segmentIntersectsRect(this.uv[a], this.uv[b], rect)) continue;
      let x = find(fi), y = find(other); if (x === y) continue;
      let forbidden = false;
      for (const s of members.get(x)) { for (const t of this.sharp[s]) if (members.get(y).has(t)) { forbidden = true; break; } if (forbidden) break; }
      if (forbidden) continue;
      if (members.get(x).size > members.get(y).size) { const tmp = x; x = y; y = tmp; }
      parent.set(x, y); for (const s of members.get(x)) members.get(y).add(s); members.delete(x);
    }
    const groups = new Map();
    for (const [fi, poly] of pieces) { const root = find(fi); if (!groups.has(root)) groups.set(root, new Map()); groups.get(root).set(fi, poly); }
    return Array.from(groups.values());
  }

  outlines(polyIds, uv, vertices) {
    // Split at every component vertex before edge cancellation. This retains
    // real XYZ bends at collinear UV points and handles clipping T junctions.
    const edges = new Map();
    for (const ids of polyIds) for (let j = 0; j < ids.length; j++) {
      const ia = ids[j], ib = ids[(j + 1) % ids.length]; if (ia === ib) continue;
      const a = uv[ia], b = uv[ib], dx = b[0] - a[0], dy = b[1] - a[1], l2 = dx * dx + dy * dy;
      if (l2 < 1e-22) continue;
      const split = [[0, ia], [1, ib]];
      for (let k = 0; k < uv.length; k++) if (k !== ia && k !== ib) {
        const p = uv[k], t = ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / l2;
        if (t > 1e-9 && t < 1 - 1e-9 && Math.abs(dx * (p[1] - a[1]) - dy * (p[0] - a[0])) <= 2e-9 * Math.sqrt(l2)) split.push([t, k]);
      }
      split.sort((x, y) => x[0] - y[0]);
      for (let k = 0; k + 1 < split.length; k++) {
        const x = split[k][1], y = split[k + 1][1]; if (x === y) continue;
        const key = x < y ? `${x},${y}` : `${y},${x}`;
        if (edges.has(key)) {
          const old = edges.get(key);
          if (old[0] !== y || old[1] !== x) throw new NeedsSplit('非流形板块边界');
          edges.delete(key);
        } else edges.set(key, [x, y]);
      }
    }
    const outgoing = new Map();
    for (const edge of edges.values()) {
      if (outgoing.has(edge[0])) throw new NeedsSplit('板块边界连接歧义');
      outgoing.set(edge[0], edge[1]);
    }
    const rings = [];
    while (outgoing.size) {
      const start = outgoing.keys().next().value, ring = []; let next = start, guard = 0;
      do {
        if (!outgoing.has(next) || ++guard > edges.size + 1) throw new NeedsSplit('板块边界未闭合');
        ring.push(next); const after = outgoing.get(next); outgoing.delete(next); next = after;
      } while (next !== start);
      if (ring.length < 3) throw new NeedsSplit('板块边界退化');
      let signed = 0; for (let i = 0; i < ring.length; i++) { const a = uv[ring[i]], b = uv[ring[(i + 1) % ring.length]]; signed += a[0] * b[1] - b[0] * a[1]; }
      rings.push({ ring, signed });
    }
    rings.sort((a, b) => Math.abs(b.signed) - Math.abs(a.signed));
    if (!rings.length || rings[0].signed <= 0 || rings.slice(1).some(r => r.signed > 1e-12)) throw new NeedsSplit('板块不是单一连通区域');
    return rings.map(r => r.ring.map(i => vertices[i].map(x => round(x, 9))));
  }

  makePanel(pieces, grid, rect, width, length) {
    const vertices = [], uv = [], faces = [], lookup = new Map(), used = new Set(), polyIds = [];
    for (const [fi, poly] of pieces) {
      const ids = [];
      for (const p of poly) {
        const key = uvKey(p); let id = lookup.get(key);
        if (id === undefined) { id = vertices.length; lookup.set(key, id); vertices.push(this.lift(fi, p)); uv.push(p); }
        if (!ids.length || id !== ids[ids.length - 1]) ids.push(id);
      }
      if (ids.length > 1 && ids[0] === ids[ids.length - 1]) ids.pop();
      let hasFace = false;
      for (let i = 1; i + 1 < ids.length; i++) {
        const a = ids[0], b = ids[i], c = ids[i + 1];
        if (area3(vertices[a], vertices[b], vertices[c]) > 1e-11) { faces.push([a, b, c]); used.add(fi); hasFace = true; }
      }
      if (hasFace) polyIds.push(ids);
    }
    if (!faces.length) return null;
    let area = 0;
    const worldAreas = this.cofactors ? this.cofactors.map(() => 0) : null;
    for (const f of faces) {
      const cr = cross(sub(vertices[f[1]], vertices[f[0]]), sub(vertices[f[2]], vertices[f[0]]));
      area += norm(cr) * .5;
      if (worldAreas) for (let i = 0; i < this.cofactors.length; i++) {
        const c = this.cofactors[i];
        worldAreas[i] += Math.hypot(c[0][0] * cr[0] + c[1][0] * cr[1] + c[2][0] * cr[2], c[0][1] * cr[0] + c[1][1] * cr[1] + c[2][1] * cr[2], c[0][2] * cr[0] + c[1][2] * cr[1] + c[2][2] * cr[2]) * .5;
      }
    }
    if (area < 1e-10) return null;
    let u0 = Infinity, v0 = Infinity, u1 = -Infinity, v1 = -Infinity, nu = 0, nv = 0;
    for (const p of uv) { u0 = Math.min(u0, p[0]); v0 = Math.min(v0, p[1]); u1 = Math.max(u1, p[0]); v1 = Math.max(v1, p[1]); }
    for (const fi of used) { nu = Math.max(nu, this.info[fi].nu); nv = Math.max(nv, this.info[fi].nv); }
    const du = (u1 - u0) * nu, dv = (v1 - v0) * nv, sw = Math.min(du, dv), sl = Math.max(du, dv);
    // The user-facing width and length control U and V independently. Sorting
    // only belongs to reported short/long dimensions, never to the grid axes.
    if (du > width - 1e-7 || dv > length - 1e-7) throw new NeedsSplit('曲面路径尺寸', du / width >= dv / length ? 0 : 1);
    const shortLimit = Math.min(width, length), longLimit = Math.max(width, length);
    const fit = planeBasis(vertices), planar = fit.deviation < .001;
    const panel = { id: '', type_id: '', vertices: vertices.map(p => p.map(x => round(x, 9))), uv_vertices: uv.map(p => p.map(x => round(x, 12))), faces,
      area_m2: area, width_m: round(sw, 9), length_m: round(sl, 9),
      world_areas_m2: worldAreas || Array(this.instanceCount).fill(area),
      surface_width_bound_m: round(sw, 9), surface_length_bound_m: round(sl, 9),
      surface_u_bound_m: round(du, 9), surface_v_bound_m: round(dv, 9),
      kind: planar ? 'planar' : 'curved_mesh', nonplanarity_mm: round(fit.deviation, 6),
      source_face_ids: Array.from(used).sort((a, b) => a - b), source_face_count: used.size, grid: grid.slice(),
      uv_bounds: rect.map(x => round(x, 12)), dimension_method: 'source_uv_jacobian_surface_path_bound' };
    if (planar) {
      const projected = vertices.map(p => { const d = sub(p, fit.mean); return [dot(d, fit.basis[0]), dot(d, fit.basis[1])]; });
      const box = feasibleRectangle(projected, shortLimit - 1e-6, longLimit - 1e-6);
      if (!box) throw new NeedsSplit('平面矩形包络', du >= dv ? 0 : 1);
      const [bw, bl, angle] = box, c = Math.cos(angle), s = Math.sin(angle), a = fit.basis[0], b = fit.basis[1];
      panel.planar_box_width_m = round(bw, 9); panel.planar_box_length_m = round(bl, 9);
      panel.planar_box_axes = [a.map((x, k) => x * c + b[k] * s), a.map((x, k) => -x * s + b[k] * c)];
      panel.width_m = Math.max(panel.width_m, panel.planar_box_width_m); panel.length_m = Math.max(panel.length_m, panel.planar_box_length_m);
      panel.dimension_method = 'max_source_uv_path_and_feasible_orthogonal_planar_box';
    }
    panel.outlines = this.outlines(polyIds, uv, vertices);
    return panel;
  }

  solve(widthMm, lengthMm) {
    const width = widthMm / 1000, length = lengthMm / 1000;
    // Even an ideal W×L panel cannot cover more than W*L of the source surface.
    // Reject infeasible memory requests before allocating millions of cuts.
    if (Math.ceil(this.sourceArea / (width * length)) * this.instanceCount > MAX_WORLD_PANELS) throw new Error(RESOURCE_ERROR);
    const [uc, vc] = this.cuts(width, length), nv = vc.length - 1;
    const cells = new Map();
    this.progress({ stage: 'grid', progress: 4, message: `生成 ${uc.length - 1} 条放射分带 × ${nv} 道随形横带` });
    for (let fi = 0; fi < this.f.length; fi++) {
      const tri = this.f[fi].map(k => this.uv[k]), info = this.info[fi];
      const i0 = Math.max(0, upperBound(uc, info.lo[0]) - 1), i1 = Math.min(uc.length - 2, lowerBound(uc, info.hi[0]));
      const j0 = Math.max(0, upperBound(vc, info.lo[1]) - 1), j1 = Math.min(nv - 1, lowerBound(vc, info.hi[1]));
      for (let i = i0; i <= i1; i++) for (let j = j0; j <= j1; j++) {
        const poly = clipRect(tri, [uc[i], vc[j], uc[i + 1], vc[j + 1]]);
        if (poly.length && polygonArea(poly) > 1e-12) {
          const key = i * nv + j;
          if (!cells.has(key)) cells.set(key, new Map());
          cells.get(key).set(fi, poly);
        }
      }
      if (fi % 128 === 0) this.progress({ stage: 'clipping', progress: 5 + Math.round(fi / this.f.length * 15), message: '裁切原始曲面三角片' });
    }
    const panels = []; let refinements = 0, uRefinements = 0, vRefinements = 0;
    const refine = (pieces, rect, grid, depth = 0) => {
      for (const component of this.components(pieces, rect)) {
        try {
          const p = this.makePanel(component, grid, rect, width, length);
          if (p) {
            if ((panels.length + 1) * this.instanceCount > MAX_WORLD_PANELS) throw new Error(RESOURCE_ERROR);
            panels.push(p);
          }
        }
        catch (e) {
          if (!(e instanceof NeedsSplit)) throw e;
          if (depth >= 12) throw new Error(`板块深化无法满足尺寸或边界校核：${e.message}，网格 ${grid}`);
          const axis = e.axis === 0 || e.axis === 1 ? e.axis : (depth % 2 ? 0 : 1);
          refinements++; if (axis === 0) uRefinements++; else vRefinements++;
          const mid = (rect[axis] + rect[axis + 2]) / 2, a = rect.slice(), b = rect.slice();
          a[axis + 2] = mid; b[axis] = mid;
          for (const child of [a, b]) {
            const sub = new Map();
            for (const [fi, p] of component) { const poly = clipRect(p, child); if (poly.length && polygonArea(poly) > 1e-12) sub.set(fi, poly); }
            if (sub.size) refine(sub, child, grid, depth + 1);
          }
        }
      }
    };
    const keys = Array.from(cells.keys()).sort((a, b) => a - b); let done = 0;
    for (const key of keys) {
      const i = Math.floor(key / nv), j = key % nv;
      refine(cells.get(key), [uc[i], vc[j], uc[i + 1], vc[j + 1]], [i, j]);
      if (++done % 100 === 0) this.progress({ stage: 'panels', progress: 20 + Math.round(done / keys.length * 72), message: `校核板块 ${done.toLocaleString()} / ${keys.length.toLocaleString()}` });
    }
    // Each distinct template location is conservatively a separate fabrication
    // family. All eight exact repeated instances reuse that family's geometry;
    // curved mirror instances are labelled as separate handed types in the UI.
    const types = []; let area = 0, maxW = 0, maxL = 0, maxSW = 0, maxSL = 0, maxSU = 0, maxSV = 0, maxDev = 0, minArea = Infinity, curved = 0, triangleCount = 0, small = 0, edgePieces = 0;
    for (let i = 0; i < panels.length; i++) {
      const p = panels[i], id = String(i + 1).padStart(5, '0');
      p.id = `P${id}`; p.type_id = `T${widthMm}x${lengthMm}-${id}`;
      types.push({ id: p.type_id, representative: p.id, width_m: p.width_m, length_m: p.length_m, area_m2: p.area_m2, kind: p.kind,
        nonplanarity_mm: p.nonplanarity_mm, template_count: 1, handed: p.kind === 'curved_mesh',
        shape_signature: `source-grid-${widthMm}x${lengthMm}-${i + 1}` });
      area += p.area_m2; maxW = Math.max(maxW, p.width_m); maxL = Math.max(maxL, p.length_m); maxSW = Math.max(maxSW, p.surface_width_bound_m); maxSL = Math.max(maxSL, p.surface_length_bound_m);
      maxSU = Math.max(maxSU, p.surface_u_bound_m); maxSV = Math.max(maxSV, p.surface_v_bound_m);
      maxDev = Math.max(maxDev, p.nonplanarity_mm); minArea = Math.min(minArea, p.area_m2); curved += p.kind === 'curved_mesh' ? 1 : 0; triangleCount += p.faces.length;
      if (p.area_m2 < .05) small++; if (p.width_m < .5 - 1e-9) edgePieces++;
    }
    if (Math.abs(area - this.sourceArea) > 1e-5) throw new Error(`原始屋面面积守恒校核未通过：${area - this.sourceArea} m²`);
    const n = this.instanceCount, summary = { template_panel_count: panels.length, panel_count: panels.length * n, type_count: types.length,
      handed_type_count: types.length + curved, surface_area_m2: this.worldArea, template_surface_area_m2: area, area_error_m2: area - this.sourceArea,
      max_width_m: maxW, max_length_m: maxL, max_nonplanarity_mm: maxDev, min_panel_area_m2: minArea,
      max_surface_width_bound_m: maxSW, max_surface_length_bound_m: maxSL,
      max_surface_u_bound_m: maxSU, max_surface_v_bound_m: maxSV,
      curved_panel_count: curved * n, planar_panel_count: (panels.length - curved) * n, triangle_count: triangleCount * n,
      small_panel_count: small * n, below_500mm_panel_count: edgePieces * n, crease_edge_count_per_template: this.sharpCount,
      repeat_ratio: 1 - types.length / (panels.length * n), transverse_local_refinements: refinements * n,
      nominal_width_mm: widthMm, nominal_length_mm: lengthMm,
      selected_nominal_width_mm: widthMm, selected_nominal_length_mm: lengthMm,
      selected_max_width_m: Math.min(width, length), selected_max_length_m: Math.max(width, length),
      selected_max_u_m: width, selected_max_v_m: length,
      u_local_refinements: uRefinements * n, v_local_refinements: vRefinements * n, max_world_panel_count: MAX_WORLD_PANELS,
      family_grouping: 'conservative_exact_source_template_location', dimension_grouping_is_geometry_identity: false };
    this.progress({ stage: 'complete', progress: 100, message: `完成 ${summary.panel_count.toLocaleString()} 块铝板的几何与面积校核` });
    return { id: `fan-${widthMm}x${lengthMm}`, name: `连续放射 · ${widthMm} × ${lengthMm}`, nominal_width_m: width, nominal_length_m: length,
      panels, types, summary, grid: { u_cuts: uc, v_cuts: vc, transverse_local_refinements: refinements,
        u_local_refinements: uRefinements, v_local_refinements: vRefinements } };
  }
}

function generate(data, progress) {
  if (!data || !Number.isInteger(data.widthMm) || data.widthMm < 500 || data.widthMm > 1500) throw new Error('宽度必须是 500–1500 mm 之间的整数');
  if (!Number.isInteger(data.lengthMm) || data.lengthMm < 1 || data.lengthMm > 1e9) throw new Error('长度必须是大于 0 且不超过 1,000,000,000 mm 的整数');
  return new Study(data.model || {}, progress).solve(data.widthMm, data.lengthMm);
}

if (typeof self !== 'undefined' && typeof self.postMessage === 'function') {
  self.onmessage = event => {
    const data = event.data || {}; if (data.type !== 'generate') return;
    try {
      const candidate = generate(data, p => self.postMessage({ type: 'progress', requestId: data.requestId, ...p }));
      self.postMessage({ type: 'result', requestId: data.requestId, candidate });
    } catch (error) { self.postMessage({ type: 'error', requestId: data.requestId, message: error && error.message ? error.message : String(error) }); }
  };
}
if (typeof module !== 'undefined' && module.exports) module.exports = { generate, Study, feasibleRectangle, planeBasis, clipRect };
