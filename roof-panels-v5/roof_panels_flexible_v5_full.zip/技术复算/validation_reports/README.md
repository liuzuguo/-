# V5 独立几何校核

使用真实网页 Worker 在 Node VM 中生成网格，Python 校核器独立读取原始曲面、UV 与输出网格，不调用生成算法。

校核包括：原始三角片及 UV 溯源、逐原始面覆盖无缺面和重叠、放射网格走向、U 方向不超过所输入宽度、V 方向不超过所输入长度、排序后的几何短边和长边限制、平面正交包络、内部折角不超过 10°、全部 8 个实例的真实三维面积、逐板面积及板型数量统计、独立长宽及自定义比例元数据。

| 宽度 mm | 长度 mm | 模式 | 报告 |
| --- | --- | --- | --- |
| 500 | 1500 | 自由输入 | 500x1500_report.json |
| 1000 | 6000 | 自由输入 | 1000x6000_report.json |
| 873 | 2222 | 自由输入 | 873x2222_report.json |
| 1200 | 800 | 自由输入，长度小于宽度 | 1200x800_report.json |
| 1000 | 4200 | 锁定长/宽比例 4.2 | 1000x4200-ratio_report.json |

复现示例（在本目录的上一级执行）：

```bash
node worker_generate.mjs --width 873 --length 2222 --output /tmp/v5-873x2222.json
python validate_dynamic_geometry.py --data /tmp/v5-873x2222.json --output validation_reports/873x2222_report.json
node worker_generate.mjs --width 1000 --ratio 4.2 --output /tmp/v5-1000x4200.json
python validate_dynamic_geometry.py --data /tmp/v5-1000x4200.json --output validation_reports/1000x4200-ratio_report.json
```

500 mm 是名义输入宽度下限；在边界和折线裁切后，实际局部小板可以小于 500 mm。6000 mm 长板和长度小于宽度的方案也按所输入方向校核。此处报告为几何及统计校核，不包含加工展开、接缝扣减、厚度或支撑结构计算。SketchUp 原生导入需在 SketchUp 中执行，当前云环境没有 SketchUp 运行时。
