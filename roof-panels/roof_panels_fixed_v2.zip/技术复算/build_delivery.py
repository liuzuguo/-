"""Build the self-contained offline viewer from validated geometry."""
import base64, gzip, json
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def build():
    model = json.loads((ROOT / 'modelData.json').read_text())
    model['variants'] = {'0': model['variants']['0']}
    blobs = {
        'panelData': gzip.compress((ROOT / 'panels.json').read_bytes(), mtime=0),
        'modelData': gzip.compress(json.dumps(model,separators=(',',':')).encode(), mtime=0),
        'contextData': (ROOT / 'context_lite.bin.gz').read_bytes(),
    }
    embed = '\n'.join('<script type="application/octet-stream" id="'+key+'">'+base64.b64encode(value).decode()+'</script>' for key,value in blobs.items())
    bridge = base64.b64encode((ROOT / 'sketchup_bridge.rb').read_bytes()).decode()
    embed += '\n<script type="application/octet-stream" id="bridgeData">'+bridge+'</script>'
    template = (ROOT / 'app.template.html.txt').read_text()
    if template.count('<!-- EMBED_DATA -->') != 1:
        raise ValueError('Source template must contain exactly one data placeholder')
    html = template.replace('<!-- EMBED_DATA -->', embed)
    assert '<!-- EMBED_DATA -->' not in html
    for key in blobs:
        assert html.count('id="'+key+'"') == 1
    # Every file a user can open is a complete runnable application.
    for name in ['app.html', '1102e_屋面铝板分隔工作台.html']:
        out = ROOT / name
        out.write_text(html, encoding='utf-8')
        print(out, out.stat().st_size)

if __name__ == '__main__':
    build()
