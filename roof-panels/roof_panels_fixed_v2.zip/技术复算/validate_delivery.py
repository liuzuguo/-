"""Validate distributable offline HTML files inside a ZIP, not source templates.

Usage: python3 validate_delivery.py releases/roof_panels_fixed_v2.zip
This verifies package/data integrity only; it does not prove download delivery,
browser rendering, SketchUp execution, or fabrication suitability.
"""
from __future__ import annotations

import argparse
import array
import base64
import gzip
import hashlib
import json
import math
import re
import sys
import zipfile
from datetime import datetime, timezone
from html.parser import HTMLParser
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parent
PAYLOADS = ("panelData", "modelData", "contextData", "bridgeData")


def require(condition, message):
    if not condition:
        raise ValueError(message)


class Scripts(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=False)
        self.nodes = {name: [] for name in PAYLOADS}
        self.active = None
        self.external_resources = []

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == "script":
            if attrs.get("src"):
                self.external_resources.append(attrs["src"])
            name = attrs.get("id")
            if name in self.nodes:
                self.nodes[name].append([])
                self.active = self.nodes[name][-1]
        elif tag == "link" and attrs.get("href"):
            self.external_resources.append(attrs["href"])

    def handle_data(self, text):
        if self.active is not None:
            self.active.append(text)

    def handle_endtag(self, tag):
        if tag == "script":
            self.active = None


def finite(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def vector(value, size, label):
    require(isinstance(value, list) and len(value) == size and all(map(finite, value)),
            f"{label}: expected {size} finite numbers")


def mesh(vertices, faces, label):
    require(isinstance(vertices, list) and len(vertices) >= 3, f"{label}: missing vertices")
    for point in vertices:
        vector(point, 3, label + " vertex")
    require(isinstance(faces, list) and len(faces) > 0, f"{label}: missing triangles")
    for face in faces:
        require(isinstance(face, list) and len(face) == 3 and len(set(face)) == 3
                and all(isinstance(i, int) and not isinstance(i, bool) and 0 <= i < len(vertices)
                        for i in face), f"{label}: invalid triangle indices")


def validate_panel_data(data):
    require(isinstance(data, dict) and data.get("format") == "roof-panel-study-1",
            "panelData: wrong format")
    require(data.get("unit") == "m", "panelData: unit must be m")
    require(data.get("max_width_m") == 1.5 and data.get("max_length_m") == 3,
            "panelData: wrong dimensional limits")
    instances = data.get("instances")
    require(isinstance(instances, list) and len(instances) == 8, "panelData: expected 8 instances")
    for instance in instances:
        vector(instance.get("matrix"), 16, "panelData instance transform")
    candidates = data.get("candidates")
    require(isinstance(candidates, list) and len(candidates) > 0, "panelData: no candidates")
    ids = [candidate.get("id") for candidate in candidates]
    require(len(set(ids)) == len(ids) and all(isinstance(i, str) and i for i in ids),
            "panelData: invalid candidate IDs")
    require(data.get("recommended_id") in ids, "panelData: recommendation not found")
    counts = {}
    for candidate in candidates:
        panels = candidate.get("panels")
        require(isinstance(panels, list) and panels, "panelData: empty panel list")
        panel_ids = set()
        type_ids = {item.get("id") for item in candidate.get("types", [])}
        require(type_ids, "panelData: no panel types")
        for panel in panels:
            label = f"panelData {candidate['id']} {panel.get('id')}"
            require(isinstance(panel.get("id"), str) and panel["id"] not in panel_ids,
                    label + ": missing or duplicate ID")
            panel_ids.add(panel["id"])
            require(panel.get("type_id") in type_ids, label + ": unknown panel type")
            for key, maximum in (("width_m", 1.5), ("length_m", 3.0)):
                require(finite(panel.get(key)) and 0 < panel[key] <= maximum + 1e-7,
                        label + ": invalid " + key)
            require(finite(panel.get("area_m2")) and panel["area_m2"] > 0,
                    label + ": invalid area")
            mesh(panel.get("vertices"), panel.get("faces"), label)
        summary = candidate.get("summary", {})
        require(summary.get("template_panel_count") == len(panels),
                "panelData: template panel count mismatch")
        require(summary.get("panel_count") == len(panels) * len(instances),
                "panelData: full panel count mismatch")
        counts[candidate["id"]] = summary["panel_count"]
    return {"format": data["format"], "candidate_count": len(candidates),
            "recommended_id": data["recommended_id"], "full_panel_counts": counts}


def validate_payloads(nodes):
    raw = {}
    for name in PAYLOADS:
        payload = "".join(nodes[name][0]).strip()
        require(payload, f"{name}: empty payload")
        try:
            encoded = base64.b64decode(payload, validate=True)
            # The bridge is raw base64 UTF-8 Ruby; the geometry payloads are gzip.
            raw[name] = encoded if name == "bridgeData" else gzip.decompress(encoded)
        except Exception as error:
            raise ValueError(f"{name}: invalid base64 or gzip payload: {error}") from error
    panels = json.loads(raw["panelData"])
    panel_summary = validate_panel_data(panels)
    model = json.loads(raw["modelData"])
    require(isinstance(model, dict) and isinstance(model.get("variants"), dict)
            and "0" in model["variants"], "modelData: original roof variant missing")
    mesh(model["variants"]["0"].get("vertices"), model["variants"]["0"].get("faces"),
         "modelData original roof")
    require(isinstance(model.get("instances"), list) and len(model["instances"]) == 8,
            "modelData: expected 8 instances")
    for instance in model["instances"]:
        vector(instance.get("matrix"), 16, "modelData instance transform")
    vector(model.get("center"), 3, "modelData center")
    require(finite(model.get("targetZ")), "modelData: invalid target height")
    require(len(raw["contextData"]) > 0 and len(raw["contextData"]) % 108 == 0,
            "contextData: expected triangles with 3 vertices x 9 float32 values")
    context = array.array("f")
    context.frombytes(raw["contextData"])
    if sys.byteorder != "little":
        context.byteswap()
    require(all(map(math.isfinite, context)), "contextData: nonfinite values")
    bridge = raw["bridgeData"].decode("utf-8")
    for token in ("module RoofPanelBridge", "require 'sketchup.rb'", "def import_panels",
                  "def export_selected", "roof-panels-1"):
        require(token in bridge, "bridgeData: expected Ruby bridge content missing: " + token)
    return {"decoded_bytes": {name: len(value) for name, value in raw.items()},
            "panel_data": panel_summary, "source_roof_triangles": len(model["variants"]["0"]["faces"]),
            "context_triangles": len(raw["contextData"]) // 108,
            "bridge_encoding": "base64 raw UTF-8 Ruby; geometry payloads use base64 gzip"}


def validate_zip(path):
    report = {"format": "roof-panel-delivery-validation-1", "all_passed": False,
              "validated_at_utc": datetime.now(timezone.utc).isoformat(),
              "zip_path": str(path.resolve()), "html_files": [],
              "scope": "Local ZIP integrity only; platform download delivery is unconfirmed"}
    with zipfile.ZipFile(path) as package:
        require(package.testzip() is None, "ZIP CRC validation failed")
        names = package.namelist()
        require(len(names) == len(set(names)), "ZIP contains duplicate member paths")
        for name in names:
            member = PurePosixPath(name)
            require(not member.is_absolute() and ".." not in member.parts and "\\" not in name,
                    "Unsafe ZIP member path: " + name)
        html_names = [name for name in names if name.lower().endswith((".html", ".htm"))]
        require(html_names, "ZIP contains no runnable HTML")
        digests = set()
        decoded = None
        for name in html_names:
            require("template" not in PurePosixPath(name).name.lower(),
                    "Source template has a runnable HTML extension: " + name)
            content = package.read(name)
            html = content.decode("utf-8-sig")
            require("EMBED_DATA" not in html, "Unprocessed data placeholder in " + name)
            parsed = Scripts()
            parsed.feed(html)
            require(not parsed.external_resources, "External resources in offline HTML " + name)
            for payload in PAYLOADS:
                require(len(parsed.nodes[payload]) == 1,
                        f"{name}: expected exactly one {payload} node; found {len(parsed.nodes[payload])}")
            digest = hashlib.sha256(content).hexdigest()
            if decoded is None:
                decoded = validate_payloads(parsed.nodes)
            # Every runnable alias must be byte-identical; one decoded data check
            # therefore covers all aliases without silently accepting stale data.
            digests.add(digest)
            report["html_files"].append({"path": name, "bytes": len(content),
                                         "sha256": digest, "embedded_nodes": len(PAYLOADS)})
        require(len(digests) == 1, "Runnable HTML aliases are not byte-identical")
        report.update({"all_passed": True, "zip_member_count": len(names),
                       "runnable_html_count": len(html_names), "html_aliases_identical": True,
                       "payload_validation": decoded})
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("zip_path", type=Path)
    parser.add_argument("--output", type=Path, default=ROOT / "delivery_validation.json")
    args = parser.parse_args()
    try:
        report = validate_zip(args.zip_path)
    except Exception as error:
        report = {"format": "roof-panel-delivery-validation-1", "all_passed": False,
                  "zip_path": str(args.zip_path.resolve()), "error": str(error),
                  "scope": "Local ZIP integrity only; platform download delivery is unconfirmed"}
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    if report["all_passed"]:
        data = report["payload_validation"]
        print(f"PASS: {report['zip_member_count']} ZIP members, "
              f"{report['runnable_html_count']} complete identical HTML file(s), "
              f"{data['panel_data']['candidate_count']} candidates, "
              f"{data['context_triangles']} context triangles; report: {args.output}")
    else:
        print("FAIL:", report["error"], file=sys.stderr)
        raise SystemExit(1)


if __name__ == "__main__":
    main()
