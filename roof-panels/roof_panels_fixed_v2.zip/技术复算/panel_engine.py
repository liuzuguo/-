"""Roof panel design study: preserve source mesh; bound surface paths, never XY-only sizes.
The panels are mesh patches, not manufacturing-ready flat developments.
"""
from __future__ import annotations
import collections, hashlib, json, math, sys, time
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent/'vendor'))
from shapely.geometry import Polygon
from shapely.ops import unary_union
from shapely.strtree import STRtree
from planar_rectangle import feasible_rectangle

ROOT=Path(__file__).resolve().parent
ANGLE_DEG=10.0
EPS=1e-8

def clip(poly, axis, bound, above):
    if not poly:return []
    out=[]
    p=poly[-1];dp=(p[axis]-bound)*(1 if above else -1)
    for q in poly:
        dq=(q[axis]-bound)*(1 if above else -1)
        if (dp>=-1e-10)!=(dq>=-1e-10):
            t=dp/(dp-dq)
            out.append(p+(q-p)*t)
        if dq>=-1e-10:out.append(q)
        p,dp=q,dq
    clean=[]
    for p in out:
        if not clean or np.linalg.norm(p-clean[-1])>1e-8:clean.append(p)
    if len(clean)>1 and np.linalg.norm(clean[0]-clean[-1])<1e-8:clean.pop()
    return clean if len(clean)>=3 else []

def clip_rect(poly,rect):
    x0,y0,x1,y1=rect
    for axis,bound,above in [(0,x0,True),(0,x1,False),(1,y0,True),(1,y1,False)]:
        poly=clip(poly,axis,bound,above)
        if not poly:break
    return poly

def poly_area(poly):
    if len(poly)<3:return 0.
    return sum(np.linalg.norm(np.cross(poly[i]-poly[0],poly[i+1]-poly[0]))/2 for i in range(1,len(poly)-1))

def edge_in_rect(a,b,rect):
    """Nonzero segment intersection (needed for connected patch graph)."""
    lo,hi=0.,1.
    for axis,mn,mx in [(0,rect[0],rect[2]),(1,rect[1],rect[3])]:
        delta=b[axis]-a[axis]
        if abs(delta)<1e-12:
            if a[axis]<mn-EPS or a[axis]>mx+EPS:return False
        else:
            q0,q1=(mn-a[axis])/delta,(mx-a[axis])/delta
            lo=max(lo,min(q0,q1));hi=min(hi,max(q0,q1))
    return hi-lo>1e-8 and np.linalg.norm(b-a)*(hi-lo)>1e-7

def components(pieces,adj,sharp,points,rect):
    parent={f:f for f in pieces}
    members={f:{f} for f in pieces}
    def find(i):
        while parent[i]!=i:
            parent[i]=parent[parent[i]];i=parent[i]
        return i
    for f in pieces:
        for other,e in adj[f]:
            if other in pieces and other>f and edge_in_rect(points[e[0]],points[e[1]],rect):
                ra,rb=find(f),find(other)
                if ra==rb:continue
                # A sharp edge can reconnect by a smooth path around its endpoint.
                # Enforce a cannot-link condition, not merely a skipped adjacency.
                if any(y in members[rb] for x in members[ra] for y in sharp[x]):continue
                if len(members[ra])>len(members[rb]):ra,rb=rb,ra
                parent[ra]=rb;members[rb].update(members.pop(ra))
    groups=collections.defaultdict(dict)
    for f,poly in pieces.items():groups[find(f)][f]=poly
    return list(groups.values())

def shape_hash(vertices,faces):
    """Rigid congruence signature: canonical 3D vertices AND full triangle topology.
    One micrometre numerical quantisation only; width/length rounding is never used.
    """
    p=np.asarray(vertices);dist=np.sum((p[:,None]-p[None,:])**2,axis=2)
    i,j=np.unravel_index(np.argmax(dist),dist.shape)
    candidates=[]
    for a,b in [(i,j),(j,i)]:
        origin=p[a];u=p[b]-origin;u/=np.linalg.norm(u)
        q=p-origin;perp=q-np.outer(q@u,u);k=np.argmax(np.sum(perp**2,axis=1));v=perp[k]
        if np.linalg.norm(v)<1e-10:return hashlib.sha256(str(vertices).encode()).hexdigest()[:20]
        v/=np.linalg.norm(v);n=np.cross(u,v)
        coords=np.round(np.stack([q@u,q@v,q@n],axis=1),6)
        order=sorted(range(len(p)),key=lambda t:tuple(coords[t]))
        inverse={old:new for new,old in enumerate(order)}
        faces_key=sorted(tuple(sorted(inverse[k] for k in f)) for f in faces)
        key=json.dumps([coords[order].tolist(),faces_key],separators=(',',':'))
        candidates.append(key)
    return hashlib.sha256(min(candidates).encode()).hexdigest()[:20]

def build_panel(pieces,slopes,grid,rect,number):
    vertices=[];lookup={};faces=[]
    for f,poly in pieces.items():
        ids=[]
        for v in poly:
            key=tuple(np.round(v,8))
            if key not in lookup:lookup[key]=len(vertices);vertices.append(v.tolist())
            ids.append(lookup[key])
        for i in range(1,len(ids)-1):
            face=[ids[0],ids[i],ids[i+1]]
            a,b,c=np.asarray([vertices[k] for k in face])
            if np.linalg.norm(np.cross(b-a,c-a))>1e-9:faces.append(face)
    if not faces:return None
    p=np.asarray(vertices)
    area=sum(np.linalg.norm(np.cross(p[b]-p[a],p[c]-p[a]))/2 for a,b,c in faces)
    if area<1e-9:return None
    span=p.max(0)-p.min(0)
    sx=max(abs(slopes[f][0]) for f in pieces);sy=max(abs(slopes[f][1]) for f in pieces)
    dx=float(span[0]*math.sqrt(1+sx*sx));dy=float(span[1]*math.sqrt(1+sy*sy))
    width,length=sorted([dx,dy])
    _,_,vt=np.linalg.svd(p-p.mean(0),full_matrices=False)
    dev=float(max(abs((p-p.mean(0))@vt[-1]))*1000)
    panel={'id':f'P{number:05d}','type_id':'','width_m':round(width,8),'length_m':round(length,8),
           'area_m2':round(float(area),10),'vertices':[[round(float(x),8) for x in v] for v in vertices],
           'faces':faces,'kind':'planar' if dev<0.001 else 'curved_mesh',
           'nonplanarity_mm':round(dev,5),'grid':list(grid),'source_face_count':len(pieces),
           'dimension_method':'conservative_surface_path_envelope',
           '_shape':shape_hash(vertices,faces),'_source_faces':set(pieces),
           '_slope_x':sx,'_slope_y':sy}
    assert width<=1.5+2e-7 and length<=3+2e-7,(width,length)
    assert area<=width*length+1e-6,(area,width,length)
    return panel

def panel_projection(panel):
    p=np.asarray(panel['vertices'])
    return unary_union([Polygon(p[f,:2]) for f in panel['faces']])

def merge_small_panels(panels,points,faces,slopes,sharp,width,length,rotated):
    """Merge small neighbors only when connected, no crease, and full surface limits hold."""
    active={i:p for i,p in enumerate(panels)}
    shapes={i:panel_projection(p) for i,p in active.items()}
    merges=0
    mx,my=(length,width) if rotated else (width,length)
    for pass_no in range(3):
        ids=list(active);tree=STRtree([shapes[i] for i in ids]);changed=False
        for i in sorted(ids,key=lambda i:active[i]['area_m2']):
            if i not in active or active[i]['area_m2']>=0.10:continue
            a=active[i];poly=shapes[i]
            choices=[]
            for slot in tree.query(poly.buffer(1e-7)):
                j=ids[slot]
                if j==i or j not in active:continue
                b=active[j]
                pp=np.asarray(a['vertices']+b['vertices']);span=pp.max(0)-pp.min(0)
                sx=max(a['_slope_x'],b['_slope_x']);sy=max(a['_slope_y'],b['_slope_y'])
                dx=float(span[0]*math.sqrt(1+sx*sx));dy=float(span[1]*math.sqrt(1+sy*sy))
                if dx>mx+1e-8 or dy>my+1e-8:continue
                if any(other in b['_source_faces'] for f in a['_source_faces'] for other in sharp[f]):continue
                if poly.boundary.intersection(shapes[j].boundary).length<1e-6:continue
                joined=poly.union(shapes[j])
                if joined.geom_type!='Polygon':continue
                choices.append((b['area_m2'],j,joined,dx,dy,sx,sy))
            if not choices:continue
            _,j,joined,dx,dy,sx,sy=max(choices,key=lambda q:q[0]);b=active[j]
            verts=[];lookup={};newfaces=[]
            for panel in [a,b]:
                ix=[]
                for v in panel['vertices']:
                    key=tuple(v)
                    if key not in lookup:lookup[key]=len(verts);verts.append(v)
                    ix.append(lookup[key])
                newfaces.extend([[ix[k] for k in face] for face in panel['faces']])
            pp=np.asarray(verts);_,_,vt=np.linalg.svd(pp-pp.mean(0),full_matrices=False)
            dev=float(max(abs((pp-pp.mean(0))@vt[-1]))*1000)
            b.update(vertices=verts,faces=newfaces,width_m=round(min(dx,dy),8),length_m=round(max(dx,dy),8),
                area_m2=round(a['area_m2']+b['area_m2'],10),nonplanarity_mm=round(dev,5),
                kind='planar' if dev<0.001 else 'curved_mesh',_slope_x=sx,_slope_y=sy,
                _source_faces=a['_source_faces']|b['_source_faces'],
                source_face_count=len(a['_source_faces']|b['_source_faces']),
                _shape=shape_hash(verts,newfaces))
            shapes[j]=joined;del active[i];del shapes[i];merges+=1;changed=True
        if not changed:break
    # Exact union boundaries avoid displaying mesh diagonals or subdivision T-junctions as seams.
    for i,panel in active.items():
        geometry=shapes[i]
        if geometry.geom_type!='Polygon':raise RuntimeError('Panel projected surface is disconnected')
        pp=np.asarray(panel['vertices']);xy=pp[:,:2]
        outlines=[]
        for ring in [geometry.exterior,*geometry.interiors]:
            vv=[]
            for x,y in list(ring.coords)[:-1]:
                delta=np.linalg.norm(xy-[x,y],axis=1);v=pp[np.argmin(delta)]
                if delta.min()>2e-7:
                    # Boundary intersections introduced by a union are lifted onto the original triangle.
                    found=False
                    for fi in panel['_source_faces']:
                        tri=points[faces[fi]];mat=np.column_stack((tri[1,:2]-tri[0,:2],tri[2,:2]-tri[0,:2]))
                        bary=np.linalg.solve(mat,np.array([x,y])-tri[0,:2])
                        if bary.min()>=-1e-6 and bary.sum()<=1+1e-6:
                            v=tri[0]+bary[0]*(tri[1]-tri[0])+bary[1]*(tri[2]-tri[0]);found=True;break
                    if not found:raise RuntimeError('Unable to lift boundary vertex')
                vv.append([round(float(q),8) for q in v])
            outlines.append(vv)
        panel['outlines']=outlines
    return list(active.values()),merges

def solve(points,faces,normals,slopes,adj,sharp,width,length,rotated=False):
    # 10% projection reserve avoids needless 2x2 splitting for every nonzero slope.
    reserve=0.9
    gx,gy=((length*reserve,width*reserve) if rotated else (width*reserve,length*reserve))
    xmin,ymin=points.min(0)[:2];xmax,ymax=points.max(0)[:2]
    # Snap only origin to full nominal grid; preserves identical baseline in alternatives.
    ox=math.floor(xmin/gx)*gx;oy=math.floor(ymin/gy)*gy
    cells=collections.defaultdict(dict)
    for fi,f in enumerate(faces):
        tri=[points[k] for k in f];p=np.asarray(tri)
        ij0=np.floor((p.min(0)[:2]-[ox,oy])/[gx,gy]).astype(int)
        ij1=np.floor((p.max(0)[:2]-[ox,oy])/[gx,gy]).astype(int)
        for i in range(ij0[0],ij1[0]+1):
            for j in range(ij0[1],ij1[1]+1):
                rect=(ox+i*gx,oy+j*gy,ox+(i+1)*gx,oy+(j+1)*gy)
                poly=clip_rect(tri,rect)
                if poly and poly_area(poly)>1e-9:cells[(i,j)][fi]=poly
    panels=[]
    def refine(pieces,rect,grid,depth=0):
        for comp in components(pieces,adj,sharp,points,rect):
            allp=np.concatenate(list(comp.values()));span=allp.max(0)-allp.min(0)
            sx=max(abs(slopes[f][0]) for f in comp);sy=max(abs(slopes[f][1]) for f in comp)
            dx=float(span[0]*math.sqrt(1+sx*sx));dy=float(span[1]*math.sqrt(1+sy*sy))
            # Preserve intended width/length orientation; conservative independent surface path limits.
            mx,my=(length,width) if rotated else (width,length)
            nx=max(1,math.ceil((dx-1e-7)/mx));ny=max(1,math.ceil((dy-1e-7)/my))
            if nx==1 and ny==1:
                panel=build_panel(comp,slopes,grid,rect,len(panels)+1)
                if panel:panels.append(panel)
                continue
            if depth>5:raise RuntimeError('Unexpected subdivision depth')
            lo=allp.min(0);hi=allp.max(0)
            for i in range(nx):
                for j in range(ny):
                    subrect=(lo[0]+span[0]*i/nx,lo[1]+span[1]*j/ny,
                             lo[0]+span[0]*(i+1)/nx,lo[1]+span[1]*(j+1)/ny)
                    subpieces={}
                    for f,poly in comp.items():
                        cp=clip_rect(poly,subrect)
                        if cp and poly_area(cp)>1e-9:subpieces[f]=cp
                    if subpieces:refine(subpieces,subrect,grid,depth+1)
    for (i,j),pieces in sorted(cells.items()):
        refine(pieces,(ox+i*gx,oy+j*gy,ox+(i+1)*gx,oy+(j+1)*gy),(i,j))
    panels,merges=merge_small_panels(panels,points,faces,slopes,sharp,width,length,rotated)
    for index,p in enumerate(panels):
        p['surface_width_bound_m']=p['width_m']
        p['surface_length_bound_m']=p['length_m']
        if p['kind']=='planar':
            pp=np.asarray(p['vertices']);centered=pp-pp.mean(0)
            _,_,basis=np.linalg.svd(centered,full_matrices=False)
            xy=centered@basis[:2].T
            rect=feasible_rectangle(xy,width=1.5-1e-6,length=3.0-1e-6)
            if rect is None:raise RuntimeError(f'Planar panel does not fit fabrication rectangle: {p["id"]}')
            p['planar_box_width_m']=round(rect[0],8)
            p['planar_box_axes']=[(basis[0]*math.cos(rect[2])+basis[1]*math.sin(rect[2])).tolist(),
                                  (-basis[0]*math.sin(rect[2])+basis[1]*math.cos(rect[2])).tolist()]
            p['planar_box_length_m']=round(rect[1],8)
            p['width_m']=max(p['width_m'],p['planar_box_width_m'])
            p['length_m']=max(p['length_m'],p['planar_box_length_m'])
            p['dimension_method']='max_surface_path_and_feasible_orthogonal_planar_box'
        p['id']=f'P{index+1:05d}'
        for field in ['_source_faces','_slope_x','_slope_y']:p.pop(field)
    type_map={};types=[]
    for p in panels:
        sig=p.pop('_shape')
        if sig not in type_map:
            tid=f'T{len(types)+1:04d}';type_map[sig]=tid
            types.append({'id':tid,'representative':p['id'],'width_m':p['width_m'],
                          'length_m':p['length_m'],'area_m2':p['area_m2'],'kind':p['kind'],
                          'nonplanarity_mm':p['nonplanarity_mm'],'template_count':0,
                          'shape_signature':sig,'handed':p['kind']=='curved_mesh'})
        p['type_id']=type_map[sig]
        types[int(p['type_id'][1:])-1]['template_count']+=1
    return panels,types,merges

def main():
    source=json.loads((ROOT/'modelData.json').read_text());g=source['variants']['0']
    points=np.asarray(g['vertices'],dtype=float);faces=np.asarray(g['faces'])
    cr=np.cross(points[faces[:,1]]-points[faces[:,0]],points[faces[:,2]]-points[faces[:,0]])
    areas=np.linalg.norm(cr,axis=1)/2;normals=cr/np.linalg.norm(cr,axis=1)[:,None]
    normals[normals[:,2]<0]*=-1
    assert normals[:,2].min()>0.01,'Surface must be a z graph'
    slopes=-normals[:,:2]/normals[:,2:]
    edges=collections.defaultdict(list)
    for fi,f in enumerate(faces):
        for a,b in zip(f,np.roll(f,-1)):edges[tuple(sorted((int(a),int(b))))].append(fi)
    adj=collections.defaultdict(list);sharp=collections.defaultdict(set);crease_count=0
    for edge,fs in edges.items():
        if len(fs)==2:
            a,b=fs
            if normals[a]@normals[b]>=math.cos(math.radians(ANGLE_DEG)):
                adj[a].append((b,edge));adj[b].append((a,edge))
            else:
                crease_count+=1;sharp[a].add(b);sharp[b].add(a)
    instances=[]
    for k,inst in enumerate(source['instances']):
        m=np.array(inst['matrix']).reshape(4,4).T
        instances.append(dict(inst,roof_id='ABCD'[k//2],half=k%2+1,mirrored=bool(np.linalg.det(m[:3,:3])<0)))
    out={'format':'roof-panel-study-1','unit':'m','source':{'model_name':'1102e',
        'reference':'1027EX 屋顶编辑器内嵌屋面；用户确认与 1102e 屋面一致',
        'template_triangle_count':len(faces),'template_surface_area_m2':float(areas.sum()),
        'instance_count':len(instances),'confirmed_same_roof':True},
        'max_width_m':1.5,'max_length_m':3.,'crease_angle_deg':ANGLE_DEG,
        'method':{'dimensions':'每个网格片区在两个水平参数方向上的跨度，分别乘以该片区内最大真实表面坡度伸长系数；取短、长两个保守路径包络。不是水平投影尺寸。平面板另外通过全角度可行性检查，保证其真实正交包络可放入 1.5×3 米矩形，统计尺寸取路径包络及该正交包络的逐项较大值；曲面板不是可直接生产的平面下料展开尺寸。',
        'creases':'相邻原三角面法向夹角大于 10° 的边不合并为同一块板；连续曲面保留原始三角网格。',
        'types':'按微米数值精度的完整三维几何与三角拓扑归类，而非只按毫米四舍五入长宽；镜像曲面构件制造时须分左右手。',
        'gaps':'净覆盖分格，未扣板缝、未计厚度、折边、搭接及龙骨。',
        'optimization':'在四种离散标准网格候选中，先选实际块数最少者，再比较几何类型数；非全局最优保证。初始水平参数网格保留 10% 几何伸长余量，不表示板缝；小于 0.1m² 的相邻片区仅在不跨尖折线及满足尺寸上限时合并。'},
        'instances':instances,'center':source['center'],'targetZ':source['targetZ'],'candidates':[]}
    for ident,name,w,l,rot in [('1500x3000','1500 × 3000 · 主向',1.5,3.,False),
                              ('1500x3000-r','1500 × 3000 · 转向',1.5,3.,True),
                              ('1200x3000','1200 × 3000',1.2,3.,False),
                              ('1500x2400','1500 × 2400',1.5,2.4,False)]:
        start=time.time();panels,types,merges=solve(points,faces,normals,slopes,adj,sharp,w,l,rot)
        area=sum(p['area_m2'] for p in panels);error=area-float(areas.sum())
        if abs(error)>1e-5:raise RuntimeError(f'Area conservation failed: {error}')
        allarea=0.
        for inst in instances:
            mat=np.asarray(inst['matrix']).reshape(4,4).T
            pp=points@mat[:3,:3].T+mat[:3,3]
            allarea+=np.linalg.norm(np.cross(pp[faces[:,1]]-pp[faces[:,0]],pp[faces[:,2]]-pp[faces[:,0]]),axis=1).sum()/2
        summary={'template_panel_count':len(panels),'panel_count':len(panels)*8,
             'type_count':len(types),'handed_type_count':sum(2 if t['handed'] else 1 for t in types),
             'surface_area_m2':allarea,'template_surface_area_m2':area,'area_error_m2':error,
             'max_width_m':max(p['width_m'] for p in panels),'max_length_m':max(p['length_m'] for p in panels),
             'max_nonplanarity_mm':max(p['nonplanarity_mm'] for p in panels),
             'min_panel_area_m2':min(p['area_m2'] for p in panels),
             'max_surface_width_bound_m':max(p['surface_width_bound_m'] for p in panels),
             'max_surface_length_bound_m':max(p['surface_length_bound_m'] for p in panels),
             'curved_panel_count':sum(p['kind']=='curved_mesh' for p in panels)*8,
             'planar_panel_count':sum(p['kind']=='planar' for p in panels)*8,
             'triangle_count':sum(len(p['faces']) for p in panels)*8,
             'small_panel_count':sum(p['area_m2']<0.05 for p in panels)*8,
             'repeat_ratio':1-len(types)/(len(panels)*8),
             'crease_edge_count_per_template':crease_count,'merged_small_panels':merges*8,
             'projection_grid_reserve_factor':0.9}
        out['candidates'].append({'id':ident,'name':name,'nominal_width_m':w,'nominal_length_m':l,
              'rotated':rot,'panels':panels,'types':types,'summary':summary})
        print(ident,summary,'seconds',round(time.time()-start,2),flush=True)
    out['recommended_id']=min(out['candidates'],key=lambda c:(c['summary']['panel_count'],c['summary']['type_count']))['id']
    (ROOT/'panels.json').write_text(json.dumps(out,ensure_ascii=False,separators=(',',':')),encoding='utf8')
    print('Wrote',ROOT/'panels.json',(ROOT/'panels.json').stat().st_size,'bytes; recommended',out['recommended_id'],flush=True)

if __name__=='__main__':main()
