"""Independent output checks: source coverage, true 3D area, slope envelopes, sizes."""
import json,math,sys
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'vendor'))
from shapely.geometry import Polygon
from shapely.ops import unary_union
from planar_rectangle import feasible_rectangle

def mesh_areas(p,faces):
    f=np.asarray(faces)
    return np.linalg.norm(np.cross(p[f[:,1]]-p[f[:,0]],p[f[:,2]]-p[f[:,0]]),axis=1)/2

source=json.loads((ROOT/'modelData.json').read_text());data=json.loads((ROOT/'panels.json').read_text())
s=source['variants']['0'];sp=np.asarray(s['vertices']);sf=np.asarray(s['faces']);sourcearea=float(mesh_areas(sp,sf).sum())
sourceprojection=unary_union([Polygon(sp[f,:2]) for f in sf])
results=[]
for c in data['candidates']:
    area=0.;shapes=[];maxw=maxl=0.;maxangle=0.;tris=0
    for panel in c['panels']:
        p=np.asarray(panel['vertices']);f=np.asarray(panel['faces']);tris+=len(f)
        assert np.isfinite(p).all() and f.min()>=0 and f.max()<len(p)
        a=mesh_areas(p,f);assert a.min()>1e-12
        actual=float(a.sum());area+=actual
        assert abs(actual-panel['area_m2'])<1e-6
        cross=np.cross(p[f[:,1]]-p[f[:,0]],p[f[:,2]]-p[f[:,0]])
        normals=cross/np.linalg.norm(cross,axis=1)[:,None];normals[normals[:,2]<0]*=-1
        assert normals[:,2].min()>0.01
        sl=-normals[:,:2]/normals[:,2:]
        span=p.max(0)-p.min(0)
        bounds=sorted([float(span[axis]*math.sqrt(1+np.max(abs(sl[:,axis]))**2)) for axis in [0,1]])
        assert bounds[0]<=1.5+1e-5 and bounds[1]<=3+1e-5,(panel['id'],bounds)
        # Source-to-output rounding affects only numerical noise, not fabrication tolerances.
        assert max(abs(bounds[0]-panel['surface_width_bound_m']),abs(bounds[1]-panel['surface_length_bound_m']))<0.002
        if panel['kind']=='planar':
            q=p-p.mean(0);_,_,basis=np.linalg.svd(q,full_matrices=False)
            rectangle=feasible_rectangle(q@basis[:2].T)
            assert rectangle is not None,(panel['id'],'No feasible planar rectangle')
            box_axes=np.asarray(panel['planar_box_axes'])
            actual_box=sorted(np.ptp(p@box_axes.T,axis=0))
            assert actual_box[0]<=panel['planar_box_width_m']+2e-8
            assert actual_box[1]<=panel['planar_box_length_m']+2e-8
        assert panel['width_m']<=1.5+2e-8 and panel['length_m']<=3+2e-8
        maxw=max(maxw,bounds[0]);maxl=max(maxl,bounds[1])
        rings=panel['outlines'];poly=Polygon(np.asarray(rings[0])[:,:2],[np.asarray(r)[:,:2] for r in rings[1:]])
        assert poly.is_valid and not poly.is_empty
        shapes.append(poly)
        # Any shared internal mesh edge must stay below the crease threshold.
        edges={}
        for ti,face in enumerate(f):
            for a,b in zip(face,np.roll(face,-1)):
                edge=tuple(sorted((int(a),int(b))))
                if edge in edges:
                    angle=math.degrees(math.acos(float(np.clip(normals[ti]@normals[edges[edge]],-1,1))))
                    maxangle=max(maxangle,angle)
                    assert angle<=data['crease_angle_deg']+0.005,(panel['id'],angle)
                else:edges[edge]=ti
    covered=unary_union(shapes)
    uncovered=sourceprojection.difference(covered).area
    outside=covered.difference(sourceprojection).area
    overlap=sum(s.area for s in shapes)-covered.area
    assert uncovered<1e-4 and outside<1e-4 and overlap<1e-4,(uncovered,outside,overlap)
    assert abs(area-sourcearea)<1e-4,(area,sourcearea)
    assert c['summary']['panel_count']==len(c['panels'])*len(data['instances'])
    assert sum(t['template_count'] for t in c['types'])==len(c['panels'])
    result={'candidate':c['id'],'template_panels':len(c['panels']), 'full_panels':len(c['panels'])*8,
      'source_area_m2':sourcearea,'output_area_m2':area,'area_error_m2':area-sourcearea,
      'uncovered_projection_m2':uncovered,'outside_projection_m2':outside,'overlap_projection_m2':overlap,
      'max_recomputed_surface_width_m':maxw,'max_recomputed_surface_length_m':maxl,
      'max_internal_mesh_dihedral_deg':maxangle,'template_triangles':tris,'passed':True}
    results.append(result);print(json.dumps(result,ensure_ascii=False),flush=True)
report={'format':'roof-panel-validation-1','all_passed':True,'candidates':results,
        'manufacturing_status':'design-study-only; no flat blank development, seam deduction, support or thickness calculation'}
(ROOT/'geometry_validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
