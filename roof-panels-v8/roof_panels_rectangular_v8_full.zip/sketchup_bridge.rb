# encoding: UTF-8
# SketchUp Pro 2018 / Ruby 2.2+. All imported geometry is additive and undoable.
require 'sketchup.rb'
require 'json'
require 'time'
require 'digest'

module RoofPanelBridge
  extend self
  INCH_TO_M = 0.0254
  M_TO_INCH = 1.0 / INCH_TO_M
  MAX_WIDTH = 1.5
  MAX_LENGTH = 3.0 # Legacy V3 caps; V4–V8 use the validated sizing_rule below.
  BUILD_SCALE = 1000.0 # Avoid SketchUp small-face creation tolerance; inverse-scaled on instances.
  EPS_M = 0.00001
  STRICT_PLANAR_M = 0.0000001 # 0.0001 mm: numeric coplanarity tolerance, not a fold allowance.
  RECTANGLE_ANGLE_EPS = 0.0000001
  ARC_REFERENCE_M = 0.000001 # World-coordinate serialization tolerance, not a shape exemption.
  ATTR = 'RoofPanelStudio'

  def finite_number(value, label)
    raise ArgumentError, "#{label} 必须是数值" unless value.is_a?(Numeric)
    n = value.to_f
    raise ArgumentError, "#{label} 必须是有限数值" unless n.finite?
    n
  end

  def sizing_limits(data)
    rule=data['sizing_rule']
    v8=data['panel_study_version'].to_s.downcase.start_with?('v8')
    v7=data['panel_study_version'].to_s.downcase.start_with?('v7')
    v6=data['panel_study_version'].to_s.downcase.start_with?('v6')
    v5=data['panel_study_version'].to_s.downcase.start_with?('v5')
    if v8 || v7 || v6 || v5
      version=v8 ? 'V8' : (v7 ? 'V7' : (v6 ? 'V6' : 'V5'))
      raise ArgumentError,"#{version} 文件必须包含 sizing_rule 对象" unless rule.is_a?(Hash)
      width=finite_number(rule['nominal_width_mm'],'nominal_width_mm')
      length=finite_number(rule['nominal_length_mm'],'nominal_length_mm')
      min_width=finite_number(rule['min_width_mm'],'min_width_mm')
      max_width=finite_number(rule['max_width_mm'],'max_width_mm')
      if v8 || v7 || v6
        raise ArgumentError,"#{version} 输入宽度必须为 1–1000000000 mm 的整数" unless
          width>=1.0 && width<=1.0e9 && (width-width.round).abs<=1.0e-6
        raise ArgumentError,"#{version} 宽度数值范围声明必须为 1–1000000000 mm" unless
          (min_width-1.0).abs<=1.0e-6 && (max_width-1.0e9).abs<=1.0e-6
        {'min_length_mm'=>1.0,'max_length_mm'=>1.0e9}.each do |key,expected|
          next unless rule.key?(key)
          raise ArgumentError,"#{version} #{key} 数值范围声明不一致" if
            (finite_number(rule[key],key)-expected).abs>1.0e-6
        end
      else
        raise ArgumentError,'V5 输入宽度必须为 500–1500 mm 的整数' unless
          width>=500.0 && width<=1500.0 && (width-width.round).abs<=1.0e-6
        raise ArgumentError,'V5 宽度调节范围必须为 500–1500 mm' unless
          (min_width-500.0).abs<=1.0e-6 && (max_width-1500.0).abs<=1.0e-6
      end
      raise ArgumentError,"#{version} 输入长度必须为 1–1000000000 mm 的整数" unless
        length>=1.0 && length<=1.0e9 && (length-length.round).abs<=1.0e-6
      locked=rule['ratio_locked']
      raise ArgumentError,"#{version} ratio_locked 必须为 true 或 false" unless locked==true || locked==false
      mode=rule['mode']
      raise ArgumentError,"#{version} mode 与比例锁定状态不一致" unless mode==(locked ? 'ratio' : 'free')
      ratio=rule['ratio'].nil? ? nil : finite_number(rule['ratio'],'sizing_rule ratio')
      raise ArgumentError,"#{version} 自定义长宽比必须大于零" if ratio && ratio<=0
      if locked
        raise ArgumentError,"#{version} 锁定比例时必须提供正数 ratio" unless ratio
        raise ArgumentError,"#{version} 输入长度与锁定比例不一致（允许整数毫米舍入）" if
          (length-width*ratio).abs>0.51
      end
      nominal_width_m=width/1000.0
      nominal_length_m=length/1000.0
      # Input W/L follow chart U/V. Physical short/long envelope caps are sorted,
      # including a positive input length shorter than the input width.
      width_m,length_m=[nominal_width_m,nominal_length_m].sort
      {'max_width_m'=>width_m,'max_length_m'=>length_m,
       'nominal_width_m'=>nominal_width_m,'nominal_length_m'=>nominal_length_m}.each do |key,expected|
        declared=finite_number(data[key],key)
        raise ArgumentError,"#{key} 与 #{version} 所选输入尺寸不一致" if (declared-expected).abs>1.0e-6
      end
      return {'v4'=>false,'v5'=>v5,'v6'=>v6,'v7'=>v7,'v8'=>v8,'max_width_m'=>width_m,'max_length_m'=>length_m,
              'nominal_width_mm'=>width,'nominal_length_mm'=>length,
              'ratio_locked'=>locked,'ratio'=>ratio}
    end
    v4=data['panel_study_version'].to_s.downcase.start_with?('v4') || !rule.nil?
    unless v4
      # A legacy file cannot obtain larger caps by declaring them in metadata.
      {'max_width_m'=>MAX_WIDTH,'max_length_m'=>MAX_LENGTH}.each do |key,cap|
        next unless data.key?(key)
        value=finite_number(data[key],key)
        raise ArgumentError,"旧版 #{key} 必须大于零且不超过 #{cap} m" if value<=0 || value>cap+EPS_M
      end
      return {'v4'=>false,'max_width_m'=>MAX_WIDTH,'max_length_m'=>MAX_LENGTH}
    end
    raise ArgumentError,'V4 文件必须包含 sizing_rule 对象' unless rule.is_a?(Hash)
    width=finite_number(rule['nominal_width_mm'],'nominal_width_mm')
    length=finite_number(rule['nominal_length_mm'],'nominal_length_mm')
    ratio=finite_number(rule['ratio'],'sizing_rule ratio')
    min_width=finite_number(rule['min_width_mm'],'min_width_mm')
    max_width=finite_number(rule['max_width_mm'],'max_width_mm')
    raise ArgumentError,'V4 标准宽度必须在 500–1500 mm 之间' unless width>=500.0-1.0e-6 && width<=1500.0+1.0e-6
    raise ArgumentError,'V4 长度必须等于所选宽度的 3 倍' unless (ratio-3.0).abs<=1.0e-9 && (length-width*3.0).abs<=1.0e-6
    raise ArgumentError,'V4 调节范围必须为 500–1500 mm' unless (min_width-500.0).abs<=1.0e-6 && (max_width-1500.0).abs<=1.0e-6
    width_m=width/1000.0
    length_m=length/1000.0
    {'max_width_m'=>width_m,'max_length_m'=>length_m}.each do |key,expected|
      declared=finite_number(data[key],key)
      raise ArgumentError,"#{key} 与 V4 所选标准尺寸不一致" if (declared-expected).abs>1.0e-6
    end
    {'nominal_width_m'=>width_m,'nominal_length_m'=>length_m}.each do |key,expected|
      next unless data.key?(key)
      declared=finite_number(data[key],key)
      raise ArgumentError,"#{key} 与 sizing_rule 不一致" if (declared-expected).abs>1.0e-6
    end
    {'v4'=>true,'max_width_m'=>width_m,'max_length_m'=>length_m,
     'nominal_width_mm'=>width,'nominal_length_mm'=>length}
  end

  def geometry_limits(data)
    v8=data['panel_study_version'].to_s.downcase.start_with?('v8')
    v7=data['panel_study_version'].to_s.downcase.start_with?('v7')
    return {'strict_planar'=>false,'rectangles'=>false} unless v8 || v7
    version=v8 ? 'V8' : 'V7'
    rule=data['geometry_rule']
    raise ArgumentError,"#{version} 文件必须包含 geometry_rule 对象" unless rule.is_a?(Hash)
    expected=v8 ? 'planar_rectangles' : 'planar'
    raise ArgumentError,"#{version} panels 必须为 #{expected}" unless rule['panels']==expected
    tolerance=finite_number(rule['planarity_tolerance_mm'],'planarity_tolerance_mm')
    raise ArgumentError,"#{version} 平面数值容差声明必须为 0.0001 mm" if (tolerance-STRICT_PLANAR_M*1000.0).abs>1.0e-12
    raise ArgumentError,"#{version} 褶皱顶边分缝声明必须为 aligned" unless rule['ridge_seams']=='aligned'
    if v8
      raise ArgumentError,'V8 必须明确声明仅外轮廓弧线可修边' unless rule['exterior_arc_trims']==true
      raise ArgumentError,'V8 相邻板尺寸差容差必须为 10%' if (finite_number(rule['neighbor_tolerance'],'neighbor_tolerance')-0.1).abs>1.0e-12
      raise ArgumentError,'V8 必须声明经用户批准重构屋面' unless rule['source_geometry']=='reconstructed_with_user_approval'
    end
    {'strict_planar'=>true,'rectangles'=>v8,'planarity_tolerance_m'=>STRICT_PLANAR_M,'ridge_seams'=>'aligned'}
  end

  def sub(a, b); [a[0]-b[0], a[1]-b[1], a[2]-b[2]]; end
  def dot(a, b); a[0]*b[0]+a[1]*b[1]+a[2]*b[2]; end
  def cross(a, b)
    [a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0]]
  end
  def norm(a); Math.sqrt(dot(a,a)); end
  def unit(a)
    n = norm(a)
    raise ArgumentError, '存在退化的板片或共线顶点' if n < 1.0e-10
    a.map { |v| v/n }
  end
  def vector(a); Geom::Vector3d.new(a); end
  def point_m(a); Geom::Point3d.new(a.map { |v| v*M_TO_INCH }); end

  def source_info(model)
    {
      'model_name' => model.title.to_s.empty? ? '未命名模型' : model.title,
      'model_guid' => model.guid.to_s,
      'exported_at' => Time.now.iso8601,
      'scope' => 'explicit-selection',
      'units' => 'm'
    }
  end

  def entity_label(entity, fallback)
    name = entity.respond_to?(:name) ? entity.name.to_s : ''
    if name.empty? && entity.respond_to?(:definition)
      name = entity.definition.name.to_s
    end
    name.empty? ? fallback : name
  end

  def export_selected
    model = Sketchup.active_model
    selected = model.selection.to_a
    if selected.empty?
      UI.messagebox('请先明确选中屋顶顶面，或只包含屋顶顶面的群组/组件。不要选中整栋建筑。')
      return
    end
    note = "只导出当前选择的面及所选群组/组件中的全部面（包括内部隐藏面）。\n" +
      "不会自动识别或排除底面、檐口、玻璃、立面，也不会按法线方向猜测屋面。\n" +
      "请确认选择中只含需要分板的屋顶表面，且没有重叠的内外两层。继续？"
    return unless UI.messagebox(note, MB_YESNO) == IDYES
    roofs = []
    face_count = 0
    root_transform = model.edit_transform
    direct_faces = selected.select { |e| e.is_a?(Sketchup::Face) }
    sources = []
    sources << ['selection_faces', '直接选择的屋面', direct_faces, root_transform] unless direct_faces.empty?
    selected.each_with_index do |entity, i|
      next unless entity.is_a?(Sketchup::Group) || entity.is_a?(Sketchup::ComponentInstance)
      entities = entity.is_a?(Sketchup::Group) ? entity.entities : entity.definition.entities
      sources << ["roof_#{i+1}", entity_label(entity,"屋面 #{i+1}"), entities.to_a,
                  root_transform * entity.transformation]
    end
    sources.each do |id, name, entities, transformation|
      vertices, triangles, lookup = [], [], {}
      walk = nil
      walk = lambda do |items, tr, depth|
        raise ArgumentError, '组件嵌套超过 100 层，请检查选择' if depth > 100
        items.each do |entity|
          if entity.is_a?(Sketchup::Face)
            face_count += 1
            mesh = entity.mesh(0)
            mesh.polygons.each do |polygon|
              ids = polygon.map do |i|
                pos = mesh.point_at(i.abs).transform(tr)
                xyz = [pos.x.to_f*INCH_TO_M, pos.y.to_f*INCH_TO_M, pos.z.to_f*INCH_TO_M]
                key = xyz.map { |v| (v*1.0e7).round }.join(',')
                unless lookup.key?(key)
                  lookup[key] = vertices.length
                  vertices << xyz
                end
                lookup[key]
              end
              # Face#mesh returns triangulated polygons, including faces with holes.
              (1...(ids.length-1)).each do |j|
                tri = [ids[0], ids[j], ids[j+1]]
                a,b,c = tri.map { |k| vertices[k] }
                triangles << tri if norm(cross(sub(b,a),sub(c,a))) > 1.0e-12
              end
            end
          elsif entity.is_a?(Sketchup::Group)
            walk.call(entity.entities.to_a, tr*entity.transformation, depth+1)
          elsif entity.is_a?(Sketchup::ComponentInstance)
            walk.call(entity.definition.entities.to_a, tr*entity.transformation, depth+1)
          end
        end
      end
      walk.call(entities, transformation, 0)
      roofs << {'id'=>id, 'name'=>name, 'vertices'=>vertices, 'faces'=>triangles} unless triangles.empty?
    end
    raise ArgumentError, '当前选择中没有可以导出的面' if roofs.empty?
    path = UI.savepanel('导出选中的真实屋面（单位：米）', nil, '1102e_屋面源数据.json')
    return unless path
    path += '.json' unless File.extname(path).downcase == '.json'
    payload = {'format'=>'roof-source-1', 'unit'=>'m', 'source'=>source_info(model),
               'roofs'=>roofs, 'source_face_count'=>face_count,
               'note'=>'仅为显式选择范围；屋面口径须由操作者核实，不代表自动识别或竣工尺寸。'}
    File.open(path, 'w:UTF-8') { |f| f.write(JSON.generate(payload)) }
    count = roofs.inject(0) { |sum,r| sum+r['faces'].length }
    UI.messagebox("已导出 #{roofs.length} 个选择范围、#{face_count} 个源面、#{count} 个三角面。\n单位：米；坐标为模型世界坐标。\n#{path}\n\n此源网格 JSON 与铝板分隔 JSON 是不同格式，网页须支持该源网格格式才能重新计算。")
    path
  rescue => error
    UI.messagebox("屋面导出失败：#{error.message}")
    nil
  end

  def polygon_area(points)
    # Newell area vector is exact for planar simple polygons, also concave ones.
    sum = [0.0,0.0,0.0]
    points.each_with_index do |p,i|
      q = points[(i+1)%points.length]
      c = cross(p,q)
      3.times { |k| sum[k] += c[k] }
    end
    norm(sum)*0.5
  end

  def panel_boundary(points, faces, id)
    # Recover the actual mesh perimeter. Labels/outlines cannot turn a
    # trapezoid, a hole, or overlapping faces into a rectangular panel.
    edges={}
    used={}
    faces.each do |f|
      f.each_with_index do |a,j|
        b=f[(j+1)%f.length]
        used[a]=true
        key=[a,b].sort
        edges[key] ||= []
        edges[key] << [a,b]
      end
    end
    raise ArgumentError,"#{id} 存在未使用顶点" unless used.length==points.length
    boundary=[]
    edges.each_value do |items|
      if items.length==1
        boundary << items[0]
      else
        raise ArgumentError,"#{id} 存在重复、反向或非流形的面边" unless
          items.length==2 && items[0][0]==items[1][1] && items[0][1]==items[1][0]
      end
    end
    raise ArgumentError,"#{id} 没有单一有效外边界" if boundary.length<3
    outgoing={}; incoming={}
    boundary.each do |a,b|
      raise ArgumentError,"#{id} 外边界分叉或重叠" if outgoing.key?(a) || incoming.key?(b)
      outgoing[a]=b; incoming[b]=a
    end
    start=boundary[0][0]; ring=[]; current=start
    loop do
      raise ArgumentError,"#{id} 外边界不闭合或重复" if ring.include?(current) || !outgoing.key?(current)
      ring << current
      current=outgoing[current]
      break if current==start
    end
    raise ArgumentError,"#{id} 存在孔洞或多条外边界" unless ring.length==boundary.length
    ring.map { |i| points[i] }
  end

  def simplified_corners(ring)
    result=ring.dup
    loop do
      index=nil
      result.each_with_index do |b,i|
        a=result[(i-1)%result.length]; c=result[(i+1)%result.length]
        ab=sub(b,a); bc=sub(c,b)
        raise ArgumentError,'板件外边界存在零长边' if norm(ab)<1.0e-10 || norm(bc)<1.0e-10
        if dot(ab,bc)>0 && norm(cross(ab,bc))<=RECTANGLE_ANGLE_EPS*norm(ab)*norm(bc)
          index=i; break
        end
      end
      break if index.nil? || result.length<=3
      result.delete_at(index)
    end
    result
  end

  def rectangle_corners?(corners)
    return false unless corners.length==4
    edges=corners.each_with_index.map { |p,i| sub(corners[(i+1)%4],p) }
    lengths=edges.map { |e| norm(e) }
    return false if lengths.any? { |n| n<1.0e-10 }
    4.times do |i|
      return false if dot(edges[i],edges[(i+1)%4]).abs>RECTANGLE_ANGLE_EPS*lengths[i]*lengths[(i+1)%4]
    end
    2.times do |i|
      a=edges[i]; b=edges[i+2]
      return false unless dot(a,b)<0 && norm(cross(a,b))<=RECTANGLE_ANGLE_EPS*lengths[i]*lengths[i+2]
      return false if (lengths[i]-lengths[i+2]).abs>[STRICT_PLANAR_M,lengths[i]*RECTANGLE_ANGLE_EPS].max
    end
    true
  end

  def exterior_references(data)
    roofs=data['roofs']
    raise ArgumentError,'V8 必须包含各世界坐标屋面的外轮廓 roofs' unless roofs.is_a?(Array) && !roofs.empty?
    refs={}
    roofs.each do |raw|
      raise ArgumentError,'V8 屋面外轮廓不是对象' unless raw.is_a?(Hash)
      id=raw['roof_id'].to_s
      raise ArgumentError,'V8 屋面外轮廓编号为空或重复' if id.empty? || refs.key?(id)
      exterior=raw['exterior']
      raise ArgumentError,"#{id} exterior 必须为至少三个世界坐标点" unless exterior.is_a?(Array) && exterior.length>=3
      exterior=exterior.map do |p|
        raise ArgumentError,"#{id} exterior 必须使用三维米坐标" unless p.is_a?(Array) && p.length==3
        p.map { |v| finite_number(v,"#{id} exterior") }
      end
      exterior.pop if norm(sub(exterior[0],exterior[-1]))<=1.0e-10
      ids=raw['arc_edge_indices']
      raise ArgumentError,"#{id} arc_edge_indices 不是有效外轮廓边索引" unless ids.is_a?(Array) &&
        ids.uniq.length==ids.length && ids.all? { |i| i.is_a?(Integer) && i>=0 && i<exterior.length }
      refs[id]={'exterior'=>exterior,'arc_edge_indices'=>ids}
    end
    refs
  end

  def point_on_reference_segment?(p,a,b)
    edge=sub(b,a); d=sub(p,a)
    length2=dot(edge,edge)
    return false if length2<1.0e-20
    t=dot(d,edge)/length2
    return false if t < -ARC_REFERENCE_M/Math.sqrt(length2) || t > 1.0+ARC_REFERENCE_M/Math.sqrt(length2)
    norm(cross(d,edge))<=ARC_REFERENCE_M*Math.sqrt(length2)
  end

  def validate_rectangle_panel(raw, points, faces, normal, area, refs)
    id=raw['id'].to_s
    raise ArgumentError,"#{id} V8 kind 必须为 planar" unless raw['kind']=='planar'
    ring=panel_boundary(points,faces,id)
    raise ArgumentError,"#{id} 面网格面积与单一外边界不一致" if
      (polygon_area(ring)-area).abs>[1.0e-9,area*1.0e-8].max
    corners=simplified_corners(ring)
    rectangle=rectangle_corners?(corners)
    if rectangle
      raise ArgumentError,"#{id} V8 矩形必须明确声明 is_rectangle 和 planar_rectangle" unless
        raw['is_rectangle']==true && raw['layout_shape']=='planar_rectangle'
      raise ArgumentError,"#{id} 矩形不能冒用弧线修边声明" if raw['is_exterior_arc_trim']==true || (raw['arc_edge_ids'].is_a?(Array) && !raw['arc_edge_ids'].empty?)
      return {'is_rectangle'=>true,'is_exterior_arc_trim'=>false,'arc_edge_ids'=>[]}
    end
    raise ArgumentError,"#{id} 非矩形内板：必须为四个直角且对边平行的实际矩形" unless
      raw['is_rectangle']==false && raw['layout_shape']=='outer_arc_trim' && raw['is_exterior_arc_trim']==true
    reference=refs[raw['roof_id'].to_s]
    raise ArgumentError,"#{id} 弧线修边缺少相应屋面外轮廓" unless reference
    ids=raw['arc_edge_ids']
    raise ArgumentError,"#{id} 弧线修边必须提供有效 arc_edge_ids" unless ids.is_a?(Array) && !ids.empty? &&
      ids.uniq.length==ids.length && ids.all? { |i| i.is_a?(Integer) && reference['arc_edge_indices'].include?(i) }
    exterior=reference['exterior']
    on_arc=ring.each_with_index.map do |a,i|
      b=ring[(i+1)%ring.length]
      ids.any? do |j|
        point_on_reference_segment?(a,exterior[j],exterior[(j+1)%exterior.length]) &&
          point_on_reference_segment?(b,exterior[j],exterior[(j+1)%exterior.length])
      end
    end
    raise ArgumentError,"#{id} 非矩形未沿声明的真实外轮廓弧线裁切" unless on_arc.any?
    straight=ring.each_with_index.map { |p,i| [i,sub(ring[(i+1)%ring.length],p)] }.reject { |i,e| on_arc[i] }
    raise ArgumentError,"#{id} 弧线修边缺少可核验的矩形料边" if straight.empty?
    u=unit(straight.max_by { |i,e| norm(e) }[1]); v=unit(cross(normal,u))
    us=ring.map { |p| dot(sub(p,ring[0]),u) }; vs=ring.map { |p| dot(sub(p,ring[0]),v) }
    straight.each do |i,e|
      direction=unit(e)
      raise ArgumentError,"#{id} 存在外弧线以外的斜切边或梯形边" if [dot(direction,u).abs,dot(direction,v).abs].min>RECTANGLE_ANGLE_EPS
      j=(i+1)%ring.length
      on_stock=(us[i]-us[j]).abs<=ARC_REFERENCE_M && [us.min,us.max].any? { |n| (us[i]-n).abs<=ARC_REFERENCE_M }
      on_stock ||= (vs[i]-vs[j]).abs<=ARC_REFERENCE_M && [vs.min,vs.max].any? { |n| (vs[i]-n).abs<=ARC_REFERENCE_M }
      raise ArgumentError,"#{id} 存在矩形包络内部的非法缺口或裁切" unless on_stock
    end
    {'is_rectangle'=>false,'is_exterior_arc_trim'=>true,'arc_edge_ids'=>ids}
  end

  def fits_planar_envelope?(local, width, length)
    # A constrained 1.5 x 3 rectangle may fit at an angle that is not parallel
    # to any polygon edge. The min-area-box edge directions alone are incomplete.
    # Projection-span constraints change feasibility only where a vertex-pair
    # projection equals a limiting side, so test every critical angular interval.
    points=local.map { |p| [p[0],p[1]] }
    angles=[0.0]
    limits=[length+EPS_M,width+EPS_M]
    points.each_with_index do |p,i|
      ((i+1)...points.length).each do |j|
        dx=points[j][0]-p[0]; dy=points[j][1]-p[1]
        radius=Math.sqrt(dx*dx+dy*dy)
        return false if radius>Math.sqrt(limits[0]**2+limits[1]**2)+1.0e-9
        next if radius<1.0e-10
        alpha=Math.atan2(dy,dx)
        limits.each_with_index do |limit,k|
          next unless radius>limit
          center=alpha+(k==0 ? 0.0 : Math::PI/2.0)
          delta=Math.acos([[limit/radius,-1.0].max,1.0].min)
          angles << (center-delta)%Math::PI
          angles << (center+delta)%Math::PI
        end
      end
    end
    angles=angles.sort.uniq
    candidates=angles.dup
    angles.each_with_index do |a,i|
      b=i==angles.length-1 ? angles[0]+Math::PI : angles[i+1]
      candidates << ((a+b)*0.5)%Math::PI
    end
    candidates.any? do |a|
      c=Math.cos(a); si=Math.sin(a)
      xs=points.map { |q| q[0]*c+q[1]*si }
      ys=points.map { |q| -q[0]*si+q[1]*c }
      xs.max-xs.min<=limits[0]+1.0e-9 && ys.max-ys.min<=limits[1]+1.0e-9
    end
  end

  def canonical_panel(raw, index, max_width=MAX_WIDTH, max_length=MAX_LENGTH, strict_planar=false, rectangle_refs=nil)
    raise ArgumentError, "第 #{index+1} 块板不是对象" unless raw.is_a?(Hash)
    id = raw.fetch('id', "P#{index+1}").to_s
    verts = raw['vertices']
    raise ArgumentError, "#{id} 的 vertices 应至少包含 3 个三维点" unless verts.is_a?(Array) && verts.length >= 3
    raise ArgumentError, "#{id} 顶点过多" if verts.length > 20000
    points = verts.map.with_index do |p,i|
      raise ArgumentError, "#{id} 第 #{i+1} 个点不是三维坐标" unless p.is_a?(Array) && p.length == 3
      p.map do |n|
        value = finite_number(n,"#{id} 坐标")
        raise ArgumentError, "#{id} 坐标超出合理模型范围（1000 km）" if value.abs > 1.0e6
        value
      end
    end
    faces = raw['faces'] || [(0...points.length).to_a]
    raise ArgumentError, "#{id} 没有有效 faces" unless faces.is_a?(Array) && !faces.empty?
    faces = faces.map do |f|
      raise ArgumentError, "#{id} 的面索引不正确" unless f.is_a?(Array) && f.length >= 3 &&
        f.all? { |v| v.is_a?(Integer) && v >= 0 && v < points.length } && f.uniq.length == f.length
      f
    end
    origin = points[faces[0][0]]
    axis_x = axis_z = nil
    largest_normal = 0.0
    faces.each do |f|
      a = points[f[0]]
      (1...(f.length-1)).each do |j|
        edge = sub(points[f[j]],a)
        normal = cross(edge, sub(points[f[j+1]],a))
        magnitude=norm(normal)
        if magnitude > 1.0e-10 && (!strict_planar || magnitude>largest_normal)
          axis_x, axis_z = unit(edge), unit(normal)
          origin=a if strict_planar
          largest_normal=magnitude
          break unless strict_planar
        end
      end
      break if axis_x && !strict_planar
    end
    raise ArgumentError, "#{id} 是退化板片" unless axis_x
    axis_y = unit(cross(axis_z,axis_x))
    local = points.map do |p|
      d=sub(p,origin)
      [dot(d,axis_x),dot(d,axis_y),dot(d,axis_z)]
    end
    plane_error=local.map { |p| p[2].abs }.max
    if strict_planar
      raise ArgumentError,"#{id} 不是平直板：偏离基准平面 #{format('%.9f',plane_error*1000.0)} mm（限 0.0001 mm）" if plane_error>STRICT_PLANAR_M
      faces.each do |f|
        a=points[f[0]]
        (1...(f.length-1)).each do |j|
          n=cross(sub(points[f[j]],a),sub(points[f[j+1]],a))
          raise ArgumentError,"#{id} 存在反向或退化面，不能作为单一平直板" if norm(n)<=1.0e-12 || dot(n,axis_z)<=0
        end
      end
      raise ArgumentError,"#{id} 声明了折弯，与单一平直板要求冲突" if raw['needs_bend']==true
    end
    area = faces.inject(0.0) do |sum,f|
      fp=f.map { |i| points[i] }
      if fp.length > 3
        normal=nil
        (1...(fp.length-1)).each do |j|
          n=cross(sub(fp[j],fp[0]),sub(fp[j+1],fp[0]))
          if norm(n)>1.0e-10; normal=unit(n); break; end
        end
        raise ArgumentError,"#{id} 存在退化多边形" unless normal
        if fp.any? { |p| dot(sub(p,fp[0]),normal).abs > 0.0001 }
          raise ArgumentError,"#{id} 的非平面多边形必须提供三角化 faces"
        end
      end
      sum+polygon_area(fp)
    end
    raise ArgumentError,"#{id} 面积为零" if area<1.0e-10
    rectangular=rectangle_refs ? validate_rectangle_panel(raw,points,faces,axis_z,area,rectangle_refs) : {}
    width=finite_number(raw['width_m'],"#{id} width_m")
    length=finite_number(raw['length_m'],"#{id} length_m")
    if width <= 0 || length <= 0 || width > max_width+EPS_M || length > max_length+EPS_M
      raise ArgumentError,"#{id} 尺寸超限或无效：#{width} × #{length} m（限 #{max_width} × #{max_length} m）"
    end
    reported=finite_number(raw['area_m2'],"#{id} area_m2")
    if (area-reported).abs > [0.0001,area*0.001].max
      raise ArgumentError,"#{id} 面积与几何不一致：报表 #{reported} / 几何 #{area} m²"
    end
    if area > width*length*1.001+0.00001
      raise ArgumentError,"#{id} 表面积大于标注展开包络尺寸，请检查展开口径"
    end
    # Use a 1-micrometre geometric tolerance for flat panels, matching the
    # generator. A 0.1-mm tolerance mislabeled slightly curved fan panels as
    # flat blanks and wrongly rejected valid small-width curved pieces.
    planar=strict_planar || local.all? { |p| p[2].abs<0.000001 }
    # Only after strict input validation: remove sub-micrometre serialization
    # noise so every V7/V8 component is constructed in a single exact local plane.
    local.each { |p| p[2]=0.0 } if strict_planar
    if planar
      # Validate real intrinsic extents rather than trusting metadata alone.
      fits=false
      candidate_edges=[]
      faces.each do |f|
        f.each_with_index do |a,j|
          candidate_edges << [a,f[(j+1)%f.length]].sort
        end
      end
      candidate_edges.uniq.each do |a,b|
        edge=sub(points[b],points[a])
        next if norm(edge)<1.0e-10
        u=unit(edge); v=unit(cross(axis_z,u))
        us=points.map { |q| dot(sub(q,origin),u) }
        vs=points.map { |q| dot(sub(q,origin),v) }
        dims=[us.max-us.min,vs.max-vs.min].sort
        fits=true if dims[0] <= max_width+EPS_M && dims[1] <= max_length+EPS_M
      end
      fits ||= fits_planar_envelope?(local,max_width,max_length)
      raise ArgumentError,"#{id} 的实际几何包络超过 #{max_width} × #{max_length} m" unless fits
    end
    # 0.1 micrometre rounding only absorbs floating-point transform noise;
    # component reuse never relies on rounded size/type labels alone.
    signature=JSON.generate([local.map { |p| p.map { |n| (n*1.0e7).round } },faces])
    {'id'=>id,'type_id'=>raw.fetch('type_id','未分类').to_s,'layout_shape'=>raw['layout_shape'],
     'roof_id'=>raw.fetch('roof_id','屋面').to_s,'width_m'=>width,'length_m'=>length,
     'area_m2'=>area,'local'=>local,'origin'=>origin,'x'=>axis_x,'y'=>axis_y,'z'=>axis_z,
     'faces'=>faces,'planar'=>planar,'strict_planar'=>strict_planar,'plane_error_mm'=>plane_error*1000.0,'needs_bend'=>(!strict_planar && raw['needs_bend']==true),'below_nominal_min_width'=>width<0.5-EPS_M,
     'signature'=>Digest::SHA256.hexdigest(signature)}.merge(rectangular)
  end

  def normalized_title(name)
    File.basename(name.to_s).sub(/\.skp\z/i,'').strip.downcase
  end

  def import_panels
    model=Sketchup.active_model
    if model.active_path
      UI.messagebox('请先退出群组/组件编辑状态，再导入世界坐标的铝板方案。')
      return
    end
    path=UI.openpanel('打开网页导出的铝板分隔 JSON',nil,'JSON|*.json||')
    return unless path
    raise ArgumentError,'JSON 文件过大（上限 500 MB）' if File.size(path)>500*1024*1024
    data=JSON.parse(File.open(path,'r:UTF-8') { |f| f.read }.sub(/\A\uFEFF/,''))
    raise ArgumentError,'文件必须是 roof-panels-1，单位必须为 m；不能导入屋面源网格 JSON' unless
      data.is_a?(Hash) && data['format']=='roof-panels-1' && data['unit']=='m'
    panels=data['panels']
    raise ArgumentError,'panels 必须是非空数组（最多 500000 块）' unless
      panels.is_a?(Array) && !panels.empty? && panels.length<=500000
    limits=sizing_limits(data)
    geometry=geometry_limits(data)
    rectangle_refs=geometry['rectangles'] ? exterior_references(data) : nil
    Sketchup.status_text="正在校验 #{panels.length} 块铝板…"
    prepared=panels.each_with_index.map do |raw,i|
      canonical_panel(raw,i,limits['max_width_m'],limits['max_length_m'],geometry['strict_planar'],rectangle_refs)
    end
    raise ArgumentError,'铝板编号重复' unless prepared.map { |p| p['id'] }.uniq.length==prepared.length
    source=data['source'].is_a?(Hash) ? data['source'] : {}
    source_name=(source['model_name'] || source['name'] || '未标明源模型').to_s
    mismatched=normalized_title(source_name)!=normalized_title(model.title)
    mismatched ||= source['model_guid'] && source['model_guid'].to_s!=model.guid.to_s
    count=prepared.length
    area=prepared.inject(0.0) { |sum,p| sum+p['area_m2'] }
    curved=prepared.count { |p| !p['planar'] }
    narrow=prepared.count { |p| p['below_nominal_min_width'] }
    warning=mismatched ? "【源模型身份未匹配】\n请确认方案确实对应本模型，坐标、比例及版本一致。\n\n" : ''
    warning+="方案来源：#{source_name}\n当前模型：#{model.title}\n" +
      "将新增 #{count} 块铝板，净表面积 #{format('%.3f',area)} m²。\n" +
      "现有几何不会被删除、移动或替换；可整体撤销。\n"
    if limits['v8'] || limits['v7'] || limits['v6'] || limits['v5']
      relation=limits['ratio_locked'] ? "锁定长宽比 #{format('%.8g',limits['ratio'])}∶1" : '长宽独立输入'
      warning+="所选输入尺寸：#{format('%.0f',limits['nominal_width_mm'])} × #{format('%.0f',limits['nominal_length_mm'])} mm（#{relation}）。\n"
      warning+="其中 #{narrow} 块实际短边不足 500 mm，按输入尺寸和边界裁切保留；500 mm 仅为旧版参考标记，V6/V7/V8 不设此下限。\n" if narrow>0 && (limits['v8'] || limits['v7'] || limits['v6'])
      warning+="其中 #{narrow} 块实际短边不足 500 mm，按输入尺寸和边界裁切保留；500 mm 仅为 V5 输入宽度下限。\n" if narrow>0 && limits['v5']
    elsif limits['v4']
      warning+="所选标准尺寸：#{format('%.0f',limits['nominal_width_mm'])} × #{format('%.0f',limits['nominal_length_mm'])} mm（长=3×宽）。\n"
      warning+="其中 #{narrow} 块实际宽度不足 500 mm，作为边界/收边深化板保留；500 mm 是调节器标准宽度下限。\n" if narrow>0
    end
    warning+="其中 #{curved} 块为非平面网格；尺寸为几何路径上界；桥接未验证可展性及加工展开尺寸。\n" if curved>0
    warning+="V7 全部按单一平直板校验；褶皱顶边分缝声明为对齐，原折线位于板件边界。\n" if limits['v7']
    if limits['v8']
      trims=prepared.count { |p| p['is_exterior_arc_trim'] }
      warning+="V8 为经用户批准的重构屋面：内板为真实平面矩形，#{trims} 块仅在屋面外弧线修边。\n" +
        "新平行折线及共用分缝属于重构方案，与原屋面存在几何差异；请核对重构方案叠合。\n" +
        "相邻内板尺寸差≤10%及全屋面对缝由独立几何报告校核，桥接不重新排板。\n"
    end
    warning+="继续导入？"
    return unless UI.messagebox(warning,MB_YESNO)==IDYES
    default_layer=limits['v8'] ? 'RP_V8矩形铝板_重构屋面' : (limits['v7'] ? 'RP_V7平直铝板_顶边对缝' : (limits['v6'] ? 'RP_V6自由尺寸铝板_中心矩形' :
      (limits['v5'] ? 'RP_V5自由尺寸铝板_放射随形' :
       (limits['v4'] ? 'RP_V4可调铝板_放射随形' : 'RP_V3屋面铝板_放射随形'))))
    settings=UI.inputbox(['新增方案图层名','显示抬高（mm；0 为原位，最多 20）'],
                         [default_layer,0.0],'铝板方案导入设置')
    return unless settings
    layer_name=settings[0].to_s.strip
    raise ArgumentError,'图层名不能为空' if layer_name.empty?
    offset=Float(settings[1])/1000.0
    raise ArgumentError,'显示抬高须在 0–20 mm 之间' unless offset.finite? && offset>=0 && offset<=0.02
    operation=false
    begin
      model.start_operation('导入屋面铝板分隔',true)
      operation=true
      layer=model.layers[layer_name] || model.layers.add(layer_name)
      group=model.entities.add_group
      version_label=limits['v8'] ? 'V8矩形铝板重构屋面方案' : (limits['v7'] ? 'V7平直铝板顶边对缝方案' : (limits['v6'] ? 'V6自由尺寸中心矩形铝板方案' :
        (limits['v5'] ? 'V5自由尺寸放射随形铝板方案' :
         (limits['v4'] ? 'V4可调放射随形铝板方案' : 'V3放射随形铝板方案'))))
      group.name="#{version_label} #{Time.now.strftime('%Y%m%d_%H%M%S')}"
      group.layer=layer
      group.set_attribute(ATTR,'source',JSON.generate(source))
      group.set_attribute(ATTR,'layout',JSON.generate(data['layout'] || {}))
      group.set_attribute(ATTR,'panel_study_version',data['panel_study_version'].to_s)
      group.set_attribute(ATTR,'sizing_rule',JSON.generate(data['sizing_rule'])) if limits['v4'] || limits['v5'] || limits['v6'] || limits['v7'] || limits['v8']
      group.set_attribute(ATTR,'geometry_rule',JSON.generate(data['geometry_rule'])) if limits['v7'] || limits['v8']
      group.set_attribute(ATTR,'max_width_m',limits['max_width_m'])
      group.set_attribute(ATTR,'max_length_m',limits['max_length_m'])
      group.set_attribute(ATTR,'below_nominal_min_width_count',narrow)
      group.set_attribute(ATTR,'panel_count',count)
      group.set_attribute(ATTR,'net_surface_area_m2',area)
      group.set_attribute(ATTR,'display_offset_m',offset)
      definitions={}
      roof_groups={}
      prepared.each_with_index do |p,i|
        definition=definitions[p['signature']]
        unless definition
          definition=model.definitions.add("RP_#{p['type_id']}_#{p['signature'][0,10]}")
          # Build large only inside the definition so short clipped mesh edges
          # can be created, then scale the instance back to exact physical size.
          # All calculations/signatures/attributes retain the original metres.
          local_points=p['local'].map do |point|
            point_m(point.map { |coordinate| coordinate*BUILD_SCALE })
          end
          p['faces'].each do |indices|
            face=definition.entities.add_face(indices.map { |v| local_points[v] })
            raise ArgumentError,"无法生成 #{p['id']} 的面；可能存在细碎边或自交" unless face
          end
          definition.entities.grep(Sketchup::Edge).each do |edge|
            if edge.faces.length==2
              angle=edge.faces[0].normal.angle_between(edge.faces[1].normal)
              if angle<=Math::PI/18.0+1.0e-9
                edge.hidden=true
                edge.soft=true
                edge.smooth=true
              end
            end
          end
          definition.set_attribute(ATTR,'shape_signature',p['signature'])
          definition.set_attribute(ATTR,'type_id',p['type_id'])
          definitions[p['signature']]=definition
        end
        roof_group=roof_groups[p['roof_id']]
        unless roof_group
          roof_group=group.entities.add_group
          roof_group.name=p['roof_id']
          roof_groups[p['roof_id']]=roof_group
        end
        origin=p['origin'].each_with_index.map { |v,k| v+p['z'][k]*offset }
        frame=Geom::Transformation.axes(point_m(origin),vector(p['x']),vector(p['y']),vector(p['z']))
        transform=frame*Geom::Transformation.scaling(1.0/BUILD_SCALE)
        instance=roof_group.entities.add_instance(definition,transform)
        instance.name=p['id']
        %w[id type_id roof_id width_m length_m area_m2 planar strict_planar plane_error_mm needs_bend below_nominal_min_width layout_shape is_rectangle is_exterior_arc_trim].each do |key|
          instance.set_attribute(ATTR,key,p[key]) unless p[key].nil?
        end
        instance.set_attribute(ATTR,'arc_edge_ids',JSON.generate(p['arc_edge_ids'])) if limits['v8']
        Sketchup.status_text="正在导入铝板 #{i+1} / #{count}" if i%100==0
      end
      model.commit_operation
      operation=false
      model.selection.clear
      model.selection.add(group)
      UI.messagebox("导入完成：#{count} 块铝板，#{definitions.length} 个精确形状组件定义。\n" +
        "净表面积：#{format('%.3f',area)} m²。\n" +
        "显示抬高：#{format('%.1f',offset*1000)} mm（只用于模型查看）。\n" +
        "原屋面和原分隔保留。可在图层中切换新增方案，并整体撤销。\n" +
        "此步骤未保存 SKP；请核对叠合和数据后另存为新版本。")
      group
    rescue => error
      model.abort_operation if operation
      raise error
    ensure
      Sketchup.status_text=''
    end
  rescue => error
    Sketchup.status_text=''
    UI.messagebox("铝板导入失败，未保留部分导入：#{error.message}")
    nil
  end

  unless file_loaded?(__FILE__)
    menu=UI.menu('Plugins').add_submenu('屋面铝板统计桥接')
    menu.add_item('导出选中屋面 JSON…') { export_selected }
    menu.add_item('导入铝板分隔 JSON…') { import_panels }
    file_loaded(__FILE__)
  end
end
