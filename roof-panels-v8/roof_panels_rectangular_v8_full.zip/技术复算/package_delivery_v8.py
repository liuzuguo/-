"""Package the authorized rebuilt rectangular roof and its actual validations."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import hashlib,json,shutil
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'releases'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def package():
    geo=json.loads((ROOT/'dynamic_geometry_validation.json').read_text())
    browser=json.loads((ROOT/'browser_validation_v8.json').read_text())
    guard=json.loads((ROOT/'runtime_guard_validation_v8.json').read_text())
    bridge=json.loads((ROOT/'bridge_numeric_validation.json').read_text())
    manifest=json.loads((ROOT/'build_manifest.json').read_text())
    assert geo['all_passed'] and bridge['all_passed'] and guard['passed'] and browser['passed'] and not browser['errors']
    assert geo['worker_sha256']==browser['worker_sha256']==guard['worker_sha256']==bridge['worker_sha256']==manifest['worker_sha256']==sha(ROOT/'panel-worker.js')
    assert geo['html_sha256']==browser['html_sha256']==guard['html_sha256']==bridge['html_sha256']==manifest['html_sha256']==sha(ROOT/'app.html')
    assert bridge['export_sha256']==sha(ROOT/'1102e_V8矩形铝板分隔.json')
    assert geo['independent_reconstruction_sha256']==sha(ROOT/'reconstructionData.json')
    default=json.loads((ROOT/'default-study.json').read_text())['candidates'][0]
    sm=default['summary'];assert sm['curved_panel_count']==sm['ridge_misalignment_count']==0
    assert sm['neighbor_max_relative_difference']<=.1 and len(default['instances'])==4
    OUT.mkdir(exist_ok=True)
    guide=f'''# 1102e 屋面铝板 V8 · 矩形模数与尺寸均衡

## 打开

解压后用新版 Edge 或 Chrome 打开根目录 **app.html**。模型、重构参数、计算程序和SketchUp桥接全部内嵌，下载后无需联网取模型。单文件HTML与ZIP中的app.html相同。

## 本次设计结果

已按用户明确允许的方向重构屋面，优先保证实际长方形板和相邻标准板尺寸接近。原来的放射褶皱改为直线平行折面，保留原建筑位置作为参考；原屋面几何不再保持不变。

内部所有板件均为**实际平直长方形**：四角90°、对边平行等长、顶点共面，并非把梯形包络或参数四边形命名为长方形。仅与真实外圆弧接触的修边板允许非矩形；内部原三角面和折线不会被当成“外边缘”例外。

标准长方形使用统一模数；全局排缝位置共同调整，折面两侧横缝对齐，内部相邻板实际短/长边尺寸差控制在10%以内。圆弧修边沿同一模数板裁切，净形状和净尺寸另列，边缘裁切后的净尺寸不计入内部邻板均衡指标。

默认输入1000×3000mm：全屋面{sm['panel_count']:,}块，其中内部长方形{sm['rectangle_panel_count']:,}块、外圆弧修边{sm['arc_trim_panel_count']:,}块；内部邻板最大尺寸差{sm['neighbor_max_relative_difference']*100:.2f}%，顶边错缝0处。通过全局排缝微调减少圆弧小碎板，仍在清单中保留实际小板标记，供深化检查。

同一净尺寸的长方形归为同一几何板型，原规格和修边净尺寸分开记录。数量、面积、尺寸和模型来自当前真实几何。

## 尺寸调节与交互

宽度和长度可独立输入正数，按1mm取整，已取消1500mm宽度上限。输入尺寸为两方向板材上界，系统为整齐收边自动均衡实际模数；实际尺寸区间显示在输入区下方。输入越大，重构折面的分段也随之变化，模型会真实重新生成。

需要比例联动时勾选“锁定长宽比”，输入 `2.5`、`5:2`、`4:5` 等正比例（长度÷宽度），支持改宽带长和改长带宽。取消后恢复独立输入。

单击板件：选中为橘色，其他同净尺寸为红色，模型角标与右侧同时显示数量。尺寸按实际短/长边上界上取整到1mm分组；修边板按修边后的实际尺寸参与此匹配。屋顶范围可选全部或A–D之一，可隔离同尺寸板并取消高亮。

保留上下左右平移、长按、1/5/10m步长、回中、单屋顶顶视、截图、方案对比及保存恢复。视图移动不改变模型导出坐标。可读取V5–V7尺寸参数，按V8重构规则重新计算，不直接沿用旧版三角分格。

数值范围为1–1,000,000,000mm；极小尺寸预计超过500,000块时提示调整并保留上次成功模型。此范围是计算保护，不是加工规格建议。

## 重构变化与面积

默认方案新屋面净面积约{sm['surface_area_m2']:,.2f}m²，原参考屋面约{sm['source_reference_area_m2']:,.2f}m²，变化{sm['surface_area_m2']-sm['source_reference_area_m2']:,.2f}m²。默认方案与原屋面的顶点最大高度变化约{sm['source_vertex_max_vertical_deviation_m']:.3f}m、面积加权均方根约{sm['source_centroid_area_weighted_rms_vertical_deviation_m']:.3f}m。

这些是默认输入的实测结果。其他输入会改变分段和面积，界面会重新列出高度变化；例如完整包2500×6000mm样例的最大变化约5.246m、均方根约1.341m、新面积约40,251.21m²。

原外轮廓直边按设计轴线整理，最大平面修正约4.574mm；弧边按原外轮廓线段定义。四个完整屋顶使用刚体变换布置，背景仍为原建筑，仅供位置参考。

## 导出和SketchUp

CSV分别提供尺寸/板型汇总和逐板明细，逐板含净尺寸、原规格、净面积和板件形式。JSON、DAE按当前已应用的尺寸和显示屋顶范围导出，坐标为原世界坐标系中的重构屋面。DAE坐标保留9位小数。

完整包 `示例_2500x6000_矩形重构` 含实际导出的2,924块模型和清单，其中2,764块长方形、160块圆弧修边，内部邻板尺寸差约0.59%；网页默认仍是1000×3000mm。

SketchUp桥接对V8实际坐标重新检查平面、四直角、拓扑和真实3D外弧修边，拒绝伪造的“矩形”标签或内部异形板。新图层为 `RP_V8矩形铝板_重构屋面`。导入前请另存模型副本；隐藏原屋面和旧分隔，单独查看重构结果。不会自动删除原模型。V3–V7旧格式保持其旧规则兼容。

## 校核和深化

五组尺寸均通过独立实际几何校核：内部四直角长方形、全部平直、外圆弧裁切来源、新轮廓完整覆盖且无重叠、折面两侧对缝、内部邻板尺寸差、四屋顶布置与统计。五组中内部邻板最大差约3.49%，均低于10%。

浏览器通过自由输入、比例、橘红真实像素/数量、四屋顶点选、移动、保存恢复和实际CSV/JSON/DAE导出；完全内嵌的离线HTTP访问无外部请求。云端浏览器策略阻止file://导航，未在云端直接验证本地文件启动。普通桌面浏览器请按上文下载后打开。

桥接已做语法解析与数值预检；本环境未安装SketchUp，未在SketchUp2018实机运行。板缝、折边、板厚、支承、龙骨及开孔仍需与重构屋面一并深化，导出不是直接下料文件。
'''
    (OUT/'使用说明.md').write_text(guide)
    (OUT/'打开说明.txt').write_text('1102e 屋面铝板 V8 矩形重构版\n\n解压后用新版Edge或Chrome打开 app.html。\n已按授权重构屋面：内部实际平直长方形，邻近标准板尺寸差≤10%；外圆弧修边净尺寸单列。\n保留长宽自由输入、自定义比例、橘红同尺寸联选、移动和统计导出。\n注意隐藏旧版屋面后查看重构模型，原放射褶皱已改变。\n',encoding='utf-8-sig')
    shutil.copy2(ROOT/'app.html',OUT/'roof_panels_rectangular_v8.html')
    for src,dst in [('1102e_V8矩形分格预览.png','roof_panels_rectangular_v8_preview.png'),('1102e_V8圆弧修边预览.png','roof_panels_rectangular_v8_arc.png'),('1102e_V8同尺寸联选预览.png','roof_panels_rectangular_v8_selection.png')]:shutil.copy2(ROOT/src,OUT/dst)
    basic={'app.html':ROOT/'app.html','使用说明.md':OUT/'使用说明.md','打开说明.txt':OUT/'打开说明.txt','sketchup_bridge.rb':ROOT/'sketchup_bridge.rb','SKETCHUP使用说明.md':ROOT/'SKETCHUP使用说明.md'}
    full=dict(basic)
    for name in ['1102e_V8矩形铝板分隔.json','1102e_V8矩形铝板分隔.dae','1102e_V8逐板统计.csv']:full['示例_2500x6000_矩形重构/'+name]=ROOT/name
    for name in ['1102e_V8矩形分格预览.png','1102e_V8圆弧修边预览.png','1102e_V8同尺寸联选预览.png']:full[name]=ROOT/name
    for name in ['app.template.html.txt','renderer-v8.js','panel-worker.js','build_delivery.py','default-study.json','reconstructionData.json','modelData.json','source_uv_complete.json','context_lite.bin.gz','context_lite.meta.json','worker_generate.mjs','planar_rectangle.py','validate_dynamic_geometry_v8.py','validate_rectangles_and_neighbors.py','dynamic_geometry_validation.json','browser_smoke_v8.py','browser_validation_v8.json','browser_runtime_guard_v8.py','runtime_guard_validation_v8.json','validate_bridge_numeric_v8.py','bridge_numeric_validation.json','bridge_syntax_validation.json','v8_selection_validate.mjs','v8_selection_validation.json','build_manifest.json','package_delivery_v8.py','validate_delivery_v8.py']:
        full['技术复算/'+name]=ROOT/name
    for p in sorted((ROOT/'validation_reports').glob('*.json')):full['技术复算/validation_reports/'+p.name]=p
    full['技术复算/geometry-requirements.txt']=ROOT.parent/'roof-panel-studio-v3/geometry-requirements.txt'
    for suffix,files in [('web',basic),('full',full)]:
        dest=OUT/f'roof_panels_rectangular_v8_{suffix}.zip'
        with ZipFile(dest,'w',ZIP_DEFLATED,compresslevel=9) as z:
            for name,p in files.items():assert p.is_file(),p;z.write(p,name)
        with ZipFile(dest) as z:assert z.testzip() is None
    items=[{'file':p.name,'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(OUT.iterdir()) if p.is_file() and p.name!='checksums.json']
    (OUT/'checksums.json').write_text(json.dumps(items,ensure_ascii=False,indent=2));print(json.dumps(items,ensure_ascii=False,indent=2))

if __name__=='__main__':package()
