"""Numerical mirror of V8 rectangular SketchUp preflight; no SketchUp execution.

Checks actual world-coordinate exports and local templates, plus negative shape
fixtures and legacy V3–V7 compatibility. Ruby syntax is parsed, never executed.
"""
import argparse
import copy
import hashlib
import json
import math
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EXPORT = ROOT / '1102e_V8矩形铝板分隔.json'
BRIDGE = ROOT / 'sketchup_bridge.rb'
EPS_M = 0.00001
STRICT_PLANAR_M = 1e-7
RECTANGLE_ANGLE_EPS = 1e-7
ARC_REFERENCE_M = 1e-6


def sub(a, b):
    return [a[k] - b[k] for k in range(3)]


def dot(a, b):
    return sum(a[k] * b[k] for k in range(3))


def cross(a, b):
    return [a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0]]


def norm(a):
    return math.sqrt(dot(a, a))


def unit(a):
    size = norm(a)
    if size < 1.0e-10:
        raise ValueError('degenerate unit vector')
    return [v / size for v in a]


def polygon_area(points):
    total = [0., 0., 0.]
    for i, p in enumerate(points):
        cr = cross(p, points[(i+1) % len(points)])
        for k in range(3):
            total[k] += cr[k]
    return norm(total) * .5


def fits_planar_envelope(local, width, length):
    # Same critical angles and interval midpoints as fits_planar_envelope?.
    points = [p[:2] for p in local]
    angles = [0.]
    limits = [length + EPS_M, width + EPS_M]
    for i, p in enumerate(points):
        for q in points[i+1:]:
            dx, dy = q[0] - p[0], q[1] - p[1]
            radius = math.sqrt(dx*dx + dy*dy)
            if radius > math.sqrt(limits[0]**2 + limits[1]**2) + 1.0e-9:
                return False
            if radius < 1.0e-10:
                continue
            alpha = math.atan2(dy, dx)
            for k, limit in enumerate(limits):
                if radius <= limit:
                    continue
                center = alpha + (0. if k == 0 else math.pi / 2.)
                delta = math.acos(max(-1., min(1., limit / radius)))
                angles.extend([(center-delta) % math.pi, (center+delta) % math.pi])
    angles = sorted(set(angles))
    candidates = angles.copy()
    for i, a in enumerate(angles):
        b = angles[0] + math.pi if i == len(angles)-1 else angles[i+1]
        candidates.append(((a+b)*.5) % math.pi)
    for angle in candidates:
        c, si = math.cos(angle), math.sin(angle)
        xs = [q[0]*c+q[1]*si for q in points]
        ys = [-q[0]*si+q[1]*c for q in points]
        if max(xs)-min(xs) <= limits[0]+1.0e-9 and max(ys)-min(ys) <= limits[1]+1.0e-9:
            return True
    return False


def panel_boundary(points, faces):
    edges, used = {}, set()
    for face in faces:
        for j, a in enumerate(face):
            b = face[(j+1) % len(face)]
            used.add(a)
            edges.setdefault(tuple(sorted((a, b))), []).append((a, b))
    assert len(used) == len(points), 'unused mesh vertex'
    boundary = []
    for items in edges.values():
        if len(items) == 1:
            boundary.append(items[0])
        else:
            assert len(items) == 2 and items[0] == tuple(reversed(items[1])), 'duplicate/reversed/nonmanifold mesh edge'
    assert len(boundary) >= 3, 'no valid single boundary'
    outgoing, incoming = {}, {}
    for a, b in boundary:
        assert a not in outgoing and b not in incoming, 'branched/overlapping boundary'
        outgoing[a], incoming[b] = b, a
    start = current = boundary[0][0]
    ring = []
    while True:
        assert current not in ring and current in outgoing, 'open/repeated boundary'
        ring.append(current)
        current = outgoing[current]
        if current == start:
            break
    assert len(ring) == len(boundary), 'hole or multiple boundaries'
    return [points[i] for i in ring]


def simplified_corners(ring):
    result = list(ring)
    while True:
        index = None
        for i, b in enumerate(result):
            ab, bc = sub(b, result[i-1]), sub(result[(i+1) % len(result)], b)
            assert norm(ab) >= 1e-10 and norm(bc) >= 1e-10, 'zero boundary edge'
            if dot(ab, bc) > 0 and norm(cross(ab, bc)) <= RECTANGLE_ANGLE_EPS*norm(ab)*norm(bc):
                index = i
                break
        if index is None or len(result) <= 3:
            return result
        result.pop(index)


def rectangle_corners(corners):
    if len(corners) != 4:
        return False
    edges = [sub(corners[(i+1) % 4], p) for i, p in enumerate(corners)]
    lengths = [norm(e) for e in edges]
    if min(lengths) < 1e-10:
        return False
    for i in range(4):
        if abs(dot(edges[i], edges[(i+1) % 4])) > RECTANGLE_ANGLE_EPS*lengths[i]*lengths[(i+1) % 4]:
            return False
    for i in range(2):
        if dot(edges[i], edges[i+2]) >= 0 or norm(cross(edges[i], edges[i+2])) > RECTANGLE_ANGLE_EPS*lengths[i]*lengths[i+2]:
            return False
        if abs(lengths[i]-lengths[i+2]) > max(STRICT_PLANAR_M, lengths[i]*RECTANGLE_ANGLE_EPS):
            return False
    return True


def exterior_references(data):
    roofs = data.get('roofs')
    assert isinstance(roofs, list) and roofs, 'V8 world roof references required'
    result = {}
    for raw in roofs:
        assert isinstance(raw, dict), 'roof reference not an object'
        roof_id = str(raw.get('roof_id', ''))
        assert roof_id and roof_id not in result, 'empty/duplicate roof reference ID'
        exterior = raw.get('exterior')
        assert isinstance(exterior, list) and len(exterior) >= 3, 'invalid roof exterior'
        assert all(isinstance(p, list) and len(p) == 3 and all(type(v) in (int, float) and math.isfinite(v) for v in p) for p in exterior), 'roof reference requires finite XYZ metres'
        exterior = list(exterior)
        if norm(sub(exterior[0], exterior[-1])) <= 1e-10:
            exterior.pop()
        indices = raw.get('arc_edge_indices')
        assert isinstance(indices, list) and len(set(indices)) == len(indices) and all(type(i) is int and 0 <= i < len(exterior) for i in indices), 'invalid roof arc indices'
        result[roof_id] = dict(exterior=exterior, arc_edge_indices=indices)
    return result


def point_on_reference_segment(p, a, b):
    edge, d = sub(b, a), sub(p, a)
    length2 = sum(v*v for v in edge)
    if length2 < 1e-20:
        return False
    t = dot(d, edge)/length2
    if t < -ARC_REFERENCE_M/math.sqrt(length2) or t > 1+ARC_REFERENCE_M/math.sqrt(length2):
        return False
    return norm(cross(d, edge)) <= ARC_REFERENCE_M*math.sqrt(length2)


def validate_rectangle_panel(raw, points, faces, normal, area, refs):
    assert raw.get('kind') == 'planar', 'V8 kind must be planar'
    ring = panel_boundary(points, faces)
    assert abs(polygon_area(ring)-area) <= max(1e-9, area*1e-8), 'mesh/boundary area mismatch'
    rectangle = rectangle_corners(simplified_corners(ring))
    if rectangle:
        assert raw.get('is_rectangle') is True and raw.get('layout_shape') == 'planar_rectangle', 'V8 actual rectangle requires correct rectangle metadata'
        assert raw.get('is_exterior_arc_trim') is not True and not raw.get('arc_edge_ids'), 'rectangle cannot claim arc exemption'
        return dict(is_rectangle=True, is_exterior_arc_trim=False, arc_edge_ids=[])
    assert raw.get('is_rectangle') is False and raw.get('layout_shape') == 'outer_arc_trim' and raw.get('is_exterior_arc_trim') is True, 'nonrectangular internal panel'
    reference = refs.get(str(raw.get('roof_id')))
    assert reference, 'arc trim roof reference missing'
    indices = raw.get('arc_edge_ids')
    assert isinstance(indices, list) and indices and len(indices) == len(set(indices)) and all(type(i) is int and i in reference['arc_edge_indices'] for i in indices), 'arc trim requires valid original arc IDs'
    exterior = reference['exterior']
    on_arc = [any(point_on_reference_segment(a, exterior[j], exterior[(j+1) % len(exterior)]) and
                  point_on_reference_segment(ring[(i+1) % len(ring)], exterior[j], exterior[(j+1) % len(exterior)])
                  for j in indices) for i, a in enumerate(ring)]
    assert any(on_arc), 'nonrectangle does not follow claimed exterior arc'
    straight = [(i, sub(ring[(i+1) % len(ring)], p)) for i, p in enumerate(ring) if not on_arc[i]]
    assert straight, 'arc trim has no rectangular stock side'
    u = unit(max(straight, key=lambda item:norm(item[1]))[1])
    v = unit(cross(normal, u))
    us = [dot(sub(p, ring[0]), u) for p in ring]
    vs = [dot(sub(p, ring[0]), v) for p in ring]
    for i, edge in straight:
        direction = unit(edge)
        assert min(abs(dot(direction, u)), abs(dot(direction, v))) <= RECTANGLE_ANGLE_EPS, 'non-arc oblique/trapezoid cut'
        j = (i+1) % len(ring)
        on_stock = abs(us[i]-us[j]) <= ARC_REFERENCE_M and any(abs(us[i]-n) <= ARC_REFERENCE_M for n in (min(us), max(us)))
        on_stock |= abs(vs[i]-vs[j]) <= ARC_REFERENCE_M and any(abs(vs[i]-n) <= ARC_REFERENCE_M for n in (min(vs), max(vs)))
        assert on_stock, 'illegal interior notch/cut'
    return dict(is_rectangle=False, is_exterior_arc_trim=True, arc_edge_ids=indices)


def check(raw, max_width=1.5, max_length=3., strict_planar=False, rectangle_refs=None):
    points = raw['vertices']
    assert 3 <= len(points) <= 20000, 'invalid vertices'
    assert all(len(p) == 3 and all(isinstance(v, (int, float)) and math.isfinite(v) and abs(v) <= 1e6 for v in p) for p in points), 'invalid coordinate'
    faces = raw.get('faces', [list(range(len(points)))])
    assert faces and all(len(f) >= 3 and len(set(f)) == len(f) and all(type(i) is int and 0 <= i < len(points) for i in f) for f in faces), 'invalid faces'
    origin = points[faces[0][0]]
    axis_x = axis_z = None
    largest_normal = 0.
    for f in faces:
        a = points[f[0]]
        for j in range(1, len(f)-1):
            edge = sub(points[f[j]], a)
            normal = cross(edge, sub(points[f[j+1]], a))
            magnitude = norm(normal)
            if magnitude > 1.0e-10 and (not strict_planar or magnitude > largest_normal):
                axis_x, axis_z = unit(edge), unit(normal)
                if strict_planar:
                    origin = a
                largest_normal = magnitude
                if not strict_planar:
                    break
        if axis_x and not strict_planar:
            break
    assert axis_x, 'degenerate panel'
    axis_y = unit(cross(axis_z, axis_x))
    local = [[dot(sub(p, origin), axis) for axis in (axis_x, axis_y, axis_z)] for p in points]
    height = max(abs(p[2]) for p in local)
    if strict_planar:
        assert height <= STRICT_PLANAR_M, 'V7 plate is not planar within0.0001mm'
        for f in faces:
            a = points[f[0]]
            for j in range(1, len(f)-1):
                n = cross(sub(points[f[j]], a), sub(points[f[j+1]], a))
                assert norm(n) > 1e-12 and dot(n, axis_z) > 0, 'V7 reversed or degenerate face'
        assert raw.get('needs_bend') is not True, 'V7 fold metadata conflicts with flat requirement'
    area = 0.
    for f in faces:
        fp = [points[i] for i in f]
        if len(fp) > 3:
            normal = None
            for j in range(1, len(fp)-1):
                n = cross(sub(fp[j], fp[0]), sub(fp[j+1], fp[0]))
                if norm(n) > 1.0e-10:
                    normal = unit(n)
                    break
            assert normal, 'degenerate polygon'
            assert all(abs(dot(sub(p, fp[0]), normal)) <= .0001 for p in fp), 'nonplanar polygon requires triangulation'
        area += polygon_area(fp)
    assert area >= 1e-10, 'zero area'
    rectangular = validate_rectangle_panel(raw, points, faces, axis_z, area, rectangle_refs) if rectangle_refs is not None else {}
    width, length, reported = [raw[k] for k in ('width_m', 'length_m', 'area_m2')]
    assert all(isinstance(v, (int, float)) and math.isfinite(v) for v in (width, length, reported)), 'invalid metadata'
    assert 0 < width <= max_width+EPS_M and 0 < length <= max_length+EPS_M, 'dimension limit'
    assert abs(area-reported) <= max(.0001, area*.001), 'area mismatch'
    assert area <= width*length*1.001+.00001, 'area greater than envelope'
    planar = strict_planar or height < .000001
    if strict_planar:
        for p in local:
            p[2] = 0.
    fitted_by = None
    if planar:
        edges = sorted({tuple(sorted((a, f[(j+1) % len(f)]))) for f in faces for j, a in enumerate(f)})
        for a, b in edges:
            edge = sub(points[b], points[a])
            if norm(edge) < 1e-10:
                continue
            u = unit(edge)
            v = unit(cross(axis_z, u))
            us = [dot(sub(q, origin), u) for q in points]
            vs = [dot(sub(q, origin), v) for q in points]
            dims = sorted((max(us)-min(us), max(vs)-min(vs)))
            if dims[0] <= max_width+EPS_M and dims[1] <= max_length+EPS_M:
                fitted_by = 'face_edge'
                # Ruby continues all edges even after finding a fit.
        if not fitted_by and fits_planar_envelope(local, max_width, max_length):
            fitted_by = 'critical_angular_intervals'
        assert fitted_by, 'actual planar envelope exceeds selected caps'
    return dict(below_nominal_min_width=width < .5-EPS_M, planar=planar, first_plane_deviation_m=height, area=area,
                area_error_m2=abs(area-reported), fitted_by=fitted_by,
                engine_curved=raw.get('nonplanarity_mm', 0) >= .001, **rectangular)


def finite_number(value):
    assert type(value) in (int, float) and math.isfinite(value), 'not a finite number'
    return float(value)


def sizing_limits(data):
    """Mirror Ruby sizing_limits: V6–V8 arbitrary dimensions; legacy rules intact."""
    rule = data.get('sizing_rule')
    v8 = str(data.get('panel_study_version', '')).lower().startswith('v8')
    v7 = str(data.get('panel_study_version', '')).lower().startswith('v7')
    v6 = str(data.get('panel_study_version', '')).lower().startswith('v6')
    v5 = str(data.get('panel_study_version', '')).lower().startswith('v5')
    if v8 or v7 or v6 or v5:
        assert isinstance(rule, dict), 'V5 sizing_rule required'
        width = finite_number(rule['nominal_width_mm'])
        length = finite_number(rule['nominal_length_mm'])
        low = finite_number(rule['min_width_mm'])
        high = finite_number(rule['max_width_mm'])
        if v8 or v7 or v6:
            assert 1 <= width <= 1e9 and abs(width-round(width)) <= 1e-6, 'V6 positive integer width range'
            assert abs(low-1) <= 1e-6 and abs(high-1e9) <= 1e-6, 'V6 numeric range declaration'
            for key, expected in [('min_length_mm',1),('max_length_mm',1e9)]:
                if key in rule:
                    assert abs(finite_number(rule[key])-expected) <= 1e-6, 'V6 numeric length range declaration'
        else:
            assert 500 <= width <= 1500 and abs(width-round(width)) <= 1e-6, 'V5 integer width range'
            assert abs(low-500) <= 1e-6 and abs(high-1500) <= 1e-6, 'V5 nominal range declaration'
        assert 1 <= length <= 1e9 and abs(length-round(length)) <= 1e-6, 'V5 positive integer length range'
        locked = rule['ratio_locked']
        assert type(locked) is bool, 'V5 boolean ratio_locked'
        assert rule['mode'] == ('ratio' if locked else 'free'), 'V5 mode/lock consistency'
        ratio = rule.get('ratio')
        if ratio is not None:
            ratio = finite_number(ratio)
            assert ratio > 0, 'V5 positive custom ratio'
        if locked:
            assert ratio is not None, 'V5 locked ratio required'
            assert abs(length-width*ratio) <= .51, 'V5 locked length rounding consistency'
        nominal = width/1000., length/1000.
        caps = tuple(sorted(nominal))
        for key, expected in zip(('max_width_m', 'max_length_m'), caps):
            assert abs(finite_number(data[key])-expected) <= 1e-6, 'V5 sorted cap consistency'
        for key, expected in zip(('nominal_width_m', 'nominal_length_m'), nominal):
            assert abs(finite_number(data[key])-expected) <= 1e-6, 'V5 directional nominal consistency'
        return caps
    v4 = str(data.get('panel_study_version', '')).lower().startswith('v4') or rule is not None
    if not v4:
        for key, cap in [('max_width_m', 1.5), ('max_length_m', 3.)]:
            if key in data:
                value = finite_number(data[key])
                assert 0 < value <= cap+EPS_M, 'legacy declared cap'
        return 1.5, 3.
    assert isinstance(rule, dict), 'V4 sizing_rule required'
    width = finite_number(rule['nominal_width_mm'])
    length = finite_number(rule['nominal_length_mm'])
    ratio = finite_number(rule['ratio'])
    low = finite_number(rule['min_width_mm'])
    high = finite_number(rule['max_width_mm'])
    assert 500.-1e-6 <= width <= 1500.+1e-6, 'nominal width range'
    assert abs(ratio-3.) <= 1e-9 and abs(length-width*3.) <= 1e-6, 'length/width ratio'
    assert abs(low-500.) <= 1e-6 and abs(high-1500.) <= 1e-6, 'nominal range declaration'
    caps = width/1000., length/1000.
    for key, expected in zip(('max_width_m', 'max_length_m'), caps):
        assert abs(finite_number(data[key])-expected) <= 1e-6, 'selected cap inconsistency'
    for key, expected in zip(('nominal_width_m', 'nominal_length_m'), caps):
        if key in data:
            assert abs(finite_number(data[key])-expected) <= 1e-6, 'nominal inconsistency'
    return caps


def geometry_limits(data):
    v8 = str(data.get('panel_study_version', '')).lower().startswith('v8')
    if not v8 and not str(data.get('panel_study_version', '')).lower().startswith('v7'):
        return False
    rule=data.get('geometry_rule')
    assert isinstance(rule, dict), 'V7 geometry_rule required'
    assert rule.get('panels')==('planar_rectangles' if v8 else 'planar'), 'geometry_rule panels mismatch'
    assert abs(finite_number(rule.get('planarity_tolerance_mm'))-STRICT_PLANAR_M*1000) <= 1e-12, 'V7 geometry_rule tolerance mismatch'
    assert rule.get('ridge_seams')=='aligned', 'V7 ridge seams must be declared aligned'
    if v8:
        assert rule.get('exterior_arc_trims') is True, 'V8 arc exception must be explicit'
        assert abs(finite_number(rule.get('neighbor_tolerance'))-.1) <= 1e-12, 'V8 neighbor tolerance must be 10%'
        assert rule.get('source_geometry')=='reconstructed_with_user_approval', 'V8 approved reconstruction declaration required'
    return True


def fixture_cases():
    def panel(width, length):
        return dict(id='TEST', width_m=width, length_m=length, area_m2=width*length,
                    vertices=[[0, 0, 0], [width, 0, 0], [width, length, 0], [0, length, 0]],
                    faces=[[0, 1, 2], [0, 2, 3]])

    def metadata(width, length, ratio=None, locked=False, version='v6-flexible'):
        caps = sorted((width/1000., length/1000.))
        return dict(panel_study_version=version, max_width_m=caps[0], max_length_m=caps[1],
                    nominal_width_m=width/1000., nominal_length_m=length/1000.,
                    sizing_rule=dict(mode='ratio' if locked else 'free', nominal_width_mm=width,
                    nominal_length_mm=length, ratio_locked=locked, ratio=ratio,
                    min_width_mm=500 if version.startswith('v5') else 1,
                    max_width_mm=1500 if version.startswith('v5') else 1e9))

    def v4metadata(width):
        return dict(panel_study_version='v4-adjustable', max_width_m=width/1000.,
                    max_length_m=width*3./1000., sizing_rule=dict(nominal_width_mm=width,
                    nominal_length_mm=width*3., ratio=3, min_width_mm=500, max_width_mm=1500))

    passed = []
    for width, length, ratio, locked in [(500,1500,None,False),(1000,6000,None,False),
            (873,2222,None,False),(1200,800,None,False),(1000,4200,4.2,True),
            (873,2576,2.951,True),(1000,400,.4,True),(1000,2222,8.7,False),
            (2500,6000,None,False),(250,1200,None,False),(6000,2000,None,False),
            (2500,7500,3,True),(300,1500,5,True),(1,1000,None,False),(1e9,1e9,None,False)]:
        caps = sizing_limits(metadata(width,length,ratio,locked))
        assert check(panel(*caps), *caps)['planar']
        passed.append('accept_V6_%dx%d_%s' % (width,length,'ratio' if locked else 'free'))
    for width,length,ratio,locked in [(500,1500,None,False),(1000,6000,None,False),(1200,800,None,False),(1000,4200,4.2,True)]:
        caps=sizing_limits(metadata(width,length,ratio,locked,version='v5-flexible'))
        assert check(panel(*caps),*caps)['planar']
        passed.append('accept_legacy_V5_%dx%d_mm' % (width,length))
    for width in (500,873,1000,1500):
        caps = sizing_limits(v4metadata(width))
        assert check(panel(*caps), *caps)['planar']
        passed.append('accept_legacy_V4_%dx%d_mm' % (width,width*3))
    assert sizing_limits({}) == (1.5,3.)
    assert check(panel(.2,1.2),.5,1.5)['below_nominal_min_width']
    passed.extend(['accept_legacy_V3_default_caps','accept_and_flag_clipped_200_mm_short_side'])
    invalids = [('reject_4500_mm_in_legacy', lambda: check(panel(1.5,4.5))),
                ('reject_selected_width_overflow', lambda: check(panel(.51,1.5),.5,1.5)),
                ('reject_selected_length_overflow', lambda: check(panel(.5,1.6),.5,1.5)),
                ('reject_V4_missing_rule', lambda: sizing_limits({'panel_study_version':'v4-adjustable'})),
                ('reject_V5_missing_rule', lambda: sizing_limits({'panel_study_version':'v5-flexible'})),
                ('reject_V6_missing_rule', lambda: sizing_limits({'panel_study_version':'v6-flexible'}))]
    for width in (0,-1,1000000001,1000.5,float('nan'),float('inf')):
        invalids.append(('reject_V6_nominal_width_%s' % width,lambda w=width:sizing_limits(metadata(w,2200))))
    for length in (0,-1,800.5,1000000001):
        invalids.append(('reject_V6_nominal_length_%s' % length,lambda l=length:sizing_limits(metadata(1000,l))))
    for label, key, value in [('missing_locked_ratio','ratio',None),('negative_ratio','ratio',-1),
            ('zero_ratio','ratio',0),('nonfinite_ratio','ratio',float('inf')),
            ('wrong_ratio','ratio',3),('nonboolean_lock','ratio_locked',1),
            ('mode_lock_conflict','mode','free'),('wrong_width_range','min_width_mm',500),('wrong_max_width_range','max_width_mm',1500),('wrong_min_length_range','min_length_mm',500),('wrong_max_length_range','max_length_mm',4500)]:
        bad = metadata(1000,4200,4.2,True)
        bad['sizing_rule'][key] = value
        invalids.append(('reject_V6_'+label,lambda d=bad:sizing_limits(d)))
    for width in (499,1501):
        invalids.append(('reject_legacy_V5_width_%s' % width,lambda w=width:sizing_limits(metadata(w,2200,version='v5-flexible'))))
    bad=metadata(1200,800)
    bad['max_width_m'],bad['max_length_m']=1.2,.8
    invalids.append(('reject_V6_unsorted_caps',lambda:sizing_limits(bad)))
    bad_nominal=metadata(1200,800)
    bad_nominal['nominal_width_m'],bad_nominal['nominal_length_m']=.8,1.2
    invalids.append(('reject_V6_swapped_directional_nominals',lambda:sizing_limits(bad_nominal)))
    bad_v4=v4metadata(1000)
    bad_v4['sizing_rule']['nominal_length_mm']=3001
    invalids.append(('reject_legacy_V4_wrong_ratio',lambda:sizing_limits(bad_v4)))
    for label, invoke in invalids:
        try:
            invoke()
        except (AssertionError, KeyError, ValueError):
            passed.append(label)
        else:
            raise AssertionError(label+' unexpectedly accepted')
    # V7 uses the same arbitrary positive dimensions, with actual coplanarity
    # checked independently of type/kind/planarity labels.
    geometry={'panels':'planar','planarity_tolerance_mm':.0001,'ridge_seams':'aligned'}
    for width,length,ratio,locked in [(1000,3000,None,False),(2500,6000,None,False),
            (400,6000,None,False),(5000,3000,None,False),(2500,6875,2.75,True),
            (1,1000,None,False)]:
        data=metadata(width,length,ratio,locked,version='v7-planar-aligned')
        data['geometry_rule']=dict(geometry)
        assert check(panel(*sizing_limits(data)),*sizing_limits(data),strict_planar=geometry_limits(data))['planar']
        passed.append('accept_V7_strict_%dx%d' % (width,length))
    near=panel(1.,1.)
    near['vertices'][2][2]=5e-8
    near['area_m2']=sum(polygon_area([near['vertices'][i] for i in f]) for f in near['faces'])
    assert check(near,1.,1.,strict_planar=True)['planar']
    passed.append('accept_V7_submicrometre_serialization_noise')
    bad_geometry_cases=[('missing_geometry_rule',{}),('nonplanar_mode',dict(geometry,panels='curved')),
        ('loose_tolerance',dict(geometry,planarity_tolerance_mm=.001)),
        ('unaligned_ridge_declaration',dict(geometry,ridge_seams='staggered'))]
    for label,rule in bad_geometry_cases:
        data=metadata(1000,3000,version='v7-planar-aligned')
        if rule:data['geometry_rule']=rule
        try:geometry_limits(data)
        except (AssertionError,KeyError,ValueError,TypeError):passed.append('reject_V7_'+label)
        else:raise AssertionError('V7 invalid geometry declaration accepted: '+label)
    folded=panel(1.,1.)
    folded['vertices'][2][2]=.01
    folded['nonplanarity_mm']=0
    folded['kind']='planar'
    folded['area_m2']=sum(polygon_area([folded['vertices'][i] for i in f]) for f in folded['faces'])
    reversed_face=panel(1.,1.);reversed_face['faces'][1]=[0,3,2]
    bend_flag=panel(1.,1.);bend_flag['needs_bend']=True
    for label,raw in [('folded_geometry_despite_planar_label',folded),('reversed_face',reversed_face),('fold_flag',bend_flag)]:
        try:check(raw,1.1,1.1,strict_planar=True)
        except (AssertionError,KeyError,ValueError):passed.append('reject_V7_'+label)
        else:raise AssertionError('V7 nonflat/invalid plate accepted: '+label)
    # Real V6 curved geometry remains valid in its legacy format; merely changing
    # its label to V7 cannot bypass strict plane verification.
    legacy_path=ROOT.parent/'roof-panel-studio-v6/1102e_V6自由尺寸分隔.json'
    if legacy_path.exists():
        legacy=json.loads(legacy_path.read_text());caps=sizing_limits(legacy)
        curved=next(p for p in legacy['panels'] if check(p,*caps)['first_plane_deviation_m']>1e-5)
        assert not check(curved,*caps)['planar']
        try:check(curved,*caps,strict_planar=True)
        except (AssertionError,KeyError,ValueError):passed.append('reject_real_V6_curved_plate_relabelled_V7')
        else:raise AssertionError('Real V6 folded geometry accepted in V7')
    geometry8 = dict(panels='planar_rectangles', planarity_tolerance_mm=.0001,
                     ridge_seams='aligned', exterior_arc_trims=True,
                     neighbor_tolerance=.1, source_geometry='reconstructed_with_user_approval')
    refs_data = dict(roofs=[dict(roof_id='A', exterior=[[0,0,0],[2,0,0],[2,1,0],
                     [1.8,1.6,0],[1,2,0],[0,2,0]], arc_edge_indices=[2,3])])
    refs = exterior_references(refs_data)

    def rectangular(width, length):
        return dict(panel(width, length), kind='planar', roof_id='A',
                    is_rectangle=True, layout_shape='planar_rectangle',
                    is_exterior_arc_trim=False, arc_edge_ids=[])

    def polygon_fixture(xy, **metadata_overrides):
        points = [[x,y,0.] for x,y in xy]
        raw = dict(id='TRIM', roof_id='A', vertices=points,
                   faces=[[0,j,j+1] for j in range(1,len(points)-1)],
                   width_m=2., length_m=2., area_m2=polygon_area(points),
                   kind='planar', is_rectangle=False, layout_shape='outer_arc_trim',
                   is_exterior_arc_trim=True, arc_edge_ids=[2,3])
        return dict(raw, **metadata_overrides)

    for width,length,ratio,locked in [(2500,6000,None,False),(400,6000,None,False),
            (5000,3000,None,False),(2500,6875,2.75,True),(1,1000,None,False)]:
        data=metadata(width,length,ratio,locked,version='v8-rectangular-rebuilt')
        data['geometry_rule']=dict(geometry8)
        caps=sizing_limits(data)
        assert check(rectangular(*caps),*caps,strict_planar=geometry_limits(data),rectangle_refs=refs)['is_rectangle']
        passed.append('accept_V8_actual_rectangle_%dx%d' % (width,length))
    trim=polygon_fixture([(1,1),(2,1),(1.8,1.6),(1,2)])
    assert check(trim,2,2,strict_planar=True,rectangle_refs=refs)['is_exterior_arc_trim']
    passed.append('accept_V8_verified_exterior_arc_stock_crop')
    subdivided=rectangular(1,1)
    subdivided['vertices']=[[0,0,0],[.5,0,0],[1,0,0],[1,1,0],[0,1,0]]
    subdivided['faces']=[[0,1,4],[1,3,4],[1,2,3]]
    assert check(subdivided,1,1,strict_planar=True,rectangle_refs=refs)['is_rectangle']
    passed.append('accept_V8_rectangle_with_collinear_mesh_subdivisions')
    tilted=rectangular(1,2)
    c,s=math.cos(.6),math.sin(.6)
    tilted['vertices']=[[x+99,y*c-7,y*s+30] for x,y,z in tilted['vertices']]
    assert check(tilted,1,2,strict_planar=True,rectangle_refs=refs)['is_rectangle']
    passed.append('accept_V8_world_transformed_tilted_rectangle')
    trapezoid=rectangular(1,1)
    trapezoid['vertices'][2][0]=.8
    trapezoid['area_m2']=.9
    assert check(trapezoid,1,1,strict_planar=True)['planar']
    passed.append('accept_legacy_V7_actual_planar_trapezoid')
    parallelogram=rectangular(1,1)
    parallelogram['vertices'][2][0]=1.2
    parallelogram['vertices'][3][0]=.2
    parallelogram['width_m']=1.2
    warped=rectangular(1,1)
    warped['vertices'][2][2]=.001
    warped.update(nonplanarity_mm=0,needs_bend=False)
    warped['area_m2']=sum(polygon_area([warped['vertices'][i] for i in f]) for f in warped['faces'])
    fake_trim=polygon_fixture([(0,0),(1,0),(.8,1),(0,1)])
    illegal_diagonal=polygon_fixture([(1,1),(2,1),(1.8,1.6)])
    unknown_arc=copy.deepcopy(trim); unknown_arc['arc_edge_ids']=[1]
    no_arc_id=copy.deepcopy(trim); no_arc_id['arc_edge_ids']=[]
    wrong_roof=copy.deepcopy(trim); wrong_roof['roof_id']='missing'
    false_rectangle=copy.deepcopy(trim); false_rectangle.update(is_rectangle=True,layout_shape='planar_rectangle',is_exterior_arc_trim=False)
    wrong_elevation=copy.deepcopy(trim)
    wrong_elevation['vertices']=[[x,y,z+1] for x,y,z in wrong_elevation['vertices']]
    duplicate_faces=rectangular(1,1); duplicate_faces['faces']*=2; duplicate_faces['area_m2']=2
    missing_label=rectangular(1,1); missing_label.pop('is_rectangle')
    false_trim_rectangle=rectangular(1,1); false_trim_rectangle.update(is_exterior_arc_trim=True,arc_edge_ids=[2])
    v8_bad_panels=[('trapezoid_despite_rectangle_label',trapezoid),('parallelogram_four_corners_not_right_angles',parallelogram),
                   ('warped_despite_zero_nonplanarity_metadata',warped),('fake_interior_arc_trim',fake_trim),
                   ('arc_contact_with_illegal_interior_diagonal',illegal_diagonal),('unapproved_arc_edge_id',unknown_arc),
                   ('empty_arc_edge_ids',no_arc_id),('unknown_arc_roof',wrong_roof),('arc_trim_falsely_marked_rectangle',false_rectangle),
                   ('arc_crop_wrong_3d_elevation',wrong_elevation),('duplicate_mesh_faces',duplicate_faces),
                   ('missing_rectangle_declaration',missing_label),('rectangle_claims_arc_exemption',false_trim_rectangle)]
    for label,raw in v8_bad_panels:
        try:check(raw,3,3,strict_planar=True,rectangle_refs=refs)
        except (AssertionError,KeyError,ValueError,TypeError):passed.append('reject_V8_'+label)
        else:raise AssertionError('V8 invalid shape unexpectedly accepted: '+label)
    for label,key,value in [('wrong_panel_rule','panels','planar'),('loose_plane_tolerance','planarity_tolerance_mm',.001),
            ('unaligned_ridge','ridge_seams','staggered'),('arc_exception_not_explicit','exterior_arc_trims',False),
            ('neighbor_tolerance_loosened','neighbor_tolerance',.2),('unapproved_source_geometry','source_geometry','original')]:
        data=metadata(2500,6000,version='v8-rectangular-rebuilt')
        data['geometry_rule']=dict(geometry8,**{key:value})
        try:geometry_limits(data)
        except (AssertionError,KeyError,ValueError,TypeError):passed.append('reject_V8_'+label)
        else:raise AssertionError('V8 invalid rule unexpectedly accepted: '+label)
    for label,data in [('missing_world_roof_reference',{}),('arc_id_outside_reference',dict(roofs=[dict(refs_data['roofs'][0],arc_edge_indices=[99])]))]:
        try:exterior_references(data)
        except (AssertionError,KeyError,ValueError,TypeError):passed.append('reject_V8_'+label)
        else:raise AssertionError('V8 invalid exterior reference accepted: '+label)
    return passed


def validate_panels(panels, caps, strict_planar=False, rectangle_refs=None):
    failures, counts = [], Counter()
    max_area_error = total_area = max_planar_height = 0.
    nearplanar_examples = []
    for raw in panels:
        try:
            result = check(raw, *caps, strict_planar=strict_planar, rectangle_refs=rectangle_refs)
            counts['checked_panels'] += 1
            if result.get('is_rectangle'):
                counts['actual_rectangles'] += 1
            if result.get('is_exterior_arc_trim'):
                counts['verified_exterior_arc_trims'] += 1
            total_area += result['area']
            max_area_error = max(max_area_error, result['area_error_m2'])
            if result['below_nominal_min_width']:
                counts['below_nominal_min_width'] += 1
            if result['planar']:
                counts['bridge_planar_panels'] += 1
                counts['planar_fitted_by_'+result['fitted_by']] += 1
                max_planar_height = max(max_planar_height, result['first_plane_deviation_m'])
                if result['engine_curved']:
                    counts['engine_curved_but_bridge_planar'] += 1
                    if len(nearplanar_examples) < 12:
                        nearplanar_examples.append(dict(id=raw['id'], engine_svd_nonplanarity_mm=raw['nonplanarity_mm'],
                            bridge_first_face_deviation_mm=result['first_plane_deviation_m']*1000))
            else:
                counts['bridge_curved_panels'] += 1
        except (AssertionError, ValueError, KeyError) as exc:
            failures.append(dict(id=raw.get('id'), error=str(exc), nonplanarity_mm=raw.get('nonplanarity_mm')))
    return dict(all_passed=not failures, selected_max_width_m=caps[0], selected_max_length_m=caps[1],
                expected_panel_count=len(panels), counts=dict(counts), total_newell_area_m2=total_area,
                max_panel_area_error_m2=max_area_error, max_bridge_planar_first_face_deviation_mm=max_planar_height*1000,
                nearplanar_examples=nearplanar_examples, failed_panels=len(failures), failures=failures)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--export',type=Path,default=EXPORT)
    parser.add_argument('--snapshot',type=Path,action='append',default=[])
    parser.add_argument('--fixtures-only',action='store_true')
    parser.add_argument('--templates-only',action='store_true')
    args = parser.parse_args()
    fixtures = fixture_cases()
    report = dict(format='roof-bridge-numeric-validation-4', all_passed=True,
                  method='Python numerical mirror of V8 Ruby canonical_panel, geometry_limits, rectangle/arc preflight and sizing_limits; no Ruby or SketchUp runtime execution',
                  bridge_sha256=hashlib.sha256(BRIDGE.read_bytes()).hexdigest(),
                  worker_sha256=hashlib.sha256((ROOT/'panel-worker.js').read_bytes()).hexdigest(),
                  fixture_cases_passed=fixtures, supplemental_template_checks=[])
    if not args.fixtures_only and not args.templates_only:
        data = json.loads(args.export.read_text())
        assert data['format']=='roof-panels-1' and data['unit']=='m'
        assert isinstance(data['panels'],list) and 0 < len(data['panels']) <= 500000
        assert len(set(p['id'] for p in data['panels']))==len(data['panels']),'duplicate ID'
        rectangle_refs=exterior_references(data) if data.get('panel_study_version','').lower().startswith('v8') else None
        report.update(validate_panels(data['panels'],sizing_limits(data),strict_planar=geometry_limits(data),rectangle_refs=rectangle_refs))
        report['geometry_rule']=data.get('geometry_rule')
        report.update(export_sha256=hashlib.sha256(args.export.read_bytes()).hexdigest(),
                      export_file=args.export.name,sizing_rule=data['sizing_rule'])
    paths = [] if args.fixtures_only else (args.snapshot or sorted(Path('/tmp').glob('v8-validation-*.json')))
    for path in paths:
        template=json.loads(path.read_text())
        candidate=template['candidates'][0]
        caps=sizing_limits(template)
        rectangle_refs=exterior_references(candidate) if template.get('panel_study_version','').lower().startswith('v8') else None
        result=validate_panels(candidate['panels'],caps,strict_planar=geometry_limits(template),rectangle_refs=rectangle_refs)
        result.update(nominal_width_mm=template['sizing_rule']['nominal_width_mm'],
                      nominal_length_mm=template['sizing_rule']['nominal_length_mm'],
                      input_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),input_file=path.name,
                      scope='All local full-roof template panels before four instance world transforms')
        report['supplemental_template_checks'].append(result)
        report['all_passed']=report['all_passed'] and result['all_passed']
    try:
        sys.path.insert(0,'/tmp/roof-ruby-parser')
        import tree_sitter
        import tree_sitter_ruby
        parser=tree_sitter.Parser(tree_sitter.Language(tree_sitter_ruby.language()))
        tree=parser.parse(BRIDGE.read_bytes())
        problems=[]
        stack=[tree.root_node]
        while stack:
            node=stack.pop()
            if node.type=='ERROR' or node.is_missing:
                problems.append(dict(type=node.type,line=node.start_point.row+1,column=node.start_point.column+1))
            stack.extend(node.children)
        syntax=dict(all_passed=not problems,method='tree-sitter Ruby syntax parser; Ruby and SketchUp not executed',
                    bridge_sha256=report['bridge_sha256'],errors=problems)
    except ImportError:
        syntax=dict(all_passed=False,method='Ruby syntax parser unavailable; no runtime execution')
    (ROOT/'bridge_syntax_validation.json').write_text(json.dumps(syntax,ensure_ascii=False,indent=2)+'\n')
    report['syntax_validation']=syntax
    report['all_passed']=report['all_passed'] and syntax['all_passed']
    (ROOT/'bridge_numeric_validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k not in ('failures','nearplanar_examples','supplemental_template_checks')},ensure_ascii=False))
    for result in report['supplemental_template_checks']:
        print(json.dumps({k:v for k,v in result.items() if k not in ('failures','nearplanar_examples')},ensure_ascii=False))
    if not report['all_passed']:
        print(json.dumps(report.get('failures',[])[:20],ensure_ascii=False,indent=2))
        raise SystemExit(1)


if __name__=='__main__':
    main()
