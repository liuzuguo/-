#!/usr/bin/env node
/** Run the real browser geometry worker in a Node VM for independent validation.
 *
 * Example:
 * node worker_generate.mjs --width 873 --length 2222 --output /tmp/v8-873x2222.json
 * node worker_generate.mjs --width 1000 --ratio 4.2 --output /tmp/v8-ratio42.json
 */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import crypto from 'node:crypto';
import { performance } from 'node:perf_hooks';
import { fileURLToPath } from 'node:url';

const root = path.dirname(fileURLToPath(import.meta.url));
const args = process.argv.slice(2);
const options = {};
for (let i = 0; i < args.length; i++) {
  if (!args[i].startsWith('--') || i + 1 >= args.length) {
    throw new Error(`Expected --name value, received ${args[i]}`);
  }
  options[args[i].slice(2)] = args[++i];
}
const widthMm = Number(options.width ?? 1000);
if (!Number.isInteger(widthMm) || widthMm < 1 || widthMm > 1e9) {
  throw new Error('Width must be a positive integer millimetre within the numerical range');
}
const ratioLocked = options.ratio !== undefined;
const ratio = ratioLocked ? Number(options.ratio) : null;
if (ratioLocked && (!Number.isFinite(ratio) || ratio <= 0)) {
  throw new Error('Ratio must be a finite positive length/width ratio');
}
const lengthMm = Number(options.length ?? (ratioLocked ? Math.round(widthMm * ratio) : 3000));
if (!Number.isInteger(lengthMm) || lengthMm < 1 || lengthMm > 1e9) {
  throw new Error('Length must be an integer from 1 to 1000000000 mm');
}
if (ratioLocked && Math.abs(lengthMm - widthMm * ratio) > 0.51) {
  throw new Error('Locked ratio must match the selected length after integer-mm rounding');
}
const sizingRule = {
  mode: ratioLocked ? 'ratio' : 'free',
  nominal_width_mm: widthMm,
  nominal_length_mm: lengthMm,
  ratio_locked: ratioLocked,
  ratio,
  min_width_mm: 1,
  max_width_mm: 1e9,
  min_length_mm: 1,
  max_length_mm: 1e9,
};
function fallbackFile(name) {
  const local = path.join(root, name);
  return fs.existsSync(local) ? local : path.join(root, '..', 'roof-panel-studio-v3', name);
}
const sourcePath = options.source ?? fallbackFile('modelData.json');
const uvPath = options.uv ?? fallbackFile('source_uv_complete.json');
const workerPath = options.worker ?? path.join(root, 'panel-worker.js');
const outputPath = options.output ?? path.join(root, 'validation_reports', `${widthMm}x${lengthMm}.json`);
const source = JSON.parse(fs.readFileSync(sourcePath, 'utf8'));
const sourceUv = JSON.parse(fs.readFileSync(uvPath, 'utf8'));
const reconstruction=JSON.parse(fs.readFileSync(path.join(root,'reconstructionData.json'),'utf8'));
const uv = Array.isArray(sourceUv) ? sourceUv : sourceUv.uv;
const workerCode = fs.readFileSync(workerPath, 'utf8');
const workerSha256 = crypto.createHash('sha256').update(workerCode).digest('hex');
const started = performance.now();
const requestId = `validation-${widthMm}x${lengthMm}`;

let resolveResult;
let rejectResult;
const resultPromise = new Promise((resolve, reject) => {
  resolveResult = resolve;
  rejectResult = reject;
});
let lastProgress = '';
const sandbox = {
  console,
  performance,
  setTimeout,
  clearTimeout,
  setInterval,
  clearInterval,
  structuredClone,
  TextEncoder,
  TextDecoder,
  postMessage(message) {
    if (message.type === 'result') {
      if (message.requestId !== requestId) {
        rejectResult(new Error(`Wrong worker requestId: ${message.requestId}`));
      } else {
        resolveResult(message.candidate);
      }
    } else if (message.type === 'error') {
      rejectResult(new Error(message.error ?? message.message ?? JSON.stringify(message)));
    } else if (message.type === 'progress') {
      // Keep the generation log concise, without changing the real worker.
      const progress = message.phase ?? message.stage ?? message.message ?? '';
      if (progress !== lastProgress) {
        process.stderr.write(`${JSON.stringify(message)}\n`);
        lastProgress = progress;
      }
    }
  },
};
sandbox.self = sandbox;
const context = vm.createContext(sandbox);
vm.runInContext(workerCode, context, { filename: workerPath });
if (typeof context.onmessage !== 'function') {
  throw new Error('The worker did not install an onmessage handler');
}
const input = {
  type: 'generate', requestId, widthMm, lengthMm, ratioLocked, ratio,
  model:{reconstruction},
};
try {
  await context.onmessage({ data: input });
} catch (error) {
  rejectResult(error);
}
const candidate = await resultPromise;
if (!candidate || !Array.isArray(candidate.panels) || !candidate.panels.length) {
  throw new Error('The worker returned no panel geometry');
}
const generationSeconds = (performance.now() - started) / 1000;
const data = {
  format: 'roof-panel-dynamic-study-8',
  panel_study_version: 'v8-rectangular-rebuilt',
  unit: 'm',
  max_width_m: Math.min(widthMm, lengthMm) / 1000,
  max_length_m: Math.max(widthMm, lengthMm) / 1000,
  nominal_width_m: widthMm / 1000,
  nominal_length_m: lengthMm / 1000,
  sizing_rule: sizingRule,
  geometry_rule:{panels:'planar_rectangles',planarity_tolerance_mm:.0001,ridge_seams:'aligned',exterior_arc_trims:true,neighbor_tolerance:.1,source_geometry:'reconstructed_with_user_approval'},
  crease_angle_deg: 10,
  layout:{type:'rebuilt-parallel-folds-rectangular',source_uv:uv,reconstruction,user_approved_reconstruction:true},
  instances:candidate.instances,
  original_instances:source.instances,
  center: source.center,
  targetZ: source.targetZ,
  recommended_id: candidate.id,
  candidates: [candidate],
  validation_generation: {
    selected_width_mm: widthMm,
    selected_length_mm: lengthMm,
    ratio_locked: ratioLocked,
    ratio,
    worker_sha256: workerSha256,
    generation_seconds: generationSeconds,
    generated_at: new Date().toISOString(),
    implementation: 'Real browser worker executed unchanged in a Node VM',
  },
};
fs.mkdirSync(path.dirname(outputPath), { recursive: true });
fs.writeFileSync(outputPath, JSON.stringify(data));
process.stdout.write(`${JSON.stringify({
  width_mm: widthMm,
  length_mm: lengthMm,
  ratio_locked: ratioLocked,
  ratio,
  template_panels: candidate.panels.length,
  template_types: candidate.types?.length,
  full_panels: candidate.summary?.panel_count,
  surface_area_m2: candidate.summary?.surface_area_m2,
  generation_seconds: generationSeconds,
  worker_sha256: workerSha256,
  bytes: fs.statSync(outputPath).size,
  output: outputPath,
})}\n`);
