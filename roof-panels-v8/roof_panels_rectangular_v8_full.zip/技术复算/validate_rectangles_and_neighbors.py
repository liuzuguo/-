#!/usr/bin/env python3
"""Independent checks of actual rectangular roof plates and their neighbours.

No panel label, UV chart, nominal dimensions, or stock bounding box is accepted
as proof that the installed plate is a rectangle. The boundary is recovered
from the actual mesh. Nonrectangular pieces require an independently supplied
full-roof outline and may be accepted only as rectangle/exterior-arc crops.

Input: {"panels":[{"id", "roof_id", "vertices", "faces"}]} (world metres),
or the existing roof-panel study format with candidates and eight instances.
Reference: {"roofs":[{"roof_id":"A", "exterior":[[x,y,z],...],
                         "arc_edge_indices":[0,1,...]}]}.
--source modelData.json derives full-roof exteriors from the original source
triangles and instance transforms instead of trusting a supplied trim label.

Neighbour dimensions are SORTED actual rectangle side lengths, not nominal
stock sizes. The default ratio 1.10 applies to neighbours that are both full
rectangles. Ratios involving exterior crops are reported separately.
"""
from __future__ import annotations

import argparse
from collections import defaultdict
import json
import math
from pathlib import Path
import sys

import numpy as np

for vendor in (Path('/workspace/roof-panel-studio/vendor'),):
    if vendor.exists():
        sys.path.insert(0, str(vendor))
from shapely.geometry import Polygon, LineString, MultiLineString, Point, box
from shapely.ops import unary_union
from shapely.strtree import STRtree
try:
    from shapely import set_precision
except ImportError:
    set_precision = None


def fail_unless(test, message):
    if not test:
        raise ValueError(message)


def simplify_ring(points, tolerance):
    """Remove duplicate/collinear subdivision points, retaining true corners."""
    p = [np.asarray(q, dtype=float) for q in points]
    if len(p) > 1 and np.linalg.norm(p[0]-p[-1]) <= tolerance:
        p.pop()
    changed = True
    while changed and len(p) > 2:
        changed = False
        for i in range(len(p)):
            a, b, c = p[i-1], p[i], p[(i+1) % len(p)]
            u, v = b-a, c-b
            lu, lv = np.linalg.norm(u), np.linalg.norm(v)
            if lu <= tolerance or lv <= tolerance:
                p.pop(i); changed = True; break
            if np.dot(u, v) >= 0 and abs(float(u[0]*v[1]-u[1]*v[0])) <= tolerance*(lu+lv):
                p.pop(i); changed = True; break
    return np.asarray(p)


def actual_panel(raw, tolerance=1e-7, angle_tolerance=1e-6):
    vertices = np.asarray(raw.get('vertices'), dtype=float)
    fail_unless(vertices.ndim == 2 and vertices.shape[1] == 3 and len(vertices) >= 3
                and np.isfinite(vertices).all(), 'invalid actual XYZ vertices')
    faces = raw.get('faces') or [list(range(len(vertices)))]
    fail_unless(isinstance(faces, list) and faces, 'missing mesh faces')
    largest = None
    normals = []
    for face in faces:
        fail_unless(len(face) >= 3 and all(type(k) is int and 0 <= k < len(vertices) for k in face),
                    'invalid mesh face indices')
        a = vertices[face[0]]
        for i in range(1, len(face)-1):
            normal = np.cross(vertices[face[i]]-a, vertices[face[i+1]]-a)
            magnitude = float(np.linalg.norm(normal))
            if magnitude > 1e-15:
                normals.append((normal/magnitude, magnitude))
                if largest is None or magnitude > largest[0]:
                    largest = (magnitude, a, normal/magnitude)
    fail_unless(largest is not None, 'mesh has no nondegenerate face')
    _, origin, normal = largest
    plane_error = float(np.max(np.abs((vertices-origin) @ normal)))
    fail_unless(plane_error <= tolerance, f'actual vertices are not planar: {plane_error:g} m')
    # A rectangular face remains flat regardless of source normal labels.
    fail_unless(all(float(n @ normal) > 0 for n, size in normals if size > 1e-13),
                'mesh has reversed or folded face winding')
    axis = np.eye(3)[int(np.argmin(np.abs(normal)))]
    u = np.cross(axis, normal); u /= np.linalg.norm(u)
    v = np.cross(normal, u)
    projected = np.column_stack(((vertices-origin) @ u, (vertices-origin) @ v))
    pieces = []
    for face in faces:
        polygon = Polygon(projected[face])
        fail_unless(polygon.is_valid and polygon.area > 1e-15, 'invalid or zero-area actual face')
        pieces.append(polygon)
    mesh = unary_union(pieces)
    fail_unless(mesh.geom_type == 'Polygon' and mesh.is_valid, 'mesh is disconnected or invalid')
    fail_unless(not mesh.interiors, 'plate has an internal hole')
    area_tolerance = max(1e-12, mesh.area*1e-10)
    fail_unless(abs(sum(p.area for p in pieces)-mesh.area) <= area_tolerance,
                'actual plate faces overlap')
    corners = simplify_ring(list(mesh.exterior.coords), tolerance)
    rectangle = False
    right_error = None
    width = length = None
    if len(corners) == 4:
        edges = np.roll(corners, -1, axis=0)-corners
        lengths = np.linalg.norm(edges, axis=1)
        if float(lengths.min()) > tolerance:
            unit = edges/lengths[:, None]
            right_error = float(np.max(np.abs(np.sum(unit*np.roll(unit, -1, axis=0), axis=1))))
            opposite = max(abs(float(unit[0,0]*unit[2,1]-unit[0,1]*unit[2,0])),
                           abs(float(unit[1,0]*unit[3,1]-unit[1,1]*unit[3,0])))
            equal = max(abs(float(lengths[0]-lengths[2])), abs(float(lengths[1]-lengths[3])))
            rectangle = (right_error <= angle_tolerance and opposite <= angle_tolerance
                         and equal <= max(tolerance*4, float(lengths.max())*angle_tolerance))
            if rectangle:
                width, length = sorted(((lengths[0]+lengths[2])*.5,
                                        (lengths[1]+lengths[3])*.5))
    ring_xyz = origin+corners[:, :1]*u+corners[:, 1:]*v
    return {'id':str(raw.get('id', '?')), 'roof_id':str(raw.get('roof_id', 'A')),
            'vertices':vertices, 'origin':origin, 'normal':normal, 'u':u, 'v':v,
            'polygon':mesh, 'corners':corners, 'ring_xyz':ring_xyz,
            'is_rectangle':bool(rectangle), 'width_m':None if width is None else float(width),
            'length_m':None if length is None else float(length), 'plane_error_m':plane_error,
            'right_angle_cos_error':right_error, 'arc_trim':False}


def source_roof_name(instance, index):
    return str(instance.get('roof_id') or ('ABCD'[index//2] if index < 8 else index//2))


def expand_panels(data):
    if isinstance(data.get('panels'), list):
        return data['panels']
    candidates = data.get('candidates')
    fail_unless(isinstance(candidates, list) and candidates, 'input contains no panels')
    candidate = next((c for c in candidates if c.get('id') == data.get('recommended_id')), candidates[0])
    local = candidate['panels']
    instances = data.get('instances')
    if not instances:
        return local
    output = []
    for k, instance in enumerate(instances):
        matrix = np.asarray(instance['matrix'], dtype=float).reshape(4, 4).T
        mirrored = np.linalg.det(matrix[:3, :3]) < 0
        for panel in local:
            points = np.asarray(panel['vertices']) @ matrix[:3, :3].T+matrix[:3, 3]
            item = dict(panel, id=f'{k}:{panel["id"]}', roof_id=source_roof_name(instance, k),
                        vertices=points.tolist())
            if mirrored:
                item['faces'] = [list(reversed(f)) for f in panel['faces']]
            output.append(item)
    return output


def detect_original_arc_edges(exterior):
    """Conservative rounded-corner detection; straight sides are not exceptions."""
    points = np.asarray(exterior, dtype=float)[:, :2]
    if np.linalg.norm(points[0]-points[-1]) < 1e-9:
        points = points[:-1]
    edges = np.roll(points, -1, axis=0)-points
    lengths = np.linalg.norm(edges, axis=1)
    unit = edges/np.maximum(lengths[:, None], 1e-30)
    turns = np.arctan2(np.roll(unit, 1, axis=0)[:,0]*unit[:,1]-np.roll(unit, 1, axis=0)[:,1]*unit[:,0],
                       np.sum(np.roll(unit, 1, axis=0)*unit, axis=1))
    turns_degrees = np.degrees(turns)
    curved = (np.abs(turns_degrees) >= .2) & (np.abs(turns_degrees) < 45)
    seeds = [i for i in range(len(points)) if curved[i] and curved[(i+1) % len(points)]
             and turns[i]*turns[(i+1) % len(points)] > 0]
    if not seeds:
        return []
    median = float(np.median(lengths[seeds]))
    return [i for i in seeds if lengths[i] <= max(.01, median*3)]


def reference_from_source(source, snap_m=1e-5, roof_ids=None):
    """Derive the complete outer roof; source facet/half-roof edges disappear."""
    geometry = source['variants']['0']
    points = np.asarray(geometry['vertices'], dtype=float)
    faces = np.asarray(geometry['faces'], dtype=int)
    roofs = defaultdict(list)
    for k, instance in enumerate(source['instances']):
        if roof_ids is not None and source_roof_name(instance, k) not in roof_ids:
            continue
        matrix = np.asarray(instance['matrix'], dtype=float).reshape(4, 4).T
        xyz = points @ matrix[:3, :3].T+matrix[:3, 3]
        for face in faces:
            p = Polygon(xyz[face, :2])
            roofs[source_roof_name(instance, k)].append(set_precision(p, snap_m) if set_precision else p)
    result = []
    for roof, pieces in roofs.items():
        domain = unary_union(pieces)
        if domain.geom_type != 'Polygon' or domain.interiors:
            domain = domain.buffer(snap_m*2).buffer(-snap_m*2)
        fail_unless(domain.geom_type == 'Polygon' and not domain.interiors,
                    f'cannot derive connected full exterior for roof {roof}')
        domain = domain.simplify(snap_m*2, preserve_topology=True)
        exterior = [[float(x), float(y), 0.] for x, y in list(domain.exterior.coords)[:-1]]
        result.append({'roof_id':roof, 'exterior':exterior,
                       'arc_edge_indices':detect_original_arc_edges(exterior)})
    return {'roofs':result, 'provenance':'derived from original full-roof triangle union and instances',
            'xy_precision_snap_m':snap_m}


def prepare_reference(reference):
    output = {}
    if reference is None:
        return output
    roofs = reference.get('roofs', [])
    if isinstance(roofs, dict):
        roofs = [dict(value, roof_id=key) for key, value in roofs.items()]
    for raw in roofs:
        points = np.asarray(raw['exterior'], dtype=float)
        fail_unless(points.ndim == 2 and points.shape[1] in (2, 3) and len(points) >= 3,
                    'invalid full-roof exterior reference')
        if np.linalg.norm(points[0, :2]-points[-1, :2]) <= 1e-10:
            points = points[:-1]
        domain = Polygon(points[:, :2])
        fail_unless(domain.is_valid and domain.area > 0, 'invalid reference exterior polygon')
        indices = raw.get('arc_edge_indices')
        if indices is None:
            indices = detect_original_arc_edges(points)
        fail_unless(all(type(i) is int and 0 <= i < len(points) for i in indices),
                    'arc reference index is not an exterior edge')
        arcs = MultiLineString([(points[i, :2], points[(i+1) % len(points), :2]) for i in indices])
        output[str(raw.get('roof_id', 'A'))] = {'domain':domain, 'arcs':arcs,
                'exterior':points[:, :2], 'arc_edge_count':len(indices)}
    return output


def verify_exterior_arc_crop(panel, reference, tolerance, angle_tolerance, reference_tolerance):
    """A crop must be rectangle ∩ complete roof, with only arc edges oblique."""
    normal, origin = panel['normal'], panel['origin']
    fail_unless(abs(float(normal[2])) > 1e-6,
                'vertical/non-graph edge plate needs a separate surface reference')
    xyz = panel['ring_xyz']; edges = np.roll(xyz, -1, axis=0)-xyz
    arcs = reference['arcs']
    fail_unless(not arcs.is_empty, 'full-roof reference contains no verified exterior arcs')
    on_arc = []
    for i in range(len(xyz)):
        line = LineString([xyz[i, :2], xyz[(i+1) % len(xyz), :2]])
        on_arc.append(line.difference(arcs.buffer(reference_tolerance)).length <= tolerance)
    fail_unless(any(on_arc), 'nonrectangle does not meet a true full-roof exterior arc')
    straight = [(i, np.linalg.norm(edge)) for i, edge in enumerate(edges) if not on_arc[i]]
    fail_unless(straight, 'edge crop has no verifiable rectangular stock side')
    i = max(straight, key=lambda item:item[1])[0]
    u = edges[i]/np.linalg.norm(edges[i]); v = np.cross(normal, u)
    for j, length in straight:
        direction = edges[j]/length
        fail_unless(min(abs(float(direction @ u)), abs(float(direction @ v))) <= angle_tolerance,
                    'non-arc boundary is oblique: an interior triangular/trapezoidal cut is hidden')
    local = np.column_stack(((xyz-origin) @ u, (xyz-origin) @ v))
    actual = Polygon(local)
    stock = box(float(local[:, 0].min()), float(local[:, 1].min()),
                float(local[:, 0].max()), float(local[:, 1].max()))
    # Lift the independently supplied full XY exterior to this plate's plane.
    xy = reference['exterior']
    z = origin[2]-(normal[0]*(xy[:, 0]-origin[0])+normal[1]*(xy[:, 1]-origin[1]))/normal[2]
    lifted = np.column_stack((xy, z))
    domain = Polygon(np.column_stack(((lifted-origin) @ u, (lifted-origin) @ v)))
    expected = stock.intersection(domain)
    residual = float(actual.symmetric_difference(expected).area)
    # Reference tolerance only tolerates the narrow ORIGINAL perimeter strip.
    fail_unless(residual <= max(1e-11, expected.length*reference_tolerance*1.01),
                'edge shape is not a rectangular stock crop against the full-roof exterior')
    fail_unless(expected.buffer(-reference_tolerance).difference(actual).area <= max(1e-11, tolerance*stock.length),
                'edge crop hides a hole or cut inside the expected rectangle/exterior intersection')
    panel['arc_trim'] = True
    panel['stock_bbox_sides_m'] = sorted([float(np.ptp(local[:, 0])), float(np.ptp(local[:, 1]))])
    panel['arc_crop_residual_area_m2'] = residual


def actual_neighbours(panels, tolerance, angle_tolerance):
    """Find shared 3-D edge intervals, including T joints and folded neighbours."""
    edges = []
    for pi, panel in enumerate(panels):
        xyz = panel['ring_xyz']
        for i in range(len(xyz)):
            a, b = xyz[i], xyz[(i+1) % len(xyz)]
            length = float(np.linalg.norm(b-a))
            if length > tolerance:
                edges.append((pi, a, b, (b-a)/length, length))
    envelopes = [LineString([e[1][:2], e[2][:2]]).buffer(tolerance).envelope for e in edges]
    tree = STRtree(envelopes)
    identities = {id(g):i for i, g in enumerate(envelopes)}
    pairs = defaultdict(float)
    for ei, edge in enumerate(edges):
        pi, a, b, direction, length = edge
        for hit in tree.query(envelopes[ei]):
            ej = int(hit) if isinstance(hit, (int, np.integer)) else identities[id(hit)]
            if ej <= ei:
                continue
            pj, c, d, other_direction, other_length = edges[ej]
            if pi == pj or panels[pi]['roof_id'] != panels[pj]['roof_id']:
                continue
            angular_error = float(np.linalg.norm(np.cross(direction, other_direction)))
            if angular_error > max(angle_tolerance, tolerance*2/min(length, other_length)):
                continue
            if max(float(np.linalg.norm(np.cross(c-a, direction))),
                   float(np.linalg.norm(np.cross(d-a, direction)))) > tolerance:
                continue
            t0, t1 = sorted([float((c-a) @ direction), float((d-a) @ direction)])
            overlap = min(length, t1)-max(0., t0)
            if overlap > tolerance*10:
                pairs[(min(pi, pj), max(pi, pj))] += overlap
    return pairs


def validate(data, reference=None, tolerance=1e-7, angle_tolerance=1e-6,
             adjacent_ratio=1.10, reference_tolerance=1e-5):
    fail_unless(adjacent_ratio >= 1 and math.isfinite(adjacent_ratio), 'invalid neighbour ratio')
    references = prepare_reference(reference)
    raw_panels = expand_panels(data)
    panels = []; failures = []; unverified = []
    for raw in raw_panels:
        try:
            p = actual_panel(raw, tolerance, angle_tolerance)
            if not p['is_rectangle']:
                ref = references.get(p['roof_id'])
                if ref is None:
                    unverified.append({'id':p['id'], 'check':'nonrectangular exception has no independent full-roof exterior'})
                else:
                    verify_exterior_arc_crop(p, ref, tolerance, angle_tolerance, reference_tolerance)
            panels.append(p)
        except (ValueError, KeyError, IndexError, TypeError) as error:
            failures.append({'id':str(raw.get('id', '?')), 'error':str(error)})
    pairs = actual_neighbours(panels, tolerance, angle_tolerance)
    full_ratios = []; trimmed_pairs = 0; unequal = []
    for (i, j), shared in pairs.items():
        a, b = panels[i], panels[j]
        if not (a['is_rectangle'] and b['is_rectangle']):
            trimmed_pairs += 1; continue
        ratio = max(a['width_m']/b['width_m'], b['width_m']/a['width_m'],
                    a['length_m']/b['length_m'], b['length_m']/a['length_m'])
        full_ratios.append(float(ratio))
        if ratio > adjacent_ratio+angle_tolerance:
            unequal.append({'a':a['id'], 'b':b['id'], 'ratio':float(ratio), 'shared_edge_m':shared,
                            'a_actual_sides_m':[a['width_m'], a['length_m']],
                            'b_actual_sides_m':[b['width_m'], b['length_m']]})
    coverage = []
    for roof in sorted(set(p['roof_id'] for p in panels)):
        ref = references.get(roof)
        if ref is None:
            unverified.append({'roof_id':roof, 'check':'complete coverage requires independent full-roof exterior'})
            continue
        group = [p for p in panels if p['roof_id'] == roof]
        if any(abs(float(p['normal'][2])) < 1e-6 for p in group):
            unverified.append({'roof_id':roof, 'check':'vertical plates require non-XY surface coverage proof'})
            continue
        shapes = [Polygon(p['ring_xyz'][:, :2]) for p in group]
        union = unary_union(shapes)
        domain = ref['domain']
        area_tolerance = max(1e-9, domain.area*1e-11, domain.length*tolerance)
        overlap = max(0., sum(p.area for p in shapes)-union.area)
        missing = domain.difference(union)
        extra = union.difference(domain)
        missing_interior = domain.buffer(-reference_tolerance).difference(union).area
        extra_outside = union.difference(domain.buffer(reference_tolerance)).area
        okay = overlap <= area_tolerance and missing_interior <= area_tolerance and extra_outside <= area_tolerance
        coverage.append({'roof_id':roof,'passed':bool(okay),'expected_xy_area_m2':float(domain.area),
                         'actual_xy_union_area_m2':float(union.area),'overlap_xy_area_m2':float(overlap),
                         'missing_xy_area_m2':float(missing.area),'extra_xy_area_m2':float(extra.area),
                         'missing_interior_xy_area_m2':float(missing_interior),
                         'extra_outside_reference_strip_m2':float(extra_outside),
                         'area_tolerance_m2':area_tolerance,'reference_strip_tolerance_m':reference_tolerance})
        if not okay:
            failures.append({'roof_id':roof,'error':'actual projected plates have overlap, missing interior, or exterior spill'})
    rectangles = sum(p['is_rectangle'] for p in panels)
    trims = sum(p['arc_trim'] for p in panels)
    geometry_passed = not failures and rectangles+trims == len(raw_panels)
    coverage_passed = bool(coverage) and all(p['passed'] for p in coverage) and not any('roof_id' in p for p in unverified)
    return {'format':'independent-rectangle-neighbour-validation-1',
            'all_passed':bool(geometry_passed and not unequal and coverage_passed and not unverified),
            'geometry_passed':bool(geometry_passed),'neighbour_similarity_passed':not unequal,
            'complete_coverage_passed':bool(coverage_passed),'input_panel_count':len(raw_panels),
            'valid_mesh_count':len(panels),'true_rectangle_count':int(rectangles),
            'verified_exterior_arc_crop_count':int(trims),'unverified_checks':unverified,
            'max_plane_error_m':max((p['plane_error_m'] for p in panels),default=0.),
            'max_right_angle_cos_error':max((p['right_angle_cos_error'] or 0. for p in panels if p['is_rectangle']),default=0.),
            'actual_shared_edge_neighbour_pairs':len(pairs),'full_rectangle_neighbour_pairs':len(full_ratios),
            'neighbour_pairs_with_exterior_crops_excluded_from_similarity':trimmed_pairs,
            'neighbour_dimension_definition':'sorted actual physical rectangle side lengths, independently recovered from mesh',
            'neighbour_max_allowed_ratio':adjacent_ratio,
            'neighbour_max_observed_ratio':max(full_ratios,default=1.),
            'neighbour_violations':unequal,'coverage':coverage,'failures':failures,
            'tolerances':{'planarity_and_edges_m':tolerance,'right_angle_cosine':angle_tolerance,
                          'exterior_reference_strip_m':reference_tolerance},
            'scope_note':'full-rectangle neighbour similarity excludes arc crops; no original-form preservation or ridge alignment claimed by this validator'}


def self_test():
    def panel(identity, points, **kwargs):
        return dict(id=identity,roof_id='A',vertices=[[x,y,0.] for x,y in points],
                    faces=[list(range(len(points)))],**kwargs)
    reference={'roofs':[{'roof_id':'A','exterior':[[0,0],[2,0],[2,1],[0,1]],'arc_edge_indices':[]}]}
    a=panel('a',[(0,0),(1,0),(1,1),(0,1)])
    b=panel('b',[(1,0),(2,0),(2,1),(1,1)])
    report=validate({'panels':[a,b]},reference)
    assert report['all_passed'] and report['actual_shared_edge_neighbour_pairs']==1
    # A nominal/metadata rectangle with slanted corners must fail.
    trapezoid=panel('false-rectangle',[(0,0),(1,0),(.8,1),(0,1)],is_rectangle=True)
    assert not validate({'panels':[trapezoid]},reference)['geometry_passed']
    bent=panel('bent',[(0,0),(1,0),(1,1),(0,1)]);bent['vertices'][2][2]=.01
    assert not validate({'panels':[bent]},reference)['geometry_passed']
    # Merely touching bounding boxes or crossing edges is not adjacency.
    shifted=panel('separate',[(1.01,0),(2.01,0),(2.01,1),(1.01,1)])
    assert validate({'panels':[a,shifted]})['actual_shared_edge_neighbour_pairs']==0
    # One full side meeting two half-sides is detected as two real T neighbours.
    half1=panel('half1',[(1,0),(2,0),(2,.5),(1,.5)])
    half2=panel('half2',[(1,.5),(2,.5),(2,1),(1,1)])
    t=validate({'panels':[a,half1,half2]},reference)
    assert t['actual_shared_edge_neighbour_pairs']==3 and not t['neighbour_similarity_passed']
    # Missing area and duplicated plates fail coverage even with valid rectangles.
    assert not validate({'panels':[a]},reference)['complete_coverage_passed']
    assert not validate({'panels':[a,a,b]},reference)['complete_coverage_passed']
    # Collinear boundary subdivisions do not make a true rectangle a pentagon.
    split=panel('subdivided',[(0,0),(.5,0),(1,0),(1,1),(0,1)])
    assert actual_panel(split)['is_rectangle']
    # A bent roof can still have genuine equal-size shared-edge neighbours.
    folded=dict(id='folded-neighbour',roof_id='A',vertices=[[1,0,0],[2,0,.5],[2,1,.5],[1,1,0]],faces=[[0,1,2],[0,2,3]])
    edge_pair=actual_neighbours([actual_panel(a),actual_panel(folded)],1e-7,1e-6)
    assert len(edge_pair)==1
    print(json.dumps({'self_test_passed':True,'checks':9}))


def main():
    parser=argparse.ArgumentParser(description=__doc__,formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('input',nargs='?',type=Path)
    parser.add_argument('--reference',type=Path,help='independent complete roof exterior/arcs JSON')
    parser.add_argument('--source',type=Path,help='original modelData.json; derives full roofs independently')
    parser.add_argument('--output',type=Path)
    parser.add_argument('--adjacent-ratio',type=float,default=1.10)
    parser.add_argument('--tolerance-m',type=float,default=1e-7)
    parser.add_argument('--angle-tolerance',type=float,default=1e-6)
    parser.add_argument('--reference-tolerance-m',type=float,default=1e-5)
    parser.add_argument('--self-test',action='store_true')
    args=parser.parse_args()
    if args.self_test:
        self_test();return 0
    parser.error('input is required unless --self-test is used') if args.input is None else None
    data=json.loads(args.input.read_text())
    reference=json.loads(args.reference.read_text()) if args.reference else None
    if args.source:
        reference=reference_from_source(json.loads(args.source.read_text()),roof_ids={str(p.get('roof_id','A')) for p in expand_panels(data)})
    report=validate(data,reference,args.tolerance_m,args.angle_tolerance,args.adjacent_ratio,args.reference_tolerance_m)
    rendered=json.dumps(report,ensure_ascii=False,indent=2)
    if args.output:args.output.write_text(rendered+'\n')
    summary={k:v for k,v in report.items() if k not in ('failures','neighbour_violations','unverified_checks','coverage')}
    print(json.dumps(summary,ensure_ascii=False,indent=2))
    return 0 if report['all_passed'] else 2 if report['unverified_checks'] and not report['failures'] else 1


if __name__=='__main__':
    raise SystemExit(main())
