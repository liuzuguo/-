#!/usr/bin/env python3
"""Independently audit V8 installed meshes against the approved NEW roof.

This verifier never uses a panel's rectangle label, nominal stock dimensions,
reported area, or worker summary as geometric proof. Actual mesh triangle unions
provide the corners. The independently supplied reconstructionData.json supplies
the complete roof perimeter and the ONLY exterior-arc exceptions. All interior
plates must have four actual corners, four right angles, equal/parallel opposite
sides and <= 1e-7 m plane error. Fold partitions come from actual 3-D mesh edges.

Usage: python validate_dynamic_geometry_v8.py generated.json --output report.json
       python validate_dynamic_geometry_v8.py --self-test

NumPy and Shapely are required. The adjacent general mesh verifier supplies only
mesh/edge primitives; it has no dependency on the V8 geometry generator.
"""
from __future__ import annotations

import argparse
from collections import defaultdict
import hashlib
import json
import math
from pathlib import Path
import sys

import validate_rectangles_and_neighbors as meshcheck
import numpy as np
from shapely.geometry import LineString, MultiLineString, Polygon
from shapely.ops import unary_union

ROOT = Path(__file__).resolve().parent
PLANE_M = 1e-7
ANGLE = 1e-7
RULE = {'panels': 'planar_rectangles', 'planarity_tolerance_mm': .0001,
        'ridge_seams': 'aligned', 'exterior_arc_trims': True,
        'neighbor_tolerance': .1, 'source_geometry': 'reconstructed_with_user_approval'}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def selected_candidate(data):
    if isinstance(data.get('panels'), list):
        return data
    candidates = data.get('candidates', [])
    require(bool(candidates), 'no candidates or actual panels')
    return next((c for c in candidates if c.get('id') == data.get('recommended_id')), candidates[0])


def make_reference(reconstruction):
    """Use the approved design file, never a worker-produced crop label."""
    require(reconstruction.get('user_approved_reconstruction') is True,
            'independent reconstruction does not record user approval')
    outline = np.asarray(reconstruction.get('outline'), dtype=float)
    require(outline.ndim == 2 and outline.shape[1] >= 2 and len(outline) >= 3
            and np.isfinite(outline).all(), 'reconstruction has no finite full-roof outline')
    outline = outline[:, :2]
    if np.linalg.norm(outline[0]-outline[-1]) < 1e-12:
        outline = outline[:-1]
    indices = reconstruction.get('arc_edge_indices')
    require(isinstance(indices, list) and bool(indices),
            'reconstruction must independently identify actual exterior arc_edge_indices')
    require(all(type(i) is int and 0 <= i < len(outline) for i in indices),
            'an arc exception is not an edge of the complete exterior')
    reference = {'roofs': [{'roof_id': 'A', 'exterior': outline.tolist(), 'arc_edge_indices': indices}]}
    prepared = meshcheck.prepare_reference(reference)['A']
    return prepared


def corner_metrics(points):
    points = np.asarray(points, dtype=float)
    if len(points) != 4:
        return {'corner_count': len(points), 'is_rectangle': False}
    edges = np.roll(points, -1, axis=0)-points
    lengths = np.linalg.norm(edges, axis=1)
    if min(lengths) <= PLANE_M:
        return {'corner_count': 4, 'is_rectangle': False}
    units = edges/lengths[:, None]
    right = float(np.max(np.abs(np.sum(units*np.roll(units, -1, axis=0), axis=1))))
    parallel = max(float(np.linalg.norm(np.cross(units[0], units[2]))),
                   float(np.linalg.norm(np.cross(units[1], units[3]))))
    equal = max(float(abs(lengths[0]-lengths[2])), float(abs(lengths[1]-lengths[3])))
    return {'corner_count': 4, 'is_rectangle': bool(right <= ANGLE and parallel <= ANGLE
                and equal <= max(PLANE_M*4, max(lengths)*ANGLE)),
            'max_right_angle_cosine_error': right, 'max_opposite_parallel_sine_error': parallel,
            'max_opposite_side_difference_m': equal,
            'actual_sides_m': sorted([float((lengths[0]+lengths[2])/2),
                                      float((lengths[1]+lengths[3])/2)])}


def directional_sizes(panel):
    """Intrinsic chord-direction/Y extents, including honest tiny arc crops."""
    points = panel['ring_xyz']
    normal = panel['normal']
    # Reconstructed strips extrude along world-A Y. This axis lies in each plane.
    axis_y = np.array([0., 1., 0.])
    require(abs(float(normal @ axis_y)) <= ANGLE, 'plate is not on a reconstructed extrusion strip')
    axis_chord = np.cross(axis_y, normal)
    axis_chord /= np.linalg.norm(axis_chord)
    return [float(np.ptp(points @ axis_chord)), float(np.ptp(points[:, 1]))]


def coverage_report(panels, reference):
    shapes = [Polygon(p['ring_xyz'][:, :2]) for p in panels]
    require(bool(shapes), 'no actual meshes available for coverage')
    union = unary_union(shapes)
    domain = reference['domain']
    gap = float(domain.difference(union).area)
    extra = float(union.difference(domain).area)
    overlap = max(0., float(sum(p.area for p in shapes)-union.area))
    area_tolerance = max(1e-9, domain.length*PLANE_M, domain.area*1e-11)
    return {'passed': bool(max(gap, extra, overlap) <= area_tolerance),
            'coverage_target': 'approved reconstructed footprint, not the original 3-D roof surface',
            'expected_xy_area_m2': float(domain.area), 'actual_xy_union_area_m2': float(union.area),
            'missing_xy_area_m2': gap, 'extra_xy_area_m2': extra,
            'overlap_xy_area_m2': overlap, 'area_tolerance_m2': area_tolerance,
            'linear_tolerance_m': PLANE_M}


def line_intervals(geometry):
    if geometry.is_empty:
        return []
    if geometry.geom_type in ('LineString', 'LinearRing'):
        values = np.asarray(geometry.coords)[:, 1]
        return [[float(min(values)), float(max(values))]] if np.ptp(values) > PLANE_M else []
    return [value for item in getattr(geometry, 'geoms', []) for value in line_intervals(item)]


def fold_alignment(panels, grid, reference):
    """Recover both side partitions from actual edges, not ridge summary records."""
    cuts = np.asarray(grid.get('u_cuts'), dtype=float)
    require(cuts.ndim == 1 and len(cuts) >= 2 and np.isfinite(cuts).all()
            and np.all(np.diff(cuts) > PLANE_M), 'invalid strip stations')
    ymin, ymax = reference['domain'].bounds[1], reference['domain'].bounds[3]
    actual = defaultdict(lambda: [[], []])
    failures = []
    for p in panels:
        xyz = p['ring_xyz']
        # Every actual installed polygon must lie within a single strip.
        low, high = float(xyz[:, 0].min()), float(xyz[:, 0].max())
        if any(low+PLANE_M < x < high-PLANE_M for x in cuts[1:-1]):
            failures.append({'id': p['id'], 'error': 'actual plate crosses a reconstructed fold station'})
        center_x = float(xyz[:, 0].mean())
        for a, b in zip(xyz, np.roll(xyz, -1, axis=0)):
            if abs(float(a[0]-b[0])) > PLANE_M or np.linalg.norm(b-a) <= PLANE_M*10:
                continue
            j = int(np.argmin(abs(cuts-a[0])))
            if not 0 < j < len(cuts)-1 or abs(float(cuts[j]-a[0])) > PLANE_M:
                continue
            side = 0 if center_x < cuts[j] else 1
            actual[j][side].append([float(min(a[1], b[1])), float(max(a[1], b[1]))])
    records = []
    maximum = 0.
    for j, x in enumerate(cuts[1:-1], 1):
        left, right = [sorted(intervals) for intervals in actual[j]]
        expected = line_intervals(reference['domain'].intersection(LineString([(x, ymin-1), (x, ymax+1)])))
        error = math.inf
        if left and len(left) == len(right):
            error = max(abs(a-b) for li, ri in zip(left, right) for a, b in zip(li, ri))
        complete = True
        for side in (left, right):
            union = unary_union([LineString([(x, a), (x, b)]) for a, b in side]) if side else LineString()
            target = unary_union([LineString([(x, a), (x, b)]) for a, b in expected])
            complete &= union.symmetric_difference(target).length <= PLANE_M*max(4, len(side)*2)
            complete &= all(b[0] >= a[1]-PLANE_M for a, b in zip(side, side[1:]))
        okay = bool(error <= PLANE_M and complete)
        if math.isfinite(error):
            maximum = max(maximum, error)
        records.append({'station_index': j, 'x_m': float(x), 'aligned': okay,
                        'left_actual_y_intervals': left, 'right_actual_y_intervals': right,
                        'max_opposing_endpoint_error_m': error if math.isfinite(error) else None,
                        'complete_fold_edge_covered': bool(complete)})
    return {'passed': all(r['aligned'] for r in records) and not failures,
            'checked_fold_stations': len(records),
            'mismatched_fold_stations': sum(not r['aligned'] for r in records),
            'max_opposing_station_error_m': maximum, 'edges': records, 'failures': failures}


def instance_audit(panels, instances, expected_instances):
    """Check every world-instance vertex/corner after actual floating transforms."""
    require(isinstance(instances, list) and len(instances) == 4, 'V8 requires four complete roof instances')
    expected = {str(item.get('roof_id')): item for item in expected_instances}
    require(set(expected) == set('ABCD'), 'independent reconstruction must supply roofs A-D')
    result = []
    for index, instance in enumerate(instances):
        matrix = np.asarray(instance.get('matrix'), dtype=float)
        require(matrix.size == 16 and np.isfinite(matrix).all(), 'invalid actual roof instance matrix')
        matrix = matrix.reshape(4, 4).T
        roof_id = str(instance.get('roof_id', 'ABCD'[index]))
        require(roof_id in expected, 'instance roof is absent from independent reconstruction')
        expected_matrix = np.asarray(expected[roof_id]['matrix'], dtype=float).reshape(4, 4).T
        require(float(np.max(abs(matrix-expected_matrix))) <= 1e-8,
                'actual roof instance placement differs from independently reconstructed roof')
        rotation, translation = matrix[:3, :3], matrix[:3, 3]
        rigid_error = float(np.max(abs(rotation.T @ rotation-np.eye(3))))
        require(rigid_error <= 1e-8 and abs(abs(np.linalg.det(rotation))-1) <= 1e-8,
                'instance transform changes physical plate dimensions')
        require(np.max(abs(matrix[3]-np.array([0., 0., 0., 1.]))) <= 1e-10,
                'roof transform is not affine')
        plane_max = right_max = parallel_max = opposite_max = 0.
        rectangles = 0
        for panel in panels:
            points = panel['vertices'] @ rotation.T+translation
            normal = panel['normal'] @ rotation.T
            origin = panel['origin'] @ rotation.T+translation
            plane = float(np.max(abs((points-origin) @ normal)))
            require(plane <= PLANE_M, f'instance {index}, plate {panel["id"]} exceeds planarity tolerance')
            plane_max = max(plane_max, plane)
            if panel['is_rectangle']:
                corners = panel['ring_xyz'] @ rotation.T+translation
                metric = corner_metrics(corners)
                require(metric['is_rectangle'], f'instance {index}, plate {panel["id"]} fails actual four-corner rectangle')
                right_max = max(right_max, metric['max_right_angle_cosine_error'])
                parallel_max = max(parallel_max, metric['max_opposite_parallel_sine_error'])
                opposite_max = max(opposite_max, metric['max_opposite_side_difference_m'])
                rectangles += 1
        result.append({'roof_id': roof_id,
                       'passed': True, 'actual_panel_count': len(panels),
                       'actual_four_corner_rectangle_count': rectangles,
                       'actual_exterior_arc_crop_count': len(panels)-rectangles,
                       'rigid_isometry_error': rigid_error, 'max_actual_plane_error_m': plane_max,
                       'max_actual_right_angle_cosine_error': right_max,
                       'max_actual_opposite_parallel_sine_error': parallel_max,
                       'max_actual_opposite_side_difference_m': opposite_max})
    require(len({r['roof_id'] for r in result}) == 4, 'four roof instance identifiers must be distinct')
    return result


def source_change_report(reconstruction, grid):
    source = reconstruction.get('reference', {})
    vertices = np.asarray(source.get('verticesA', []), dtype=float)
    faces = np.asarray(source.get('facesA', []), dtype=int)
    nodes = np.asarray(grid.get('profile_nodes', []), dtype=float)
    if not vertices.size or not faces.size or not nodes.size:
        return {'verified': False, 'reason': 'independent original reference vertices/faces unavailable'}
    if vertices.ndim == 3:
        triangles = np.concatenate([half[faces] for half in vertices])
        vertices = vertices.reshape(-1, 3)
    else:
        triangles = vertices[faces]
    target_z = np.interp(vertices[:, 0], nodes[:, 0], nodes[:, 1])
    centroids = triangles.mean(axis=1)
    weights = np.linalg.norm(np.cross(triangles[:, 1]-triangles[:, 0], triangles[:, 2]-triangles[:, 0]), axis=1)/2
    residual = centroids[:, 2]-np.interp(centroids[:, 0], nodes[:, 0], nodes[:, 1])
    return {'verified': True, 'source_vertex_max_vertical_change_m': float(max(abs(target_z-vertices[:, 2]))),
            'source_centroid_area_weighted_rms_vertical_change_m': float(np.sqrt(np.average(residual**2, weights=weights))),
            'source_centroid_p95_abs_vertical_change_m': float(np.percentile(abs(residual), 95)),
            'original_source_surface_is_coverage_target': False}


def validate(data, reconstruction):
    candidate = selected_candidate(data)
    reference = make_reference(reconstruction)
    failures = []
    raw_panels = candidate.get('panels', [])
    require(bool(raw_panels), 'empty actual panel array')
    require(len({str(p.get('id', '?')) for p in raw_panels}) == len(raw_panels),
            'actual panel identifiers are not unique')
    panels = []
    for raw in raw_panels:
        try:
            faces = raw.get('faces')
            require(isinstance(faces, list) and bool(faces) and
                    all(isinstance(f, list) and len(set(f)) == len(f) for f in faces),
                    'actual installed mesh must have nonempty faces with unique vertex indices')
            panel = meshcheck.actual_panel(raw, PLANE_M, ANGLE)
            metric = corner_metrics(panel['ring_xyz'])
            require(panel['is_rectangle'] == metric['is_rectangle'], 'inconsistent independent corner extraction')
            require(raw.get('needs_bend') is not True, 'folded-panel metadata conflicts with flat roof plates')
            if not panel['is_rectangle']:
                meshcheck.verify_exterior_arc_crop(panel, reference, PLANE_M, ANGLE, PLANE_M)
            panel['metric'] = metric
            panel['directional_actual_sizes_m'] = directional_sizes(panel)
            panels.append(panel)
        except (ValueError, KeyError, TypeError, IndexError) as error:
            failures.append({'id': str(raw.get('id', '?')), 'error': str(error)})
    pairs = meshcheck.actual_neighbours(panels, PLANE_M, ANGLE)
    interior_pairs = []; trim_pairs = []; violations = []
    for (i, j), shared in pairs.items():
        a, b = panels[i], panels[j]
        dimensions_a, dimensions_b = a['directional_actual_sizes_m'], b['directional_actual_sizes_m']
        ratio = max(x/y for x, y in zip(dimensions_a, dimensions_b))
        ratio = max(ratio, max(y/x for x, y in zip(dimensions_a, dimensions_b)))
        if a['is_rectangle'] and b['is_rectangle']:
            interior_pairs.append(ratio)
            if ratio > 1.1+ANGLE:
                violations.append({'a': a['id'], 'b': b['id'], 'actual_size_ratio': ratio,
                                   'a_actual_chord_y_sizes_m': dimensions_a,
                                   'b_actual_chord_y_sizes_m': dimensions_b, 'shared_edge_m': shared})
        else:
            trim_pairs.append(ratio)
    coverage = coverage_report(panels, reference)
    grid = candidate.get('grid', {})
    seams = fold_alignment(panels, grid, reference)
    instances = candidate.get('instances', data.get('instances', reconstruction.get('instances')))
    world = instance_audit(panels, instances, reconstruction.get('instances', []))
    surface_area = float(sum(p['polygon'].area for p in panels))
    coverage['world_coverage_proof'] = 'The complete actual roof-A mesh covers its independent footprint; every A-D placement matches the independent approved rigid instance transform.'
    coverage['world_roof_ids'] = [r['roof_id'] for r in world]
    rectangles = [p for p in panels if p['is_rectangle']]
    trims = [p for p in panels if not p['is_rectangle']]
    # Profile endpoints must lie on the independently approved reconstructed profile.
    nodes = np.asarray(grid.get('profile_nodes'), dtype=float)
    profile = np.asarray(reconstruction.get('profile'), dtype=float)
    require(nodes.ndim == 2 and nodes.shape[1] == 2 and profile.ndim == 2 and profile.shape[1] == 2,
            'missing approved and actual reconstructed profile nodes')
    profile_error = float(max(abs(nodes[:, 1]-np.interp(nodes[:, 0], profile[:, 0], profile[:, 1]))))
    require(profile_error <= PLANE_M, 'worker changed approved reconstruction profile endpoint heights')
    require(len(nodes) == len(grid.get('u_cuts', [])) and
            max(abs(nodes[:, 0]-np.asarray(grid['u_cuts']))) <= PLANE_M,
            'actual strip stations disagree with reconstructed profile nodes')
    actual_surface_error = max(float(max(abs(p['vertices'][:, 2]-
                np.interp(p['vertices'][:, 0], nodes[:, 0], nodes[:, 1])))) for p in panels)
    require(actual_surface_error <= PLANE_M,
            'actual installed plate vertices do not lie on the approved reconstructed strip surface')
    chords = np.linalg.norm(np.diff(nodes, axis=0), axis=1)
    actual_widths = [p['directional_actual_sizes_m'][0] for p in rectangles]
    actual_lengths = [p['directional_actual_sizes_m'][1] for p in rectangles]
    trim_sides = [p['directional_actual_sizes_m'] for p in trims]
    if 'nominal_width_m' in data and 'nominal_length_m' in data:
        width_limit, length_limit = float(data['nominal_width_m']), float(data['nominal_length_m'])
        require(math.isfinite(width_limit) and math.isfinite(length_limit) and min(width_limit, length_limit) > 0,
                'invalid independently selected directional dimensions')
        require(all(p['directional_actual_sizes_m'][0] <= width_limit+PLANE_M and
                    p['directional_actual_sizes_m'][1] <= length_limit+PLANE_M for p in panels),
                'an actual physical plate extent exceeds the selected directional width/length')
    version_ok = data.get('panel_study_version') == 'v8-rectangular-rebuilt'
    rule_ok = data.get('geometry_rule') == RULE
    if not version_ok:
        failures.append({'error': 'missing exact V8 reconstructed-roof version declaration'})
    if not rule_ok:
        failures.append({'error': 'geometry_rule does not declare all approved V8 requirements',
                         'actual': data.get('geometry_rule'), 'expected': RULE})
    geometry_passed = not failures and len(panels) == len(raw_panels)
    all_passed = geometry_passed and coverage['passed'] and seams['passed'] and not violations
    return {'format': 'independent-dynamic-geometry-validation-8', 'all_passed': bool(all_passed),
            'geometry_passed': bool(geometry_passed), 'complete_coverage_passed': coverage['passed'],
            'interior_neighbor_similarity_passed': not violations, 'reconstructed_fold_alignment_passed': seams['passed'],
            'template_actual_panel_count': len(raw_panels), 'template_true_rectangle_count': len(rectangles),
            'template_verified_exterior_arc_crop_count': len(trims),
            'full_actual_panel_count': len(panels)*len(world), 'full_true_rectangle_count': len(rectangles)*len(world),
            'full_verified_exterior_arc_crop_count': len(trims)*len(world),
            'template_actual_surface_area_m2': surface_area,
            'full_actual_surface_area_m2': surface_area*len(world),
            'max_actual_plane_error_m': max(r['max_actual_plane_error_m'] for r in world),
            'max_actual_right_angle_cosine_error': max(r['max_actual_right_angle_cosine_error'] for r in world),
            'max_actual_opposite_parallel_sine_error': max(r['max_actual_opposite_parallel_sine_error'] for r in world),
            'max_actual_opposite_side_difference_m': max(r['max_actual_opposite_side_difference_m'] for r in world),
            'actual_rectangle_chord_width_min_m': min(actual_widths, default=None), 'actual_rectangle_chord_width_max_m': max(actual_widths, default=None),
            'actual_rectangle_y_length_min_m': min(actual_lengths, default=None), 'actual_rectangle_y_length_max_m': max(actual_lengths, default=None),
            'actual_strip_chord_min_m': float(min(chords)), 'actual_strip_chord_max_m': float(max(chords)),
            'max_profile_endpoint_error_m': profile_error,
            'max_actual_vertex_to_rebuilt_surface_error_m': actual_surface_error,
            'actual_shared_edge_neighbor_pairs': len(pairs), 'interior_rectangle_neighbor_pairs': len(interior_pairs),
            'neighbor_statistics_scope': 'one complete roof-A template; identical intrinsic dimensions in all four independently checked rigid instances',
            'full_actual_shared_edge_neighbor_pairs': len(pairs)*len(world),
            'interior_neighbor_max_actual_size_ratio': max(interior_pairs, default=1.),
            'interior_neighbor_max_relative_difference': max(interior_pairs, default=1.)-1,
            'neighbor_allowed_actual_size_ratio': 1.1,
            'neighbor_dimension_definition': 'independently measured physical strip-chord and Y edge sizes; max(a/b,b/a)<=1.10',
            'exterior_arc_crop_neighbor_pairs': len(trim_pairs),
            'exterior_arc_crop_neighbor_max_actual_size_ratio': max(trim_pairs, default=1.),
            'exterior_arc_crop_neighbor_max_relative_difference': max(trim_pairs, default=1.)-1,
            'exterior_arc_crop_chord_extent_min_m': min((p[0] for p in trim_sides), default=None),
            'exterior_arc_crop_chord_extent_max_m': max((p[0] for p in trim_sides), default=None),
            'exterior_arc_crop_y_extent_min_m': min((p[1] for p in trim_sides), default=None),
            'exterior_arc_crop_y_extent_max_m': max((p[1] for p in trim_sides), default=None),
            'exterior_arc_crop_similarity_is_subject_to_10_percent_bound': False,
            'coverage': coverage, 'fold_alignment': seams, 'actual_world_instances': world,
            'approved_reconstruction_source_change': source_change_report(reconstruction, grid),
            'neighbor_violations': violations, 'failures': failures,
            'tolerances': {'actual_plane_m': PLANE_M, 'actual_edges_and_outer_arc_m': PLANE_M,
                           'right_angle_cosine_and_parallel_sine': ANGLE},
            'scope': 'Every actual rectangle corner and every world-instance vertex checked. Exterior crops are checked against the independent complete NEW footprint, never source facets or old crease edges.'}


def self_test():
    """Adversarial tests exercise geometry, true-arc provenance and folded seams."""
    meshcheck.self_test()
    tests = 9
    def raw(identity, points, **kwargs):
        return dict(id=identity, roof_id='A', vertices=points,
                    faces=[list(range(len(points)))], **kwargs)
    rectangle = raw('r', [[0,0,0], [1,0,.5], [1,1,.5], [0,1,0]])
    p = meshcheck.actual_panel(rectangle)
    assert corner_metrics(p['ring_xyz'])['is_rectangle']; tests += 1
    trapezoid = raw('fake', [[0,0,0], [1,0,0], [.8,1,0], [0,1,0]], is_rectangle=True)
    assert not corner_metrics(meshcheck.actual_panel(trapezoid)['ring_xyz'])['is_rectangle']; tests += 1
    # A slanted internal/facet cut cannot claim the roof's remote exterior arc.
    ref = meshcheck.prepare_reference({'roofs': [{'roof_id':'A', 'exterior':[[0,0],[3,0],[3,3],[2,4],[0,4]], 'arc_edge_indices':[2]}]})['A']
    try:
        meshcheck.verify_exterior_arc_crop(meshcheck.actual_panel(trapezoid), ref, PLANE_M, ANGLE, PLANE_M)
        raise AssertionError('fake arc trim accepted')
    except ValueError:
        tests += 1
    # A genuine outer-arc crop is a rectangle intersected with the complete roof.
    crop = raw('arc', [[2,2,0],[3,2,0],[3,3,0],[2,4,0]])
    meshcheck.verify_exterior_arc_crop(meshcheck.actual_panel(crop), ref, PLANE_M, ANGLE, PLANE_M)
    tests += 1
    # Shared folded edge: same station partitions pass; a T joint fails.
    a = meshcheck.actual_panel(raw('a', [[0,0,0],[1,0,0],[1,1,0],[0,1,0]]))
    b = meshcheck.actual_panel(raw('b', [[1,0,0],[2,0,.5],[2,1,.5],[1,1,0]]))
    domain = meshcheck.prepare_reference({'roofs':[{'roof_id':'A','exterior':[[0,0],[2,0],[2,1],[0,1]],'arc_edge_indices':[]}]})['A']
    assert fold_alignment([a,b], {'u_cuts':[0,1,2]}, domain)['passed']; tests += 1
    b1 = meshcheck.actual_panel(raw('b1', [[1,0,0],[2,0,.5],[2,.5,.5],[1,.5,0]]))
    b2 = meshcheck.actual_panel(raw('b2', [[1,.5,0],[2,.5,.5],[2,1,.5],[1,1,0]]))
    assert not fold_alignment([a,b1,b2], {'u_cuts':[0,1,2]}, domain)['passed']; tests += 1
    assert not coverage_report([a,a,b], domain)['passed']; tests += 1
    # Whole-study tests reject forged instances and a roof moved away from its
    # declared profile, even when every plate individually remains rectangular.
    identity = np.eye(4).T.reshape(-1).tolist()
    instances = [{'roof_id': letter, 'matrix': identity} for letter in 'ABCD']
    outline = [[0,0],[2,0],[2,.8],[1.8,1],[0,1]]
    reconstruction = {'user_approved_reconstruction': True, 'outline': outline,
                      'arc_edge_indices': [2], 'profile': [[0,0],[2,0]], 'instances': instances}
    arc = raw('trim', [[1,0,0],[2,0,0],[2,.8,0],[1.8,1,0],[1,1,0]])
    study = {'panel_study_version':'v8-rectangular-rebuilt', 'geometry_rule':RULE,
             'instances':instances, 'panels':[raw('square',[[0,0,0],[1,0,0],[1,1,0],[0,1,0]]),arc],
             'grid':{'u_cuts':[0,1,2], 'profile_nodes':[[0,0],[1,0],[2,0]]}}
    assert validate(study, reconstruction)['all_passed']; tests += 1
    import copy
    moved = copy.deepcopy(study)
    moved['instances'][1]['matrix'][12] = 20
    try:
        validate(moved, reconstruction)
        raise AssertionError('wrong roof placement accepted')
    except ValueError:
        tests += 1
    floated = copy.deepcopy(study)
    for item in floated['panels']:
        for point in item['vertices']:
            point[2] += 1
    try:
        validate(floated, reconstruction)
        raise AssertionError('wrong reconstructed surface accepted')
    except ValueError:
        tests += 1
    print(json.dumps({'v8_adversarial_self_tests_passed': True, 'checks': tests}))


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('input', type=Path, nargs='?')
    parser.add_argument('--reconstruction', type=Path, default=ROOT/'reconstructionData.json')
    parser.add_argument('--output', type=Path)
    parser.add_argument('--self-test', action='store_true')
    args = parser.parse_args()
    if args.self_test:
        self_test()
        return 0
    if args.input is None:
        parser.error('input required unless --self-test is given')
    data = json.loads(args.input.read_text())
    reconstruction = json.loads(args.reconstruction.read_text())
    try:
        report = validate(data, reconstruction)
    except (ValueError, TypeError, KeyError, IndexError) as error:
        report = {'format':'independent-dynamic-geometry-validation-8', 'all_passed':False,
                  'failures':[{'error':str(error)}]}
    report['input_sha256'] = hashlib.sha256(args.input.read_bytes()).hexdigest()
    report['independent_reconstruction_sha256'] = hashlib.sha256(args.reconstruction.read_bytes()).hexdigest()
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n')
    summary = {k:v for k,v in report.items() if k not in ('fold_alignment', 'actual_world_instances', 'neighbor_violations')}
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0 if report['all_passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
