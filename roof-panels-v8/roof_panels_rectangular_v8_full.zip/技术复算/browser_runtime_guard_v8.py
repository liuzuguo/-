"""V8 negative geometry controls, embedded offline worker, and WebGL fallback."""
from pathlib import Path
from functools import partial
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
import threading, json, hashlib, base64
from playwright.sync_api import sync_playwright, expect, Error as PlaywrightError

ROOT = Path(__file__).resolve().parent
PORT = 8055


class QuietHandler(SimpleHTTPRequestHandler):
    def log_message(self, *args):
        pass


NEGATIVE_CONTROL = r"""kind => {
  const t=ROOF_PANEL_TEST,before=t.candidate,beforeWorld=t.world,fake=structuredClone(before);
  const p=fake.panels.find(p=>p.vertices.length===4 && p.is_rectangle===true) ||
    fake.panels.find(p=>p.vertices.length===4 && p.layout_shape==='rectangle') ||
    fake.panels.find(p=>p.vertices.length===4 && !p.is_arc_trim);
  if(!p)throw Error('No four-corner interior rectangle found');
  fake.id='intentional-'+kind+'-negative-control';
  p.vertices=kind==='bent'?[[0,0,0],[1,0,0],[1,1,.01],[0,1,0]]:
    [[0,0,0],[1,0,0],[1.2,1,0],[.2,1,0]];
  p.faces=[[0,1,2],[0,2,3]];
  p.kind='planar';p.nonplanarity_mm=0;p.needs_bend=false;
  t.data.candidates.push(fake);let rejected=false,message='';
  try{t.choose(fake.id)}catch(error){rejected=true;message=error.message}
  finally{t.data.candidates=t.data.candidates.filter(c=>c.id!==fake.id)}
  return {rejected,message,unchanged_candidate:t.candidate===before,
    unchanged_world:t.world===beforeWorld,retained_count:t.world.length};
}"""


def main():
    server=ThreadingHTTPServer(('127.0.0.1',PORT),partial(QuietHandler,directory=str(ROOT)))
    threading.Thread(target=server.serve_forever,daemon=True).start()
    checks=[];errors=[];external=[]
    try:
        with sync_playwright() as p:
            browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=[
                '--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'])
            context=browser.new_context(viewport={'width':1780,'height':1220})
            page=context.new_page();page.set_default_timeout(120000)
            page.on('pageerror',lambda e:errors.append(str(e)))
            page.on('request',lambda r:external.append(r.url) if not r.url.startswith((
                f'http://127.0.0.1:{PORT}/','blob:','data:')) else None)
            response=page.goto(f'http://127.0.0.1:{PORT}/app.html');page.wait_for_function('window.ROOF_PANEL_TEST')
            actual_response_html_sha256=hashlib.sha256(response.body()).hexdigest()
            embedded_worker_sha256=hashlib.sha256(base64.b64decode(
                page.locator('#workerData').text_content().strip())).hexdigest()
            manifest=json.loads((ROOT/'build_manifest.json').read_text())
            worker_sha256=hashlib.sha256((ROOT/'panel-worker.js').read_bytes()).hexdigest()
            html_sha256=hashlib.sha256((ROOT/'app.html').read_bytes()).hexdigest()
            assert actual_response_html_sha256==html_sha256==manifest['html_sha256']
            assert embedded_worker_sha256==worker_sha256==manifest['worker_sha256']
            checks.append('Actual HTTP response HTML and embedded worker hashes match disk and final build manifest')
            controls={kind:page.evaluate(NEGATIVE_CONTROL,kind) for kind in ['bent','skewed']}
            for kind,result in controls.items():
                assert result['rejected'] and result['unchanged_candidate'] and result['unchanged_world'],(kind,result)
            checks.append('Actual XYZ rejects bent and skewed plates despite rectangle/planar metadata; active candidate retained')
            context.set_offline(True)
            offline=page.evaluate('''async()=>{
              const t=ROOF_PANEL_TEST,c=await t.requestSize(2123,4789);
              renderer.render();return {applied:!!c,width:t.sizing.widthMm,length:t.sizing.lengthMm,
                panels:t.world.length,gl_error:t.gl.getError(),instances:c?.instances?.length};
            }''')
            assert offline['applied'] and offline['width']==2123 and offline['length']==4789
            assert offline['panels']>0 and offline['instances']==4 and offline['gl_error']==0,offline
            checks.append('Embedded worker regenerates an uncached 2123×4789 mm model while browser networking is offline')
            context.close()

            file_context=browser.new_context()
            file_page=file_context.new_page();file_page.set_default_timeout(120000)
            file_errors=[];file_external=[]
            file_page.on('pageerror',lambda e:file_errors.append(str(e)))
            file_page.on('request',lambda r:file_external.append(r.url) if not r.url.startswith((
                'file:','blob:','data:')) else None)
            file_evidence={'url':(ROOT/'app.html').as_uri(),'navigation_allowed':False}
            try:
                file_page.goto(file_evidence['url'])
            except PlaywrightError as error:
                file_evidence['navigation_limitation']=str(error)
            else:
                file_page.wait_for_function('window.ROOF_PANEL_TEST')
                file_context.set_offline(True)
                file_result=file_page.evaluate('''async()=>{
                  const t=ROOF_PANEL_TEST,c=await t.requestSize(2087,4793);renderer.render();
                  return {applied:!!c,width:t.sizing.widthMm,length:t.sizing.lengthMm,
                    panels:t.world.length,gl_error:t.gl.getError(),protocol:location.protocol,
                    instances:c?.instances?.length};
                }''')
                assert file_result['applied'] and file_result['width']==2087 and file_result['length']==4793,file_result
                assert file_result['panels']>0 and file_result['instances']==4 and file_result['gl_error']==0,file_result
                assert file_result['protocol']=='file:' and not file_errors and not file_external,(file_result,file_errors,file_external)
                file_evidence.update(navigation_allowed=True,result=file_result,errors=file_errors,external_requests=file_external)
                checks.append('Standalone file:// HTML loads and regenerates uncached 2087×4793 mm offline without JS, GL, or external-request errors')
            file_context.close()

            fallback_context=browser.new_context()
            fallback=fallback_context.new_page();fallback.set_default_timeout(120000)
            fallback_errors=[]
            fallback.on('pageerror',lambda e:fallback_errors.append(str(e)))
            fallback.add_init_script('''(()=>{
              const get=HTMLCanvasElement.prototype.getContext;
              HTMLCanvasElement.prototype.getContext=function(kind,...args){
                return /^(webgl|webgl2|experimental-webgl)$/.test(kind)?null:get.call(this,kind,...args);
              };
            })()''')
            fallback.goto(f'http://127.0.0.1:{PORT}/app.html')
            expect(fallback.locator('#loadText')).to_contain_text('WebGL')
            expect(fallback.locator('#loading')).to_be_visible()
            fallback_message=fallback.locator('#loadText').inner_text()
            assert not fallback_errors,fallback_errors
            checks.append('Unavailable WebGL produces visible browser guidance without an uncaught JavaScript error')
            browser.close()
        assert not errors,errors
        assert not external,external
        report={'passed':True,'checks':checks,'actual_xyz_guard_negative_controls':controls,
            'offline_worker':offline,'webgl_fallback_message':fallback_message,
            'standalone_file':file_evidence,
            'errors':errors,'external_requests':external,
            'html_sha256':html_sha256,'worker_sha256':worker_sha256,
            'actual_response_html_sha256':actual_response_html_sha256,
            'embedded_worker_sha256':embedded_worker_sha256,'build_manifest_match':True}
        (ROOT/'runtime_guard_validation_v8.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
        print(json.dumps(report,ensure_ascii=False,indent=2))
    finally:
        server.shutdown();server.server_close()


if __name__=='__main__':
    main()
