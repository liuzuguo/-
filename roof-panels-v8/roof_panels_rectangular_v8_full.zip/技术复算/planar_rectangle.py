"""Feasible orthogonal rectangle for planar points; metres, no source changes."""
import math


def feasible_rectangle(points_xy, width, length, tolerance=1e-8):
    """Return a feasible (short side, long side, long-axis angle) or None.

    Tests all angular constraint boundaries and the intervals between them.
    This includes diagonal placement; minimum-area edge-aligned boxes alone
    cannot decide whether a polygon fits a fixed-size fabrication rectangle.
    """
    points = sorted(set((float(p[0]), float(p[1])) for p in points_xy))
    if not points:
        return None
    limits = (length + tolerance, width + tolerance)
    angles = [0.0]
    for i, p in enumerate(points):
        for q in points[i + 1:]:
            dx, dy = q[0] - p[0], q[1] - p[1]
            radius = math.hypot(dx, dy)
            if radius > math.hypot(*limits) + 1e-10:
                return None
            if radius < 1e-12:
                continue
            alpha = math.atan2(dy, dx)
            # Pair directions also include every possible hull-edge direction,
            # useful for selecting a compact rectangle within feasible angles.
            angles.extend([alpha % math.pi, (alpha + math.pi / 2) % math.pi])
            for k, limit in enumerate(limits):
                if radius > limit:
                    center = alpha + (math.pi / 2 if k else 0)
                    delta = math.acos(max(-1., min(1., limit / radius)))
                    angles.extend([(center - delta) % math.pi,
                                   (center + delta) % math.pi])
    angles = sorted(set(angles))
    candidates = list(angles)
    for i, a in enumerate(angles):
        b = angles[i + 1] if i < len(angles) - 1 else angles[0] + math.pi
        candidates.append(((a + b) / 2) % math.pi)
    fits = []
    for angle in candidates:
        c, s = math.cos(angle), math.sin(angle)
        u = [p[0] * c + p[1] * s for p in points]
        v = [-p[0] * s + p[1] * c for p in points]
        long_extent = max(u) - min(u)
        short_extent = max(v) - min(v)
        if long_extent <= limits[0] + 1e-10 and short_extent <= limits[1] + 1e-10:
            dims = sorted((short_extent, long_extent))
            # If the nominal width axis happens to be the longer actual side,
            # rotate the returned axis while keeping dimensions ordered.
            axis = angle if long_extent >= short_extent else (angle + math.pi/2) % math.pi
            fits.append((dims[0], dims[1], axis))
    return min(fits, key=lambda item: (item[0] * item[1], item[0] + item[1])) if fits else None
