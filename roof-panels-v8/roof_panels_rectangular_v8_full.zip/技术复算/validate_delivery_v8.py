#!/usr/bin/env python3
"""Independently audit the frozen V8 app, actual exports, and release archives.

V8 intentionally reconstructs the roof. This audit never requires conservation
of the old fan surface, its ridges, its XYZ coverage, or its surface area. The
original model/context are retained as reference. Installed geometry must be
actual planar rectangles, except independently proven exterior-arc stock crops.
"""
from __future__ import annotations

import argparse
import base64
import csv
import gzip
import hashlib
from html.parser import HTMLParser
import io
import json
import math
from pathlib import Path, PurePosixPath
import re
import stat
import sys
import xml.etree.ElementTree as ET
import zipfile

import numpy as np
import validate_dynamic_geometry_v8 as geometry
import validate_rectangles_and_neighbors as meshes

ROOT = Path(__file__).resolve().parent
DATA_IDS = ('panelData', 'modelData', 'contextData', 'bridgeData', 'workerData')
CONTROLS = ('widthInput', 'widthSlider', 'lengthInput', 'ratioLock', 'ratioInput',
            'applySizeBtn', 'moveUp', 'moveDown', 'moveLeft', 'moveRight',
            'moveCenter', 'moveStep', 'selectionSummary', 'vRect', 'vTrim',
            'vPlanarity', 'vCurved', 'vNeighbor', 'vRidge', 'vDeviation', 'standardSize')
STANDALONE = 'roof_panels_rectangular_v8.html'
SAMPLE_JSON = '1102e_V8矩形铝板分隔.json'
SAMPLE_DAE = '1102e_V8矩形铝板分隔.dae'
SAMPLE_CSV = '1102e_V8逐板统计.csv'
RULE = geometry.RULE


def sha(value):
    return hashlib.sha256(value).hexdigest()


class Document(HTMLParser):
    def __init__(self, text):
        super().__init__(convert_charrefs=False)
        self.elements, self.payloads, self.active = {}, {}, None
        self.feed(text)
        self.close()

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        identity = attrs.get('id')
        if identity:
            self.elements.setdefault(identity, []).append(attrs)
        if tag == 'script' and identity in DATA_IDS:
            self.active = (identity, [])

    def handle_data(self, value):
        if self.active:
            self.active[1].append(value)

    def handle_endtag(self, tag):
        if tag == 'script' and self.active:
            identity, parts = self.active
            self.payloads.setdefault(identity, []).append(''.join(parts))
            self.active = None


class Audit:
    def __init__(self):
        self.checks = []

    def check(self, name, condition, detail=None):
        item = {'name': name, 'passed': bool(condition)}
        if detail is not None:
            item['detail'] = detail
        self.checks.append(item)
        return bool(condition)

    def guard(self, name, fn):
        try:
            return fn()
        except Exception as exc:
            self.check(name, False, f'{type(exc).__name__}: {exc}')
            return None


def audit_docs(audit, text, label):
    compact = re.sub(r'\s+', '', text).replace(',', '').replace('，', '')
    audit.check(label+': independent positive dimensions and optional custom ratio',
                any(x in compact for x in ('正数', '正整数', '大于0')) and
                '独立' in compact and '比例' in compact and
                any(x in compact for x in ('自定义', '2.5', '5:2')) and
                any(x in compact for x in ('可选', '默认关闭', '不勾选', '取消勾选')))
    audit.check(label+': former 1500mm input ceiling removed', bool(re.search(
        r'(?:取消|去掉|移除|不再|没有|不限).{0,50}1500|1500.{0,50}(?:取消|去掉|移除|不再|限制)', compact)))
    audit.check(label+': selected orange and same-size peers red with 1mm groups',
                '橘色' in compact and '红色' in compact and '同尺寸' in compact and
                any(x in compact for x in ('1mm', '1毫米')))
    audit.check(label+': all internal finished panels are actual flat rectangles',
                '矩形' in compact and '平直' in compact and
                any(x in compact for x in ('内板', '内部', '内矩形')) and
                any(x in compact for x in ('真实', '实际', '四个直角')))
    audit.check(label+': true exterior arc crops and stock versus finished sizes explained',
                any(x in compact for x in ('外弧', '圆弧', '弧线')) and '修边' in compact and
                any(x in compact for x in ('原规格', '矩形料', 'stock_width_m')) and
                any(x in compact for x in ('净尺寸', '成品尺寸', '实际尺寸', '成品板')))
    audit.check(label+': 10 percent similarity applies to interior rectangles separately',
                '10%' in compact and any(x in compact for x in ('相邻内', '内部邻', '标准邻', '相邻标准')) and
                any(x in compact for x in ('另计', '单独', '另列', '不作为', '不受')))
    audit.check(label+': approved reconstruction changes original fan ridges and area',
                any(x in compact for x in ('批准', '授权')) and '重构' in compact and
                any(x in compact for x in ('放射', '扇形')) and
                any(x in compact for x in ('替代', '改为', '取代', '不保留', '替换')) and
                '面积' in compact and any(x in compact for x in ('变化', '改变', '不相等', '不作为')))
    audit.check(label+': shared seams and world-coordinate placement explained',
                any(x in compact for x in ('对缝', '分缝对齐', '共用的分缝', '共享分缝')) and
                any(x in compact for x in ('世界坐标', '原坐标')) and
                any(x in compact for x in ('四个完整', '四组完整', '四个重构')))
    audit.check(label+': resource limit and untested SketchUp runtime disclosed',
                any(x in compact for x in ('50万', '500000', '板数过多', '资源保护')) and
                'SketchUp' in compact and any(x in compact for x in ('未安装', '未在SketchUp', '未实机')))


def audit_app(audit, content, refs):
    text = content.decode('utf-8')
    doc = Document(text)
    label = 'built app'
    audit.check(label+': complete single offline HTML', '<!doctype html>' in text.lower() and '</html>' in text.lower()
                and not re.search(r'<script\b[^>]*\bsrc\s*=|<link\b[^>]*\bhref\s*=\s*[\"\']https?://', text, re.I))
    audit.check(label+': no unresolved development placeholders', '<!-- EMBED_DATA -->' not in text
                and not re.search(r'/\*\s*RENDERER_V\d+\s*\*/', text))
    audit.check(label+': final manifest HTML and worker hashes', sha(content) == refs['manifest'].get('html_sha256')
                and sha(refs['worker']) == refs['manifest'].get('worker_sha256'))
    audit.check(label+': each required control present once', all(len(doc.elements.get(x, [])) == 1 for x in CONTROLS))
    for name, value in (('widthInput', '1000'), ('lengthInput', '3000')):
        attrs = doc.elements.get(name, [{}])[0]
        audit.check(label+': independent positive uncapped '+name,
                    attrs.get('type') == 'number' and attrs.get('min') == '1' and 'max' not in attrs
                    and attrs.get('step') == '1' and attrs.get('value') == value, attrs)
    audit.check(label+': optional ratio defaults to free sizing', 'checked' not in doc.elements.get('ratioLock', [{}])[0]
                and 'disabled' in doc.elements.get('ratioInput', [{}])[0]
                and 'ratioLocked:false,ratio:null' in text and 'function parseRatio(' in text)
    audit.check(label+': auxiliary width slider expands with typed width', 'function syncWidthSlider(w)' in text
                and 'Math.ceil(w/1000)*2000' in text and doc.elements.get('widthSlider', [{}])[0].get('max') != '1500')
    audit.check(label+': same-size grouping uses actual finished dimensions to 1mm',
                "function panelSizeKey(p){return mm(p.width_m)+' × '+mm(p.length_m)}" in text
                and 'function selectionStats()' in text and '其他同尺寸' in text and '同尺寸总数（含选中）' in text)
    audit.check(label+': exact frozen V8 renderer with orange/red selection', refs['renderer'].decode() in text
                and 'C = vec3(.91, .16, .14)' in text and 'C = vec3(1., .53, .12)' in text)
    audit.check(label+': reconstructs using approved data and four candidate instances',
                'model:{reconstruction:DATA.layout.reconstruction}' in text
                and 'instances=candidate.instances||original.instances' in text)
    audit.check(label+': export explicitly declares V8 reconstructed rectangles and arc exceptions',
                "panel_study_version:'v8-rectangular-rebuilt'" in text
                and "panels:'planar_rectangles'" in text and "source_geometry:'reconstructed_with_user_approval'" in text
                and 'is_rectangle:!!p.is_rectangle' in text and 'is_exterior_arc_trim:!!p.is_exterior_arc_trim' in text
                and 'stock_width_m:p.stock_width_m' in text and 'arc_edge_ids:p.arc_edge_ids' in text)
    audit.check(label+': disclosure distinguishes rebuilt geometry from original fan surface',
                '重构' in text and '原放射褶皱改为直线平行折面' in text and '新分隔与原屋面重合' not in text
                and '与原屋面面积变化' in text and '原屋面高度最大变化' in text)
    audit.check(label+': new project format retains legacy parameter loading', "format:'roof-panel-project-8'" in text
                and "['roof-panel-project-8','roof-panel-project-7','roof-panel-project-6','roof-panel-project-5'].includes(p.format)" in text)
    audit.check(label+': DAE uses nine-decimal world coordinates', 'x.toFixed(9)' in text)
    audit.check(label+': five embedded payload elements appear exactly once',
                all(len(doc.payloads.get(x, [])) == 1 for x in DATA_IDS))
    decoded = {}
    for name in DATA_IDS:
        values = doc.payloads.get(name, [])
        if len(values) != 1:
            continue
        raw = base64.b64decode(re.sub(r'\s+', '', values[0]), validate=True)
        if name in ('panelData', 'modelData', 'contextData'):
            raw = gzip.decompress(raw)
        audit.check(label+': valid nonempty '+name, bool(raw), {'bytes': len(raw), 'sha256': sha(raw)})
        decoded[name] = json.loads(raw) if name in ('panelData', 'modelData') else raw
    audit.check(label+': original source mesh and all eight reference transforms preserved',
                decoded.get('modelData') == refs['embedded_model'] and len(refs['model'].get('instances', [])) == 8)
    audit.check(label+': original context payload unchanged', decoded.get('contextData') == refs['context'])
    audit.check(label+': worker and bridge payloads match frozen source exactly',
                decoded.get('workerData') == refs['worker'] and decoded.get('bridgeData') == refs['bridge'])
    data = decoded.get('panelData', {})
    selected = geometry.selected_candidate(data)
    audit.check(label+': default geometry is identical to generated worker result',
                data.get('candidates') == refs['default'].get('candidates')
                and data.get('validation_generation', {}).get('worker_sha256') == sha(refs['worker']))
    audit.check(label+': approved reconstruction payload exact identity',
                data.get('layout', {}).get('reconstruction') == refs['reconstruction'])
    audit.check(label+': default exact V8 rule and independent 1000x3000 dimensions',
                data.get('geometry_rule') == RULE and data.get('panel_study_version') == 'v8-rectangular-rebuilt'
                and selected.get('nominal_width_m') == 1 and selected.get('nominal_length_m') == 3
                and data.get('sizing_rule', {}).get('mode') == 'free'
                and data['sizing_rule'].get('ratio_locked') is False
                and data['sizing_rule'].get('min_width_mm') == 1 and data['sizing_rule'].get('max_width_mm') == 1e9)
    audit.check(label+': four full-roof output transforms separate from eight reference halves',
                selected.get('instances') == refs['reconstruction']['instances'] and len(selected.get('instances', [])) == 4
                and {x.get('roof_id') for x in selected['instances']} == set('ABCD'))
    result = geometry.validate(data, refs['reconstruction'])
    audit.check(label+': independently verified actual default meshes, coverage, folds and neighbors', result['all_passed'],
                {k: result[k] for k in ('full_actual_panel_count', 'full_true_rectangle_count',
                    'full_verified_exterior_arc_crop_count', 'max_actual_plane_error_m',
                    'interior_neighbor_max_relative_difference', 'exterior_arc_crop_neighbor_max_actual_size_ratio')})
    audit.check(label+': nonzero roof change is reported without original-area conservation claim',
                result['approved_reconstruction_source_change'].get('verified') is True
                and result['approved_reconstruction_source_change'].get('original_source_surface_is_coverage_target') is False
                and result['approved_reconstruction_source_change'].get('source_vertex_max_vertical_change_m', 0) > 1
                and selected.get('summary', {}).get('source_geometry_preserved') is False,
                result['approved_reconstruction_source_change'])
    return result


def audit_exterior_provenance(audit, data, refs, local_groups):
    """Check dense world arc declarations against the independent design outline."""
    reconstruction = refs['reconstruction']
    outline = np.asarray(reconstruction['outline'], dtype=float)[:, :2]
    approved_arcs = set(reconstruction['arc_edge_indices'])
    reference = geometry.make_reference(reconstruction)
    transforms = {x['roof_id']: np.asarray(x['matrix']).reshape(4, 4).T for x in reconstruction['instances']}
    roofs = data.get('roofs', [])
    audit.check('actual export: exactly four declared complete world exteriors', len(roofs) == 4
                and {r.get('roof_id') for r in roofs} == set('ABCD'))
    for roof in roofs:
        identity = roof['roof_id']
        label = 'actual '+identity+' dense exterior'
        matrix = transforms[identity]
        points = (np.asarray(roof['exterior'])-matrix[:3, 3]) @ np.linalg.inv(matrix[:3, :3]).T
        indices = roof.get('source_outline_edge_indices', roof.get('exterior_source_edge_ids', []))
        arcs = roof.get('arc_edge_indices', [])
        assert len(points) >= len(outline) and len(indices) == len(points), 'missing dense-to-approved exterior mapping'
        assert len(set(arcs)) == len(arcs) and all(type(i) is int and 0 <= i < len(points) for i in arcs), 'invalid dense arc indices'
        actual_domain = meshes.Polygon(points[:, :2])
        assert actual_domain.is_valid and not actual_domain.interiors, 'dense exterior is invalid'
        assert actual_domain.symmetric_difference(reference['domain']).area <= 1e-7, 'dense exterior changed the approved footprint'
        arcset = set(arcs)
        for i, source_index in enumerate(indices):
            assert type(source_index) is int and 0 <= source_index < len(outline), 'invalid source exterior index'
            line = meshes.LineString([points[i, :2], points[(i+1) % len(points), :2]])
            source = meshes.LineString([outline[source_index], outline[(source_index+1) % len(outline)]])
            assert line.difference(source.buffer(1e-7)).length <= 1e-7, 'dense edge is not on its independent source edge'
            assert (i in arcset) == (source_index in approved_arcs), 'straight exterior edge mislabeled arc or arc provenance omitted'
        # Collect actual outer mesh edges, including all row cuts and fold points.
        edges = []
        for panel in local_groups[identity]:
            ring = panel['ring_xyz']
            for a, b in zip(ring, np.roll(ring, -1, axis=0)):
                if meshes.LineString([a[:2], b[:2]]).difference(reference['domain'].boundary.buffer(1e-7)).length <= 1e-7:
                    edges.append((a, b))
        edge_points = np.asarray(edges)
        assert len(edges), 'no independently recovered outer mesh edges'
        for i, a in enumerate(points):
            b = points[(i+1) % len(points)]
            direction = b-a
            length = np.linalg.norm(direction)
            assert length > 1e-9, 'zero-length dense exterior edge'
            direction /= length
            distances = np.linalg.norm(np.cross(edge_points-a, direction), axis=2)
            matching = edge_points[np.max(distances, axis=1) <= 2e-7]
            line = meshes.LineString([a[:2], b[:2]])
            assert len(matching), 'dense exterior spans a fold without a genuine straight 3D boundary edge'
            coverage = meshes.unary_union([meshes.LineString([v[0, :2], v[1, :2]]) for v in matching])
            assert line.difference(coverage.buffer(2e-7)).length <= 2e-7, 'dense 3D exterior is not covered by actual outer panel edges'
        for raw, panel in zip((p for p in data['panels'] if p['roof_id'] == identity), local_groups[identity]):
            if panel['is_rectangle']:
                continue
            declared = raw.get('arc_edge_ids', [])
            assert declared and all(type(i) is int and i in arcset for i in declared), 'trim names a non-arc exterior edge'
            for i in declared:
                a, b = points[i], points[(i+1) % len(points)]
                assert max(abs((a-panel['origin']) @ panel['normal']),
                           abs((b-panel['origin']) @ panel['normal'])) <= 2e-7, 'named arc edge lies on a different 3D strip plane'
        audit.check(label+': complete footprint, dense 3D edge coverage, independently traced arc provenance', True,
                    {'dense_edge_count': len(points), 'dense_arc_edge_count': len(arcs),
                     'independent_outline_edge_count': len(outline), 'independent_arc_edge_count': len(approved_arcs)})


def audit_actual_export(audit, data, refs):
    """Undo each approved rigid placement, then inspect every installed mesh."""
    label = 'actual browser export'
    panels = data['panels']
    audit.check(label+': explicit V8 rule, free 2500x6000 input and directional limits',
                data.get('panel_study_version') == 'v8-rectangular-rebuilt' and data.get('geometry_rule') == RULE
                and data.get('nominal_width_m') == 2.5 and data.get('nominal_length_m') == 6
                and data.get('max_width_m') == 2.5 and data.get('max_length_m') == 6
                and data.get('sizing_rule', {}).get('mode') == 'free'
                and data['sizing_rule'].get('ratio') is None and data['sizing_rule'].get('min_width_mm') == 1
                and data['sizing_rule'].get('max_width_mm') == 1e9)
    audit.check(label+': unique world panel IDs in exactly four complete roof scopes', bool(panels)
                and len({p.get('id') for p in panels}) == len(panels)
                and {p.get('roof_id') for p in panels} == set('ABCD'))
    reference = geometry.make_reference(refs['reconstruction'])
    instances = {x['roof_id']: x for x in refs['reconstruction']['instances']}
    local_groups = {x: [] for x in instances}
    shape_errors, dimension_errors, stock_errors = [], [], []
    max_plane = max_dimension = max_area = 0.
    rectangles = trims = 0
    for raw in panels:
        try:
            roof = raw['roof_id']
            transform = np.asarray(instances[roof]['matrix'], dtype=float).reshape(4, 4).T
            xyz = np.asarray(raw['vertices'], dtype=float)
            local = (xyz-transform[:3, 3]) @ np.linalg.inv(transform[:3, :3]).T
            faces = raw['faces']
            if np.linalg.det(transform[:3, :3]) < 0:
                faces = [list(reversed(f)) for f in faces]
            p = meshes.actual_panel(dict(raw, vertices=local.tolist(), faces=faces), 1e-7, 1e-7)
            max_plane = max(max_plane, p['plane_error_m'])
            assert raw.get('kind') == 'planar' and raw.get('needs_bend') is False, 'flat metadata mismatch'
            if p['is_rectangle']:
                assert raw.get('is_rectangle') is True and raw.get('layout_shape') == 'planar_rectangle', 'actual rectangle classification mismatch'
                rectangles += 1
            else:
                assert raw.get('is_rectangle') is False and raw.get('is_exterior_arc_trim') is True, 'nonrectangle is not declared exterior crop'
                assert raw.get('layout_shape') == 'outer_arc_trim' and raw.get('arc_edge_ids'), 'missing exterior arc provenance'
                meshes.verify_exterior_arc_crop(p, reference, 1e-7, 1e-7, 1e-7)
                trims += 1
            sizes = geometry.directional_sizes(p)
            assert sizes[0] <= 2.5+1e-7 and sizes[1] <= 6+1e-7, 'actual directional size exceeds selected input'
            actual = sorted(sizes)
            delta = max(abs(actual[0]-raw['width_m']), abs(actual[1]-raw['length_m']))
            max_dimension = max(max_dimension, delta)
            if delta > 1e-7:
                dimension_errors.append({'id': raw['id'], 'actual_sorted_m': actual, 'reported_m': [raw['width_m'], raw['length_m']]})
            stock = [raw.get('stock_width_m'), raw.get('stock_length_m')]
            if (any(not isinstance(x, (int, float)) or not math.isfinite(x) or x <= 0 for x in stock)
                    or stock[0]+1e-7 < actual[0] or stock[1]+1e-7 < actual[1]):
                stock_errors.append(raw['id'])
            max_area = max(max_area, abs(float(p['polygon'].area)-raw['area_m2']))
            p['directional_actual_sizes_m'] = sizes
            local_groups[roof].append(p)
        except (ValueError, KeyError, TypeError, IndexError, AssertionError) as exc:
            shape_errors.append({'id': raw.get('id'), 'error': str(exc)})
    audit.check(label+': every actual mesh planar and rectangular or independently proven exterior crop',
                not shape_errors and rectangles+trims == len(panels),
                {'rectangles': rectangles, 'verified_arc_crops': trims, 'max_plane_error_mm': max_plane*1000,
                 'failures': shape_errors[:20]})
    audit.check(label+': finished dimensions and areas measured from actual shape',
                not dimension_errors and max_area <= 1e-7,
                {'max_dimension_error_m': max_dimension, 'max_area_error_m2': max_area, 'failures': dimension_errors[:20]})
    audit.check(label+': stock fields are explicit and distinct from finished dimensions', not stock_errors,
                {'invalid_panels': stock_errors[:20]})
    coverage, neighbor_max, crop_max = [], 1., 1.
    for roof, group in local_groups.items():
        r = geometry.coverage_report(group, reference)
        coverage.append(dict(r, roof_id=roof))
        for (i, j), shared in meshes.actual_neighbours(group, 1e-7, 1e-7).items():
            a, b = group[i], group[j]
            da, db = a['directional_actual_sizes_m'], b['directional_actual_sizes_m']
            ratio = max(max(x/y, y/x) for x, y in zip(da, db))
            if a['is_rectangle'] and b['is_rectangle']:
                neighbor_max = max(neighbor_max, ratio)
            else:
                crop_max = max(crop_max, ratio)
    audit.check(label+': each complete NEW roof covered with no holes or overlaps', all(x['passed'] for x in coverage), coverage)
    audit.check(label+': actual interior shared-edge neighbors within 10 percent', neighbor_max <= 1.1+1e-7,
                {'interior_max_actual_size_ratio': neighbor_max, 'arc_crop_max_actual_size_ratio_separate': crop_max,
                 'arc_crops_subject_to_10_percent_bound': False})
    audit.check(label+': four rigid instances contain equal complete panel counts',
                len({len(g) for g in local_groups.values()}) == 1)
    canonical = {p['id'].split('-', 1)[-1]: p for p in local_groups['A']}
    copy_error = 0.
    for roof, group in local_groups.items():
        for p in group:
            other = canonical[p['id'].split('-', 1)[-1]]
            assert p['vertices'].shape == other['vertices'].shape, 'rigid copy mesh vertex counts differ'
            copy_error = max(copy_error, float(np.max(np.abs(p['vertices']-other['vertices']))))
    audit.check(label+': four installed full roofs are actual rigid copies of complete template', copy_error <= 1e-7,
                {'max_inverse_transformed_coordinate_difference_m': copy_error})
    audit_exterior_provenance(audit, data, refs, local_groups)
    return {'panels': len(panels), 'rectangles': rectangles, 'arc_crops': trims,
            'interior_max_actual_size_ratio': neighbor_max, 'arc_crop_max_actual_size_ratio': crop_max,
            'max_actual_plane_error_m': max_plane}


def audit_serialized_exports(audit, refs):
    data = json.loads((ROOT/SAMPLE_JSON).read_text())
    result = audit_actual_export(audit, data, refs)
    rows = list(csv.reader(io.StringIO((ROOT/SAMPLE_CSV).read_text(encoding='utf-8-sig'))))
    audit.check('CSV: one row per actual panel with stock and finished dimensions',
                len(rows)-1 == len(data['panels']) and {'原规格宽mm', '原规格长mm'}.issubset(rows[0]))
    namespace = {'c': 'http://www.collada.org/2005/11/COLLADASchema'}
    tree = ET.fromstring((ROOT/SAMPLE_DAE).read_bytes())
    nodes = tree.findall('.//c:library_geometries/c:geometry', namespace)
    audit.check('DAE: one actual geometry per exported panel', len(nodes) == len(data['panels']))
    max_error, max_plane = 0., 0.
    for node, panel in zip(nodes, data['panels']):
        values = [float(x) for x in node.find('.//c:float_array', namespace).text.split()]
        indices = [int(x) for x in node.find('.//c:triangles/c:p', namespace).text.split()]
        vertices = [values[i:i+3] for i in range(0, len(values), 3)]
        faces = [indices[i:i+3] for i in range(0, len(indices), 3)]
        if len(vertices) != len(panel['vertices']):
            raise ValueError('DAE/JSON vertex counts differ')
        max_error = max(max_error, max(abs(a-b) for x, y in zip(vertices, panel['vertices']) for a, b in zip(x, y)))
        p = meshes.actual_panel(dict(panel, vertices=vertices, faces=faces), 1e-7, 1e-7)
        max_plane = max(max_plane, p['plane_error_m'])
    audit.check('DAE: actual world coordinates retain nine decimals and remain planar',
                max_error <= 5.001e-10 and max_plane <= 1e-7,
                {'max_coordinate_error_m': max_error, 'max_actual_plane_error_m': max_plane})
    return result


def safe_member(info):
    name, path = info.filename, PurePosixPath(info.filename)
    return bool(name) and not path.is_absolute() and '..' not in path.parts and '\\' not in name \
        and not re.match(r'^[A-Za-z]:', name) and not stat.S_ISLNK(info.external_attr >> 16)


def audit_zip(audit, path, refs):
    label = path.name
    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        audit.check(label+': safe relative members, no symlinks or duplicate names, valid CRC',
                    all(safe_member(x) for x in z.infolist()) and len(names) == len(set(names)) and z.testzip() is None)
        audit.check(label+': exactly one runnable root app.html', [x for x in names if x.lower().endswith('.html')] == ['app.html'])
        audit.check(label+': exact frozen app identity', 'app.html' in names and z.read('app.html') == refs['app'])
        guides = [x for x in names if PurePosixPath(x).name in ('使用说明.md', '打开说明.txt', 'SKETCHUP使用说明.md')]
        audit.check(label+': user guides and actual frozen bridge present', bool(guides)
                    and 'sketchup_bridge.rb' in names and z.read('sketchup_bridge.rb') == refs['bridge'])
        audit_docs(audit, '\n'.join(z.read(x).decode('utf-8-sig') for x in guides), label+' docs')
        for name in names:
            base = PurePosixPath(name).name
            relative = PurePosixPath(name)
            local = ROOT.joinpath(*relative.parts[1:]) if relative.parts[0] == '技术复算' else ROOT/base
            if local.is_file() and base not in ('使用说明.md', '打开说明.txt'):
                audit.check(label+': packaged source/report identity '+name, z.read(name) == local.read_bytes())
        if path.name.endswith('_full.zip'):
            required = ('app.template.html.txt', 'renderer-v8.js', 'panel-worker.js', 'reconstructionData.json',
                        'modelData.json', 'context_lite.bin.gz', 'default-study.json', 'build_manifest.json',
                        'dynamic_geometry_validation.json', 'browser_validation_v8.json', 'bridge_numeric_validation.json',
                        'validate_delivery_v8.py', 'validate_dynamic_geometry_v8.py',
                        SAMPLE_JSON, SAMPLE_DAE, SAMPLE_CSV)
            bases = [PurePosixPath(x).name for x in names]
            audit.check(label+': required actual sample, reproducible source, independent reports included once',
                        all(bases.count(x) == 1 for x in required), {'missing_or_duplicate': [x for x in required if bases.count(x) != 1]})
    return {'file': path.name, 'bytes': path.stat().st_size, 'sha256': sha(path.read_bytes()), 'entries': len(names)}


def audit_reports(audit, refs):
    reports = {name: json.loads((ROOT/file).read_text()) for name, file in (
        ('geometry', 'dynamic_geometry_validation.json'), ('browser', 'browser_validation_v8.json'),
        ('bridge', 'bridge_numeric_validation.json'), ('runtime', 'runtime_guard_validation_v8.json'))}
    worker_hash, html_hash = sha(refs['worker']), sha(refs['app'])
    for name, report in reports.items():
        audit.check(name+' report: final frozen worker identity', report.get('worker_sha256') == worker_hash)
        audit.check(name+' report: final frozen HTML identity', report.get('html_sha256') == html_hash)
    geo = reports['geometry']
    audit.check('independent geometry aggregate passed against approved reconstruction', geo.get('all_passed') is True
                and geo.get('independent_reconstruction_sha256') == sha((ROOT/'reconstructionData.json').read_bytes()))
    audit.check('independent geometry report binds both actual verifier source files',
                geo.get('validator_sha256') == sha((ROOT/'validate_dynamic_geometry_v8.py').read_bytes())
                and geo.get('independent_mesh_primitives_sha256') == sha((ROOT/'validate_rectangles_and_neighbors.py').read_bytes()))
    cases = geo.get('cases', [])
    audit.check('independent geometry cases include true rectangles, verified arc crops, coverage, folds and neighbors', bool(cases)
                and all(c.get('all_passed', c.get('passed')) is True for c in cases))
    for case in cases:
        for key in ('input', 'report'):
            path = PurePosixPath(case.get(key+'_path', ''))
            safe = bool(path.parts) and not path.is_absolute() and '..' not in path.parts and '\\' not in str(path)
            audit.check(case.get('case', 'case')+': safe '+key+' provenance path', safe)
            if safe:
                raw = ROOT.joinpath(*path.parts).read_bytes()
                audit.check(case.get('case', 'case')+': exact '+key+' report identity', sha(raw) == case.get(key+'_sha256'))
                if key == 'report':
                    detailed = json.loads(raw)
                    audit.check(case.get('case', 'case')+': detailed actual meshes, seams and complete reconstructed coverage passed',
                                detailed.get('all_passed') is True
                                and detailed.get('interior_neighbor_max_actual_size_ratio', 2) <= 1.1+1e-7
                                and detailed.get('reconstructed_fold_alignment_passed') is True
                                and detailed.get('complete_coverage_passed') is True
                                and len(detailed.get('actual_world_instances', [])) == 4)
    negative = geo.get('negative_control_checks', geo.get('negative_controls', {}).get('checks', []))
    audit.check('adversarial geometry controls reject false rectangles, warped plates, fake arc cuts and mismatched folds',
                len(negative) >= 4 and all(c.get('passed') is True for c in negative), negative)
    browser = reports['browser']
    audit.check('actual browser passed without external requests or JavaScript errors',
                browser.get('passed', 0) > 0 and not browser.get('errors') and not browser.get('external_requests')
                and browser.get('sample_width_mm') == 2500 and browser.get('sample_length_mm') == 6000
                and browser.get('sample_panels') == len(json.loads((ROOT/SAMPLE_JSON).read_text())['panels']))
    evidence = browser.get('gpu_pixel_evidence', [])
    audit.check('actual browser GPU evidence confirms selected orange, peers red and positive exact quantities',
                bool(evidence) and all(len(x.get('colors', [])) >= 2 and x.get('stats', {}).get('count', 0) > 1
                and x['stats'].get('others') == x['stats']['count']-1
                and x['colors'][0]['pixel'][0] > x['colors'][0]['pixel'][1] > x['colors'][0]['pixel'][2]
                and all(c['pixel'][0] > c['pixel'][1]*3 for c in x['colors'][1:]) for x in evidence))
    bridge = reports['bridge']
    audit.check('bridge numerical and syntax checks passed on actual exported sample and final Ruby',
                bridge.get('all_passed') is True and bridge.get('export_sha256') == sha((ROOT/SAMPLE_JSON).read_bytes())
                and bridge.get('bridge_sha256') == sha(refs['bridge'])
                and bridge.get('syntax_validation', {}).get('all_passed') is True)
    audit.check('bridge report accurately discloses its numerical mirror and absent SketchUp execution',
                'mirror' in bridge.get('method', '').lower() and 'no Ruby or SketchUp runtime' in bridge.get('method', ''))
    runtime = reports['runtime']
    audit.check('actual browser offline and runtime geometry guards passed', runtime.get('passed') is True
                and not runtime.get('errors') and not runtime.get('external_requests')
                and bool(runtime.get('actual_xyz_guard_negative_controls')) and bool(runtime.get('standalone_file')))
    guard = geo.get('resource_guard_controls', {})
    guard_raw = (ROOT/'validation_reports/resource_guard_v8.json').read_bytes()
    guard_report = json.loads(guard_raw)
    audit.check('actual worker resource guards passed with exact final-worker report', guard.get('all_passed') is True
                and guard.get('report_sha256') == sha(guard_raw) and guard_report.get('all_passed') is True
                and guard_report.get('worker_sha256') == worker_hash and len(guard_report.get('checks', [])) >= 10)
    return reports


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--app-only', action='store_true')
    parser.add_argument('--output', type=Path, default=ROOT/'delivery_validation_v8.json')
    args = parser.parse_args()
    audit = Audit()
    refs = {name: (ROOT/file).read_bytes() for name, file in (('app', 'app.html'), ('worker', 'panel-worker.js'),
        ('renderer', 'renderer-v8.js'), ('bridge', 'sketchup_bridge.rb'))}
    refs.update({name: json.loads((ROOT/file).read_text()) for name, file in (('manifest', 'build_manifest.json'),
        ('model', 'modelData.json'), ('default', 'default-study.json'), ('reconstruction', 'reconstructionData.json'))})
    refs['embedded_model'] = dict(refs['model'], variants={'0': refs['model']['variants']['0']})
    refs['context'] = gzip.decompress((ROOT/'context_lite.bin.gz').read_bytes())
    for name in ('modelData.json', 'context_lite.bin.gz', 'source_uv_complete.json'):
        audit.check('original reference unchanged from preserved V7: '+name,
                    (ROOT/name).read_bytes() == (ROOT.parent/'roof-panel-studio-v7'/name).read_bytes())
    audit.check('approved reconstruction records original-source identity separately',
                refs['reconstruction'].get('user_approved_reconstruction') is True
                and refs['reconstruction'].get('original_source_sha256') == sha((ROOT/'modelData.json').read_bytes()))
    for name in (STANDALONE, '1102e_V8矩形重构工作台.html'):
        audit.check('built standalone alias identity: '+name, (ROOT/name).read_bytes() == refs['app'])
    default_geometry = audit.guard('built app audit', lambda: audit_app(audit, refs['app'], refs))
    archives, actual_export = [], None
    if not args.app_only:
        actual_export = audit.guard('actual JSON/CSV/DAE export audit', lambda: audit_serialized_exports(audit, refs))
        audit.guard('independent reports audit', lambda: audit_reports(audit, refs))
        release = ROOT/'releases'
        audit.check('released standalone identity', (release/STANDALONE).read_bytes() == refs['app'])
        checksums = json.loads((release/'checksums.json').read_text())
        names = [item['file'] for item in checksums]
        audit.check('release manifest unique and complete', len(names) == len(set(names))
                    and set(names) == {p.name for p in release.iterdir() if p.is_file() and p.name != 'checksums.json'})
        for item in checksums:
            name = item['file']
            safe = PurePosixPath(name).name == name and '\\' not in name
            audit.check('release manifest safe filename '+name, safe)
            if safe:
                raw = (release/name).read_bytes()
                audit.check('release SHA/size '+name, len(raw) == item['bytes'] and sha(raw) == item['sha256'])
        for kind in ('web', 'full'):
            path = release/f'roof_panels_rectangular_v8_{kind}.zip'
            result = audit.guard('archive '+path.name, lambda path=path: audit_zip(audit, path, refs))
            if result:
                archives.append(result)
    report = {'format': 'roof-panel-v8-delivery-validation-1',
              'all_passed': bool(audit.checks) and all(x['passed'] for x in audit.checks),
              'app_only': args.app_only, 'worker_sha256': sha(refs['worker']), 'html_sha256': sha(refs['app']),
              'independent_reconstruction_sha256': sha((ROOT/'reconstructionData.json').read_bytes()),
              'actual_export': actual_export, 'archives': archives, 'checks': audit.checks,
              'geometry_scope': 'Approved reconstructed roof; original fan ridges, surface shape and area intentionally changed. Original model/context retained as reference only. Interior actual rectangles satisfy 10 percent neighbor similarity; actual exterior arc crops are reported separately.'}
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n')
    failed = [x for x in audit.checks if not x['passed']]
    print(json.dumps({'all_passed': report['all_passed'], 'checks': len(audit.checks), 'failed': failed,
                      'report': str(args.output)}, ensure_ascii=False))
    return 0 if report['all_passed'] else 1


if __name__ == '__main__':
    sys.exit(main())
