"""Actual offline V8 browser controls, GPU pixels and serialized geometry."""
from pathlib import Path
from functools import partial
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
import threading
import json, csv, io, math, hashlib, base64
import xml.etree.ElementTree as ET
from playwright.sync_api import sync_playwright, expect

ROOT = Path(__file__).resolve().parent
PORT = 8054


class QuietHandler(SimpleHTTPRequestHandler):
    def log_message(self, *args):
        pass


PICK_VISIBLE = r"""() => {
  const t=ROOF_PANEL_TEST, gl=t.gl, c=document.getElementById('model');
  renderer.render(true);
  const pixels=new Uint8Array(c.width*c.height*4);
  gl.readPixels(0,0,c.width,c.height,gl.RGBA,gl.UNSIGNED_BYTE,pixels);
  const region=new Map();
  const idAt=(x,y)=>{let i=(y*c.width+x)*4;return pixels[i]+256*pixels[i+1]+65536*pixels[i+2]-1};
  for(let y=3;y<c.height-3;y++)for(let x=3;x<c.width-3;x++){
    let index=idAt(x,y);if(index<0||index>=t.world.length)continue;
    let item=region.get(index);if(!item){item={index,count:0,score:-1};region.set(index,item)}
    item.count++;
    let score=0;for(let yy=-2;yy<=2;yy++)for(let xx=-2;xx<=2;xx++)if(idAt(x+xx,y+yy)===index)score++;
    if(score>item.score){item.score=score;item.x=x;item.y=y}
  }
  const groups=new Map();
  for(const item of region.values()){
    if(item.score<9)continue;
    let key=t.panelSizeKey(t.world[item.index]);if(!groups.has(key))groups.set(key,[]);
    groups.get(key).push(item);
  }
  const choices=Array.from(groups,([key,items])=>({key,items:items.sort((a,b)=>b.score-a.score||b.count-a.count),types:new Set(items.map(p=>t.world[p.index].type_id)).size})).filter(g=>g.items.length>=3).sort((a,b)=>b.types-a.types||b.items.length-a.items.length);
  if(!choices.length)throw Error('No group has 3 visible interior plate pixels');
  const result=choices[0], r=c.getBoundingClientRect();
  for(const item of result.items){item.clientX=r.left+(item.x+.5)/c.width*r.width;item.clientY=r.bottom-(item.y+.5)/c.height*r.height}
  renderer.render();return result;
}"""

READ_COLORS = r"""items => {
  renderer.render();const gl=ROOF_PANEL_TEST.gl;
  return items.map(item=>{let p=new Uint8Array(4);gl.readPixels(item.x,item.y,1,1,gl.RGBA,gl.UNSIGNED_BYTE,p);return {index:item.index,pixel:Array.from(p)}})
}"""

NEIGHBOR_METRICS = r"""() => {
  const panels=ROOF_PANEL_TEST.candidate.panels.filter(p=>p.is_rectangle),
    byGrid=new Map(panels.map(p=>[p.grid.join(','),p]));
  let pairs=0,maxWidth=0,maxLength=0;
  for(const p of panels)for(const d of [[1,0],[0,1]]){
    const q=byGrid.get([p.grid[0]+d[0],p.grid[1]+d[1]].join(','));if(!q)continue;
    pairs++;maxWidth=Math.max(maxWidth,Math.abs(p.width_m-q.width_m)/Math.min(p.width_m,q.width_m));
    maxLength=Math.max(maxLength,Math.abs(p.length_m-q.length_m)/Math.min(p.length_m,q.length_m));
  }
  return {pairs,max_width_relative_difference:maxWidth,max_length_relative_difference:maxLength};
}"""


def flat_error(points, faces):
    """Check saved coordinates against their most stable actual face plane."""
    def sub(a,b): return [a[k]-b[k] for k in range(3)]
    def cross(a,b): return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
    planes=[]
    for f in faces:
        a,b,c=(points[f[k]] for k in range(3))
        n=cross(sub(b,a),sub(c,a)); size=math.sqrt(sum(v*v for v in n))
        assert size>0, 'Serialized export contains a zero-area face'
        planes.append((size,a,n))
    size,origin,normal=max(planes,key=lambda p:p[0])
    return max(abs(sum(normal[k]*(p[k]-origin[k]) for k in range(3)))/size for p in points)


def check_flat_panels(panels):
    errors=[]; right_errors=[]; dimensions=[]; trim_dimensions=[]
    for p in panels:
        assert p['kind']=='planar' and not p['needs_bend']
        error=flat_error(p['vertices'],p['faces'])
        assert error<=1e-7,(p['id'],error)
        errors.append(error)
        area=sum(math.sqrt(sum(v*v for v in cross3(sub3(p['vertices'][f[1]],p['vertices'][f[0]]),sub3(p['vertices'][f[2]],p['vertices'][f[0]]))))/2 for f in p['faces'])
        assert abs(area-p['area_m2'])<max(1e-7,area*1e-9),(p['id'],area,p['area_m2'])
        assert p['is_rectangle']==(p['layout_shape']=='planar_rectangle')
        if p['is_rectangle']:
            points=p['vertices'];assert len(points)==4,(p['id'],len(points))
            edges=[sub3(points[(k+1)%4],points[k]) for k in range(4)]
            lengths=[math.sqrt(sum(t*t for t in v)) for v in edges]
            right=max(abs(sum(edges[k][i]*edges[(k+1)%4][i] for i in range(3)))/(lengths[k]*lengths[(k+1)%4]) for k in range(4))
            assert right<1e-8,(p['id'],right)
            assert abs(lengths[0]-lengths[2])<1e-7 and abs(lengths[1]-lengths[3])<1e-7
            actual=sorted(lengths[:2]);reported=[p['width_m'],p['length_m']]
            assert max(abs(a-b) for a,b in zip(actual,reported))<1e-7,(p['id'],actual,reported)
            right_errors.append(right);dimensions.append(reported)
        else:
            assert p['layout_shape']=='outer_arc_trim' and p['is_exterior_arc_trim'] and p['arc_edge_ids'],p
            trim_dimensions.append([p['width_m'],p['length_m']])
    assert dimensions and trim_dimensions
    assert len(set(tuple(round(x,8) for x in v) for v in trim_dimensions))>1
    return {'count':len(panels),'rectangle_count':len(dimensions),'outer_arc_trim_count':len(trim_dimensions),'max_plane_error_m':max(errors),'max_right_angle_cosine_error':max(right_errors),'nonplanar_count':0,'interior_dimensions_min_m':[min(v[k] for v in dimensions) for k in range(2)],'interior_dimensions_max_m':[max(v[k] for v in dimensions) for k in range(2)],'trim_unique_actual_dimensions':len(set(tuple(round(x,8) for x in v) for v in trim_dimensions))}


def sub3(a,b):
    return [a[k]-b[k] for k in range(3)]


def cross3(a,b):
    return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]


def check_dae(path,json_panels):
    namespace='{http://www.collada.org/2005/11/COLLADASchema}'
    count=0;max_error=0.
    for event,element in ET.iterparse(path,events=('end',)):
        if element.tag!=namespace+'geometry':
            continue
        mesh=element.find(namespace+'mesh')
        values=list(map(float,mesh.find(namespace+'source').find(namespace+'float_array').text.split()))
        points=[values[k:k+3] for k in range(0,len(values),3)]
        indices=list(map(int,mesh.find(namespace+'triangles').find(namespace+'p').text.split()))
        faces=[indices[k:k+3] for k in range(0,len(indices),3)]
        error=flat_error(points,faces)
        assert error<=1e-7,(element.attrib.get('id'),error)
        reference=json_panels[count]
        assert len(points)==len(reference['vertices'])
        assert max(abs(a-b) for p,q in zip(points,reference['vertices']) for a,b in zip(p,q))<6e-10
        assert faces==reference['faces']
        max_error=max(max_error,error);count+=1;element.clear()
    return {'count':count,'max_plane_error_m':max_error,'nonplanar_count':0}


def main():
    checks=[]; errors=[]; external=[]; pixel_evidence=[]
    server=ThreadingHTTPServer(('127.0.0.1',PORT),partial(QuietHandler,directory=str(ROOT)))
    threading.Thread(target=server.serve_forever,daemon=True).start()
    def passed(message):
        checks.append(message);print('PASS:',message,flush=True)
    try:
        with sync_playwright() as p:
            browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'])
            page=browser.new_page(viewport={'width':1780,'height':1220},device_scale_factor=1)
            page.set_default_timeout(120000)
            page.on('pageerror',lambda e:errors.append(str(e)))
            page.on('request',lambda r:external.append(r.url) if not r.url.startswith(('http://127.0.0.1','blob:','data:')) else None)
            response=page.goto(f'http://127.0.0.1:{PORT}/app.html');page.wait_for_function('window.ROOF_PANEL_TEST')
            html_hash=hashlib.sha256(response.body()).hexdigest()
            embedded_worker_hash=hashlib.sha256(base64.b64decode(page.locator('#workerData').text_content().strip())).hexdigest()
            manifest=json.loads((ROOT/'build_manifest.json').read_text())
            assert embedded_worker_hash==manifest['worker_sha256']==hashlib.sha256((ROOT/'panel-worker.js').read_bytes()).hexdigest()
            assert html_hash==manifest['html_sha256']
            def wait(w,l):
                page.wait_for_function('([w,l])=>!ROOF_PANEL_TEST.computing&&Math.round(ROOF_PANEL_TEST.candidate.nominal_width_m*1000)===w&&Math.round(ROOF_PANEL_TEST.candidate.nominal_length_m*1000)===l',arg=[w,l])
            def request(w,l,options=None):
                return page.evaluate('([w,l,o])=>ROOF_PANEL_TEST.requestSize(w,l,o).then(c=>!!c)',[w,l,options or {}])
            def counts():
                return page.evaluate('({world:ROOF_PANEL_TEST.world.length,declared:ROOF_PANEL_TEST.candidate.summary.panel_count,templates:ROOF_PANEL_TEST.candidate.panels.length})')
            default=counts();assert default['world']==default['declared']==default['templates']*4
            assert page.evaluate('ROOF_PANEL_TEST.candidate.instances.length===4&&ROOF_PANEL_TEST.candidate.instances.map(x=>x.roof_id).join("")==="ABCD"&&ROOF_PANEL_TEST.candidate.summary.curved_panel_count===0&&ROOF_PANEL_TEST.candidate.panels.every(p=>p.kind==="planar"&&!p.needs_bend&&p.nonplanarity_mm<=.0001001)')
            expect(page.locator('#vCurved')).to_have_text('0 块')
            assert page.evaluate('ROOF_PANEL_TEST.candidate.summary.rectangle_panel_count>0&&ROOF_PANEL_TEST.candidate.summary.arc_trim_panel_count>0')
            assert page.evaluate('Number(document.getElementById("vRect").textContent.replace(/[^0-9]/g,""))===ROOF_PANEL_TEST.candidate.summary.rectangle_panel_count&&Number(document.getElementById("vTrim").textContent.replace(/[^0-9]/g,""))===ROOF_PANEL_TEST.candidate.summary.arc_trim_panel_count')
            assert not page.get_by_text('表面积守恒误差',exact=True).count()
            expect(page.locator('#mCheck')).to_have_text('通过')
            assert not page.locator('#ratioLock').is_checked()
            assert not page.locator('#widthInput').get_attribute('max')
            passed('default V8 loads four full roofs with true interior rectangles and outer arc trims; free width input retained')

            page.locator('#widthInput').fill('2500');page.locator('#lengthInput').fill('6000');page.locator('#applySizeBtn').click();wait(2500,6000)
            assert page.locator('#widthInput').input_value()=='2500'
            expect(page.locator('#mCheck')).to_have_text('通过')
            large_count=counts()['world'];assert large_count>0 and large_count!=default['world']
            assert float(page.locator('#widthSlider').get_attribute('max'))>=2500
            assert request(400,6000);wait(400,6000)
            assert page.locator('#widthInput').input_value()=='400'
            expect(page.locator('#mCheck')).to_have_text('通过')
            assert request(5000,3000);wait(5000,3000)
            assert page.evaluate('ROOF_PANEL_TEST.sizing.widthMm')==5000
            assert request(2500,6000);wait(2500,6000)
            passed('actual width2500,5000 and400 independently regenerate meshes without old upper or lower clamp')

            page.locator('#ratioLock').check();wait(2500,6000)
            page.locator('#ratioInput').fill('5:2');page.locator('#ratioInput').press('Enter');wait(2500,6250)
            page.locator('#lengthInput').fill('8000');page.locator('#lengthInput').press('Enter');wait(3200,8000)
            assert page.locator('#widthInput').input_value()=='3200'
            page.locator('#ratioInput').fill('4:5');page.locator('#ratioInput').press('Enter');wait(3200,2560)
            before=page.evaluate('ROOF_PANEL_TEST.candidate.id')
            page.locator('#ratioInput').fill('1:0');page.locator('#ratioInput').press('Enter');expect(page.locator('#sizeStatus')).to_contain_text('比例')
            assert page.evaluate('ROOF_PANEL_TEST.candidate.id')==before
            page.locator('#ratioLock').uncheck();wait(3200,2560)
            page.locator('#lengthInput').fill('6000');page.locator('#lengthInput').press('Enter');wait(3200,6000)
            assert page.locator('#widthInput').input_value()=='3200'
            passed('arbitrary ratio lock links bidirectionally above1500 and below1; unlocking restores independent dimensions')

            assert request(2500,6000)
            with page.expect_download() as dl:page.locator('#saveBtn').click()
            free=ROOT/'test_free_project_v8.json';dl.value.save_as(free)
            saved=json.loads(free.read_text());assert saved['format']=='roof-panel-project-8' and saved['width_mm']==2500 and not saved['ratio_locked']
            assert request(1000,3000)
            page.locator('#projectFile').set_input_files(str(free));wait(2500,6000)
            assert request(3200,8000,{'ratioLocked':True,'ratio':2.5,'ratioText':'5:2'})
            with page.expect_download() as dl:page.locator('#saveBtn').click()
            locked=ROOT/'test_ratio_project_v8.json';dl.value.save_as(locked)
            assert request(2500,6000)
            page.locator('#projectFile').set_input_files(str(locked));wait(3200,8000)
            assert page.locator('#ratioLock').is_checked() and page.locator('#ratioInput').input_value()=='5:2'
            
            old=dict(saved);old.update(format='roof-panel-project-7',width_mm=1000,length_mm=3000)
            legacy=ROOT/'test_legacy_v7_project.json';legacy.write_text(json.dumps(old))
            page.locator('#projectFile').set_input_files(str(legacy));wait(1000,3000)
            assert page.evaluate('ROOF_PANEL_TEST.candidate.summary.curved_panel_count===0&&ROOF_PANEL_TEST.candidate.summary.ridge_misalignment_count===0')
            passed('V8 free/locked projects save and restore; legacy V7 project recomputes true rectangular V8 layout')

            result=page.evaluate('async()=>{let a=ROOF_PANEL_TEST.requestSize(2500,5000);let b=ROOF_PANEL_TEST.requestSize(2500,6000);await Promise.all([a,b]);return ROOF_PANEL_TEST.sizing}')
            assert result['widthMm']==2500 and result['lengthMm']==6000
            old_id=page.evaluate('ROOF_PANEL_TEST.candidate.id')
            assert not request(0,6000);assert page.evaluate('ROOF_PANEL_TEST.candidate.id')==old_id
            assert not request(-2,6000);assert not request(2500,0)
            assert request(2500,6000,{'ratioText':'12:5'})
            passed('latest size pair wins; zero and negative dimensions retain the last valid model')

            page.locator('#roof').select_option('all');page.locator('#topBtn').click()
            page.locator('#context').uncheck();page.locator('#seams').uncheck()
            visible=page.evaluate(PICK_VISIBLE)
            primary=visible['items'][0];page.mouse.click(primary['clientX'],primary['clientY'])
            assert page.evaluate('ROOF_PANEL_TEST.selected.index')==primary['index']
            state=page.evaluate('({stats:ROOF_PANEL_TEST.selectionStats(),highlight:ROOF_PANEL_TEST.highlight,expected:ROOF_PANEL_TEST.world.filter(p=>ROOF_PANEL_TEST.panelSizeKey(p)===ROOF_PANEL_TEST.panelSizeKey(ROOF_PANEL_TEST.selected)).map(p=>p.index),types:[...new Set(ROOF_PANEL_TEST.world.filter(p=>ROOF_PANEL_TEST.panelSizeKey(p)===ROOF_PANEL_TEST.panelSizeKey(ROOF_PANEL_TEST.selected)).map(p=>p.type_id))]})')
            assert state['highlight']['matchingIndices']==state['expected']
            assert state['stats']['count']==len(state['expected']) and state['stats']['others']==len(state['expected'])-1
            assert state['types']
            assert str(state['stats']['others']) in page.locator('#selectionSummary').inner_text().replace(',','')
            colors=page.evaluate(READ_COLORS,visible['items'][:4])
            orange=colors[0]['pixel'];assert orange[0]>orange[1]*1.4 and orange[1]>orange[2]*2,colors
            for sample in colors[1:3]:
                red=sample['pixel'];assert red[0]>red[1]*3 and red[0]>red[2]*3,colors
            pixel_evidence.append({'scope':'all','visible_group':visible,'colors':colors,'stats':state['stats'],'geometry_types':state['types']})
            page.locator('#seams').check()
            page.wait_for_function('getComputedStyle(document.getElementById("toast")).display==="none"')
            page.screenshot(path=str(ROOT/'1102e_V8同尺寸联选预览.png'),full_page=True)
            passed('actual click gives orange selected planar plate plus red same-size peers; GPU pixels and exact scoped quantities agree')

            page.locator('#isolate').check()
            isolated=page.evaluate('(()=>{renderer.render(true);let gl=ROOF_PANEL_TEST.gl,c=document.getElementById("model"),a=new Uint8Array(c.width*c.height*4),found=new Set();gl.readPixels(0,0,c.width,c.height,gl.RGBA,gl.UNSIGNED_BYTE,a);for(let i=0;i<a.length;i+=4){let id=a[i]+a[i+1]*256+a[i+2]*65536-1;if(id>=0)found.add(id)}renderer.render();return {found:[...found],allowed:ROOF_PANEL_TEST.highlight.matchingIndices}})()')
            assert isolated['found'] and set(isolated['found'])<=set(isolated['allowed'])
            page.locator('#isolate').uncheck();page.locator('#clearFilter').click()
            assert page.evaluate('ROOF_PANEL_TEST.selected') is None
            expect(page.locator('#selectionSummary')).to_be_hidden()
            page.locator('#bySize').click();page.locator('#tableBody tr').first.click()
            assert page.evaluate('ROOF_PANEL_TEST.highlight.count===ROOF_PANEL_TEST.selectionStats().count')
            page.locator('#clearFilter').click()
            passed('size-group isolation hides all unmatched plates; clear and statistics-row selection update both colors and count')

            for roof in ['A','B','C','D']:
                page.locator('#roof').select_option(roof);page.locator('#singleTopBtn').click()
                group=page.evaluate(PICK_VISIBLE);point=group['items'][0];page.mouse.click(point['clientX'],point['clientY'])
                info=page.evaluate('({selected:ROOF_PANEL_TEST.selected&&ROOF_PANEL_TEST.selected.roof_id,stats:ROOF_PANEL_TEST.selectionStats(),highlight:ROOF_PANEL_TEST.highlight,expected:ROOF_PANEL_TEST.world.filter(p=>p.roof_id===document.getElementById("roof").value&&ROOF_PANEL_TEST.panelSizeKey(p)===ROOF_PANEL_TEST.panelSizeKey(ROOF_PANEL_TEST.selected)).map(p=>p.index)})')
                assert info['selected']==roof and info['highlight']['matchingIndices']==info['expected']
                assert info['stats']['count']==len(info['expected']) and info['stats']['total']>=info['stats']['count']
                page.locator('#clearFilter').click()
            passed('single-roof A, B, C and D picking and same-size quantities respect the current scope and all-roof totals')

            page.locator('#roof').select_option('all');page.locator('#isoBtn').click();page.locator('#seams').check()
            before=page.evaluate('ROOF_PANEL_TEST.camera.pan.slice()');page.locator('#moveRight').click();after=page.evaluate('ROOF_PANEL_TEST.camera.pan.slice()');assert math.dist(before,after)>4.99
            page.locator('#moveCenter').click()
            with page.expect_download() as dl:page.locator('#partsCsvBtn').click()
            csvpath=ROOT/'1102e_V8逐板统计.csv';dl.value.save_as(csvpath)
            rows=list(csv.reader(io.StringIO(csvpath.read_text(encoding='utf-8-sig'))));assert len(rows)-1==large_count
            with page.expect_download() as dl:page.locator('#jsonBtn').click()
            modelpath=ROOT/'1102e_V8矩形铝板分隔.json';dl.value.save_as(modelpath);model=json.loads(modelpath.read_text())
            assert len(model['panels'])==large_count and model['nominal_width_m']==2.5 and model['nominal_length_m']==6
            assert model['panel_study_version'].startswith('v8-') and model['sizing_rule']['min_width_mm']==1 and model['sizing_rule']['max_width_mm']==1e9
            assert not model['sizing_rule']['ratio_locked'];assert model['geometry_rule']['planarity_tolerance_mm']==.0001
            assert len(set(p['id'] for p in model['panels']))==large_count
            assert set(p['roof_id'] for p in model['panels'])==set('ABCD')
            for row,panel in zip(rows[1:],model['panels']):
                assert row[0]==panel['id'] and row[2]==panel['roof_id']
                assert abs(float(row[3])-panel['width_m']*1000)<=.000501
                assert abs(float(row[4])-panel['length_m']*1000)<=.000501
                assert abs(float(row[5])-panel['area_m2'])<=.000000501
            json_geometry=check_flat_panels(model['panels']);assert json_geometry['max_plane_error_m']<=1e-7
            net_area=sum(p['area_m2'] for p in model['panels'])
            displayed_area=page.evaluate('Number(document.getElementById("mArea").textContent.replace(/,/g,""))')
            assert abs(net_area-displayed_area)<=.005001
            neighbors=page.evaluate(NEIGHBOR_METRICS)
            assert neighbors['pairs']>0
            assert max(neighbors['max_width_relative_difference'],neighbors['max_length_relative_difference'])<=.1+1e-8
            displayed_neighbor=page.evaluate('Number(document.getElementById("vNeighbor").textContent.replace(/[^0-9.]/g,""))/100')
            assert abs(displayed_neighbor-max(neighbors['max_width_relative_difference'],neighbors['max_length_relative_difference']))<=.0000501
            with page.expect_download() as dl:page.locator('#daeBtn').click()
            dae=ROOT/'1102e_V8矩形铝板分隔.dae';dl.value.save_as(dae)
            dae_geometry=check_dae(dae,model['panels']);assert dae_geometry['count']==large_count and dae_geometry['max_plane_error_m']<=1e-7
            page.locator('#helpBtn').click()
            with page.expect_download() as dl:page.locator('#downloadBridgeBtn').click()
            bridge=ROOT/'test_bridge_v8.rb';dl.value.save_as(bridge);assert bridge.read_bytes()==(ROOT/'sketchup_bridge.rb').read_bytes()
            page.locator('#closeModal').click()
            passed('model movement and actual 2500×6000 CSV/JSON/DAE preserve every true rectangle and arc trim in all four roofs')

            page.locator('#roof').select_option('A');page.locator('#singleTopBtn').click()
            page.wait_for_function('getComputedStyle(document.getElementById("toast")).display==="none"')
            page.locator('#isoBtn').click()
            page.screenshot(path=str(ROOT/'1102e_V8矩形分格预览.png'),full_page=True)
            shape=page.evaluate('(()=>{let panels=ROOF_PANEL_TEST.candidate.panels;return {all:panels.length,planar:panels.filter(p=>p.kind==="planar").length,folded:panels.filter(p=>p.needs_bend).length,rectangles:panels.filter(p=>p.is_rectangle).length,arc_trims:panels.filter(p=>!p.is_rectangle).length,shapes:[...new Set(panels.map(p=>p.layout_shape))],summary:ROOF_PANEL_TEST.candidate.summary}})()')
            assert shape['all']==shape['planar']==shape['rectangles']+shape['arc_trims'] and shape['folded']==0
            assert set(shape['shapes'])=={'planar_rectangle','outer_arc_trim'}
            # Frame an actual outer-arc exception from its geometry for a readable closeup.
            page.evaluate('(()=>{const p=candidate.panels.filter(p=>!p.is_rectangle).sort((a,b)=>b.area_m2-a.area_m2)[0], q=p.vertices.reduce((s,v)=>s.map((x,i)=>x+v[i]/p.vertices.length),[0,0,0]);camera.pan=[q[0]-original.center[0],q[1]-original.center[1],q[2]-original.center[2]-original.targetZ];camera.r=32;camera.phi=.5;camera.theta=-Math.PI/2;dirty=true;renderer.render()})()')
            page.screenshot(path=str(ROOT/'1102e_V8圆弧修边预览.png'),full_page=True)
            page.set_viewport_size({'width':390,'height':844})
            assert page.locator('#model').is_visible() and page.locator('#movePad').is_visible()
            page.screenshot(path=str(ROOT/'mobile_v8.png'),full_page=True)
            assert not errors,errors;assert not external,external;assert page.evaluate('ROOF_PANEL_TEST.gl.getError()')==0
            passed('all interiors are true flat rectangles and outer arc trims alone vary; offline desktop/mobile have no JS, GL or external-request errors')
            browser.close()
        assert html_hash==hashlib.sha256((ROOT/'app.html').read_bytes()).hexdigest()
        report={'passed':len(checks),'checks':checks,'errors':errors,'external_requests':external,'sample_width_mm':2500,'sample_length_mm':6000,'sample_panels':large_count,'sample_new_net_area_m2':net_area,'shape_stats':shape,'actual_interior_neighbors':neighbors,'actual_json_planarity':json_geometry,'actual_dae_planarity':dae_geometry,'worker_sha256':embedded_worker_hash,'embedded_worker_sha256':embedded_worker_hash,'build_manifest_matches':True,'html_sha256':html_hash,'gpu_pixel_evidence':pixel_evidence,'delivery_mode_tested':'fully embedded HTML via local HTTP, with no external requests'}
        (ROOT/'browser_validation_v8.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
    finally:
        server.shutdown();server.server_close()


if __name__=='__main__':
    main()
