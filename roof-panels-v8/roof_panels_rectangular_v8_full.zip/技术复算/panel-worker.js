/* V8: an explicitly approved reconstructed rectangular extrusion roof.
 * Offline JavaScript; no geometry service, preset geometry, or dependencies.
 * Equal spatial profile chords define planar strips. One global Y grid is
 * shared by every strip. Only the supplied full-roof exterior arcs are trims.
 * The original fan roof is a deviation reference, never the panel surface.
 */
'use strict';

const EPS = 1e-9;
const MAX_WORLD_PANELS = 500000;
const RESOURCE_ERROR = '尺寸过小，预计板块过多；请增大尺寸后重新计算（单次最多 500,000 块实例板）';
const sub = (a,b) => a.map((v,k) => v-b[k]);
const dot = (a,b) => a.reduce((s,v,k) => s+v*b[k],0);
const cross = (a,b) => [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
const norm = a => Math.hypot(...a);
const area3 = (a,b,c) => norm(cross(sub(b,a),sub(c,a)))/2;
const round = (v,n=9) => Math.round(v*10**n)/10**n;
const transform = (p,m) => [m[0]*p[0]+m[4]*p[1]+m[8]*p[2]+m[12],m[1]*p[0]+m[5]*p[1]+m[9]*p[2]+m[13],m[2]*p[0]+m[6]*p[1]+m[10]*p[2]+m[14]];

function polygonArea(poly) {
  if (poly.length<3) return 0;
  const p=poly[0]; let a=0;
  for(let k=1;k+1<poly.length;k++) a+=(poly[k][0]-p[0])*(poly[k+1][1]-p[1])-(poly[k][1]-p[1])*(poly[k+1][0]-p[0]);
  return Math.abs(a)/2;
}
function cleanPolygon(poly) {
  let out=[];
  for(const p of poly) if(!out.length || Math.hypot(p[0]-out[out.length-1][0],p[1]-out[out.length-1][1])>1e-10) out.push(p.slice(0,2));
  if(out.length>1 && Math.hypot(out[0][0]-out[out.length-1][0],out[0][1]-out[out.length-1][1])<1e-10) out.pop();
  let changed=true;
  while(changed && out.length>3) {
    changed=false; const next=[];
    for(let k=0;k<out.length;k++) {
      const a=out[(k+out.length-1)%out.length],b=out[k],c=out[(k+1)%out.length];
      const u=[b[0]-a[0],b[1]-a[1]],v=[c[0]-b[0],c[1]-b[1]];
      if(Math.abs(u[0]*v[1]-u[1]*v[0])<=1e-11*Math.hypot(...u)*Math.hypot(...v) && dot(u,v)>=0) changed=true;
      else next.push(b);
    }
    out=next;
  }
  return out.length>=3 ? out : [];
}
function clipSide(poly,axis,bound,above) {
  if(poly.length<3) return [];
  const out=[],sign=above?1:-1; let a=poly[poly.length-1],da=(a[axis]-bound)*sign;
  for(const b of poly) {
    const db=(b[axis]-bound)*sign;
    if((da>=0)!==(db>=0)) {
      const t=da/(da-db),p=[a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t]; p[axis]=bound;out.push(p);
    }
    if(db>=0) out.push(b);
    a=b;da=db;
  }
  return cleanPolygon(out);
}
function clipRect(poly,r) {
  return clipSide(clipSide(clipSide(clipSide(poly,0,r[0],true),0,r[2],false),1,r[1],true),1,r[3],false);
}
function bounds(poly) {
  let x0=Infinity,x1=-Infinity,y0=Infinity,y1=-Infinity;
  for(const p of poly){x0=Math.min(x0,p[0]);x1=Math.max(x1,p[0]);y0=Math.min(y0,p[1]);y1=Math.max(y1,p[1]);}
  return [x0,y0,x1,y1];
}
function lowerBound(a,v) {let l=0,h=a.length;while(l<h){const m=(l+h)>>>1;if(a[m]<v)l=m+1;else h=m;}return l;}
function upperBound(a,v) {let l=0,h=a.length;while(l<h){const m=(l+h)>>>1;if(a[m]<=v)l=m+1;else h=m;}return l;}
function interpolate(nodes,x) {
  if(x<=nodes[0][0])return nodes[0][1];
  if(x>=nodes[nodes.length-1][0])return nodes[nodes.length-1][1];
  let lo=0,hi=nodes.length;while(lo<hi){const mid=(lo+hi)>>>1;if(nodes[mid][0]<=x)lo=mid+1;else hi=mid;}
  const i=Math.max(0,Math.min(nodes.length-2,lo-1));
  const a=nodes[i],b=nodes[i+1];return a[1]+(b[1]-a[1])*(x-a[0])/(b[0]-a[0]);
}
function segmentIntersectsRect(a,b,r) {
  let lo=0,hi=1;
  for(let k=0;k<2;k++) {
    const d=b[k]-a[k];
    if(Math.abs(d)<1e-14){if(a[k]<r[k]-EPS||a[k]>r[k+2]+EPS)return false;}
    else {const p=(r[k]-a[k])/d,q=(r[k+2]-a[k])/d;lo=Math.max(lo,Math.min(p,q));hi=Math.min(hi,Math.max(p,q));}
  }
  return hi-lo>1e-10 && Math.hypot(b[0]-a[0],b[1]-a[1])*(hi-lo)>1e-9;
}
function edgeInterval(poly,axis,value) {
  const values=poly.filter(p=>Math.abs(p[axis]-value)<1e-7).map(p=>p[1-axis]);
  return values.length<2?null:[Math.min(...values),Math.max(...values)];
}
function verticalRange(poly,x) {
  const yy=[];
  for(let k=0;k<poly.length;k++) {
    const a=poly[k],b=poly[(k+1)%poly.length];
    if(x<Math.min(a[0],b[0])-EPS || x>Math.max(a[0],b[0])+EPS)continue;
    if(Math.abs(b[0]-a[0])<1e-12){if(Math.abs(x-a[0])<EPS)yy.push(a[1],b[1]);}
    else {const t=(x-a[0])/(b[0]-a[0]);if(t>=-1e-9&&t<=1+1e-9)yy.push(a[1]+t*(b[1]-a[1]));}
  }
  return yy.length?[Math.min(...yy),Math.max(...yy)]:null;
}

class RectangleStudy {
  constructor(model,progress) {
    const d=model.reconstruction||model.reconstructData||model;
    this.outline=d.outline||d.outline2d;this.profile=d.profile||d.profile_nodesXZ;
    if(!Array.isArray(this.outline)||this.outline.length<3||!this.outline.every(p=>Array.isArray(p)&&p.length>=2&&p.slice(0,2).every(Number.isFinite)))throw new Error('重构屋面外轮廓无效');
    this.outline=this.outline.map(p=>p.slice(0,2));
    if(norm(sub(this.outline[0],this.outline[this.outline.length-1]))<1e-10)this.outline.pop();
    if(!Array.isArray(this.profile)||this.profile.length<2||!this.profile.every((p,k)=>Array.isArray(p)&&p.length===2&&p.every(Number.isFinite)&&(!k||p[0]>this.profile[k-1][0])))throw new Error('重构屋面 XZ 剖面必须严格递增');
    this.profile=this.profile.map(p=>p.slice());this.progress=progress||(()=>{});
    this.reference=d.reference||{verticesA:d.sourceApoints,facesA:d.sourcefaces};
    this.instances=d.instances||model.instances;
    if(!Array.isArray(this.instances)||!this.instances.length)throw new Error('缺少完整屋面实例变换');
    for(const ins of this.instances){const m=ins.matrix;if(!Array.isArray(m)||m.length!==16||!m.every(Number.isFinite))throw new Error('屋面实例矩阵无效');const a=m.slice(0,3),b=m.slice(4,7),c=m.slice(8,11);if(Math.max(Math.abs(norm(a)-1),Math.abs(norm(b)-1),Math.abs(norm(c)-1),Math.abs(dot(a,b)),Math.abs(dot(a,c)),Math.abs(dot(b,c)))>1e-7)throw new Error('矩形屋面实例必须使用刚体变换');}
    this.n=this.instances.length;this.box=bounds(this.outline);this.footprintArea=polygonArea(this.outline);
    this.arcIds=Array.isArray(d.arc_edge_indices)?d.arc_edge_indices.slice():this.outline.map((p,k)=>{const q=this.outline[(k+1)%this.outline.length];return Math.abs(q[0]-p[0])>1e-6&&Math.abs(q[1]-p[1])>1e-6?k:-1;}).filter(k=>k>=0);
    if(!this.arcIds.every(k=>Number.isInteger(k)&&k>=0&&k<this.outline.length))throw new Error('圆弧边索引无效');
    this.curve=[[this.box[0],interpolate(this.profile,this.box[0])],...this.profile.filter(p=>p[0]>this.box[0]&&p[0]<this.box[2]),[this.box[2],interpolate(this.profile,this.box[2])]];
    this.arcLength=0;for(let k=1;k<this.curve.length;k++)this.arcLength+=norm(sub(this.curve[k],this.curve[k-1]));
  }
  advance(position,radius) {
    let lo=0,hi=this.curve.length;while(lo<hi){const mid=(lo+hi)>>>1;if(this.curve[mid][0]<=position[0])lo=mid+1;else hi=mid;}
    const start=Math.max(0,Math.min(this.curve.length-2,lo-1));
    for(let j=start;j+1<this.curve.length;j++) {
      const a=this.curve[j],d=sub(this.curve[j+1],a),v=sub(a,position),aa=dot(d,d),bb=2*dot(v,d),cc=dot(v,v)-radius*radius,disc=bb*bb-4*aa*cc;
      if(disc< -1e-12)continue;const r=Math.sqrt(Math.max(0,disc));
      for(const t of [(-bb-r)/(2*aa),(-bb+r)/(2*aa)])if(t>=-1e-10&&t<=1+1e-10){const q=[a[0]+t*d[0],a[1]+t*d[1]];if(q[0]>position[0]+1e-10)return q;}
    }
    return this.curve[this.curve.length-1].slice();
  }
  equalChords(width) {
    const count=Math.max(1,Math.ceil(this.arcLength/width));
    if(count*this.n>MAX_WORLD_PANELS)throw new Error(RESOURCE_ERROR);
    if(count===1)return [this.curve[0].slice(),this.curve[this.curve.length-1].slice()];
    let lo=0,hi=this.arcLength/count;
    for(let k=0;k<58;k++){const r=(lo+hi)/2;let p=this.curve[0];for(let j=1;j<count;j++)p=this.advance(p,r);if(norm(sub(this.curve[this.curve.length-1],p))>r)lo=r;else hi=r;}
    const radius=(lo+hi)/2,nodes=[this.curve[0].slice()];
    for(let k=1;k<count;k++)nodes.push(this.advance(nodes[nodes.length-1],radius));
    nodes.push(this.curve[this.curve.length-1].slice());
    for(let k=1;k<nodes.length;k++)if(!(nodes[k][0]>nodes[k-1][0]+1e-10)||norm(sub(nodes[k],nodes[k-1]))>width+1e-7)throw new Error('等真实弦宽分板求解未收敛');
    return nodes;
  }
  prepareStrips(nodes) {
    return nodes.slice(0,-1).map((a,k)=>{
      const b=nodes[k+1],poly=clipSide(clipSide(this.outline,0,a[0],true),0,b[0],false),box=bounds(poly);
      let safeLo=-Infinity,safeHi=Infinity;
      for(const p of poly){const r=verticalRange(poly,p[0]);if(r&&Math.abs(p[1]-r[0])<1e-7)safeLo=Math.max(safeLo,p[1]);if(r&&Math.abs(p[1]-r[1])<1e-7)safeHi=Math.min(safeHi,p[1]);}
      return {poly,box,safeLo,safeHi,width:norm(sub(b,a)),scale:norm(sub(b,a))/(b[0]-a[0])};
    });
  }
  densifyExterior(nodes) {
    const xy=[],sourceIds=[],arcSet=new Set(this.arcIds),denseArcIds=[];
    for(let k=0;k<this.outline.length;k++) {
      const a=this.outline[k],b=this.outline[(k+1)%this.outline.length],dx=b[0]-a[0],tt=[0];
      if(Math.abs(dx)>1e-12)for(const p of nodes){const t=(p[0]-a[0])/dx;if(t>1e-10&&t<1-1e-10)tt.push(t);}
      tt.sort((u,v)=>u-v);
      for(const t of tt){if(arcSet.has(k))denseArcIds.push(xy.length);xy.push([a[0]+t*dx,a[1]+t*(b[1]-a[1])]);sourceIds.push(k);}
    }
    this.denseExterior=xy.map(p=>[p[0],p[1],interpolate(nodes,p[0])]);this.denseArcIds=denseArcIds;this.denseSourceIds=sourceIds;
  }
  chooseRows(strips,length) {
    const y0=this.box[1],y1=this.box[3],height=y1-y0,base=Math.max(1,Math.ceil(height/length));
    if(base*strips.length*this.n>MAX_WORLD_PANELS)throw new Error(RESOURCE_ERROR);
    const extra=Math.min(4,Math.floor(base*.12));let best=null;
    const phaseSamples=base*strips.length>40000?5:17;
    for(let rows=base;rows<=base+extra;rows++) {
      if(rows*strips.length*this.n>MAX_WORLD_PANELS)break;
      const pitch=height/rows,limit=rows===1?0:Math.max(0,Math.min(.047*pitch,length-pitch));
      for(let si=0;si<(limit>1e-10?phaseSamples:1);si++) {
        const phase=limit>1e-10?-limit+2*limit*si/(phaseSamples-1):0;
        const cuts=[y0];for(let j=1;j<rows;j++)cuts.push(y0+j*pitch+phase);cuts.push(y1);
        let minFraction=1,minAreaFraction=1,trims=0;
        for(const s of strips) {
          const j0=Math.max(0,upperBound(cuts,s.box[1])-1),j1=Math.min(rows-1,lowerBound(cuts,s.box[3]));
          for(let j=j0;j<=j1;j++) {
            if(cuts[j]>=s.safeLo-EPS&&cuts[j+1]<=s.safeHi+EPS)continue;
            const p=clipSide(clipSide(s.poly,1,cuts[j],true),1,cuts[j+1],false),area=polygonArea(p);
            if(area<1e-12)continue;const b=bounds(p),cell=(s.box[2]-s.box[0])*(cuts[j+1]-cuts[j]);
            if(Math.abs(area-cell)<1e-9)continue;
            trims++;minFraction=Math.min(minFraction,(b[2]-b[0])/(s.box[2]-s.box[0]),(b[3]-b[1])/(cuts[j+1]-cuts[j]));minAreaFraction=Math.min(minAreaFraction,area/cell);
          }
        }
        const result={cuts,rows,pitch,phase,minFraction,minAreaFraction,trims};
        if(!best || minFraction>best.minFraction+1e-10 || Math.abs(minFraction-best.minFraction)<1e-10&&(minAreaFraction>best.minAreaFraction+1e-10 || Math.abs(minAreaFraction-best.minAreaFraction)<1e-10&&rows<best.rows))best=result;
      }
    }
    return best;
  }
  panel(i,j,poly,nodes,cuts,strips) {
    poly=cleanPolygon(poly);if(poly.length<3||polygonArea(poly)<1e-12)return null;
    const a=nodes[i],b=nodes[i+1],s=strips[i],xybox=bounds(poly),vertices=poly.map(p=>[p[0],p[1],a[1]+(p[0]-a[0])*(b[1]-a[1])/(b[0]-a[0])]);
    const faces=triangulatePolygon(poly);if(!faces.length)return null;
    let right=0,rectangle=vertices.length===4;
    for(let k=0;k<vertices.length;k++){const u=sub(vertices[(k+vertices.length-1)%vertices.length],vertices[k]),v=sub(vertices[(k+1)%vertices.length],vertices[k]);right=Math.max(right,Math.abs(dot(u,v))/(norm(u)*norm(v)));}
    rectangle=rectangle&&right<1e-8;
    const r=[a[0],cuts[j],b[0],cuts[j+1]],arcIds=rectangle?[]:this.denseArcIds.filter(k=>segmentIntersectsRect(this.denseExterior[k],this.denseExterior[(k+1)%this.denseExterior.length],r));
    if(!rectangle&&!arcIds.length)throw new Error('非矩形板未接触真实外轮廓圆弧，不能作为修边例外');
    const du=(xybox[2]-xybox[0])*s.scale,dv=xybox[3]-xybox[1],area=polygonArea(poly)*s.scale;
    const uaxis=[(b[0]-a[0])/s.width,0,(b[1]-a[1])/s.width],vaxis=[0,1,0];
    const normal=cross(uaxis,vaxis);let deviation=0;for(const p of vertices)deviation=Math.max(deviation,Math.abs(dot(sub(p,vertices[0]),normal)));
    return {id:`R${String(i).padStart(4,'0')}-${String(j).padStart(4,'0')}`,type_id:'',roof_id:'A',vertices,faces,outlines:[vertices],uv_vertices:poly,
      grid:[i,j],uv_bounds:xybox,uv_area:polygonArea(poly),area_m2:area,world_areas_m2:Array(this.n).fill(area),
      width_m:Math.min(du,dv),length_m:Math.max(du,dv),direction_width_m:du,direction_length_m:dv,
      stock_width_m:s.width,stock_length_m:cuts[j+1]-cuts[j],planar_box_width_m:Math.min(du,dv),planar_box_length_m:Math.max(du,dv),planar_box_axes:du<=dv?[uaxis,vaxis]:[vaxis,uaxis],
      surface_width_bound_m:Math.min(du,dv),surface_length_bound_m:Math.max(du,dv),surface_u_bound_m:du,surface_v_bound_m:dv,
      layout_shape:rectangle?'planar_rectangle':'outer_arc_trim',is_rectangle:rectangle,is_surface_rectangle:rectangle,is_exterior_arc_trim:!rectangle,arc_edge_ids:arcIds,source_arc_edge_ids:[...new Set(arcIds.map(k=>this.denseSourceIds[k]))],
      corner_count:vertices.length,kind:'planar',fabrication_shape:rectangle?'flat_euclidean_rectangle':'flat_exterior_arc_trim',dimension_method:'actual_finished_polygon_bbox_in_orthogonal_strip_plane',
      nonplanarity_mm:deviation*1000,first_face_deviation_mm:deviation*1000,right_angle_cosine_error:rectangle?right:null,needs_bend:false,crease_count:0,planar_patch_id:i,ridge_seams_aligned:true};
  }
  deviation(nodes) {
    const ref=this.reference||{},raw=ref.verticesA||ref.vertices||[],faces=ref.facesA||ref.faces||[];
    if(!Array.isArray(raw)||!raw.length||!Array.isArray(faces)||!faces.length)throw new Error('缺少原屋面偏差校核数据');
    const sets=Array.isArray(raw[0][0])?raw:[raw];let max=0,sum=0,area=0;const errors=[];
    for(let si=0;si<sets.length;si++) {
      const points=sets[si];for(const p of points){if(!Array.isArray(p)||p.length!==3||!p.every(Number.isFinite))throw new Error('原屋面偏差参考点无效');max=Math.max(max,Math.abs(interpolate(nodes,p[0])-p[2]));}
      const ff=Array.isArray(faces[0][0])?faces[si]:faces;
      for(const f of ff){const a=points[f[0]],b=points[f[1]],c=points[f[2]];if(!a||!b||!c)throw new Error('原屋面参考三角面无效');const weight=area3(a,b,c),x=(a[0]+b[0]+c[0])/3,z=(a[2]+b[2]+c[2])/3,e=interpolate(nodes,x)-z;sum+=e*e*weight;area+=weight;errors.push(Math.abs(e));}
    }
    errors.sort((a,b)=>a-b);return {source_vertex_max_vertical_deviation_m:max,source_centroid_area_weighted_rms_vertical_deviation_m:Math.sqrt(sum/area),source_centroid_p95_abs_vertical_deviation_m:errors[Math.floor((errors.length-1)*.95)],source_reference_area_m2:area*this.n};
  }
  checks(panels,nodes,cuts) {
    const byGrid=new Map(panels.map(p=>[p.grid.join(','),p]));let inner=0,boundary=0,innerW=0,innerL=0,boundaryW=0,boundaryL=0;
    for(const p of panels)for(let axis=0;axis<2;axis++) {
      const g=p.grid.slice();g[axis]++;const q=byGrid.get(g.join(','));if(!q)continue;
      const value=axis===0?nodes[g[0]][0]:cuts[g[1]],aa=edgeInterval(p.uv_vertices,axis,value),bb=edgeInterval(q.uv_vertices,axis,value);
      if(!aa||!bb||Math.min(aa[1],bb[1])-Math.max(aa[0],bb[0])<1e-8)continue;
      const dw=Math.abs(p.direction_width_m-q.direction_width_m)/Math.min(p.direction_width_m,q.direction_width_m),dl=Math.abs(p.direction_length_m-q.direction_length_m)/Math.min(p.direction_length_m,q.direction_length_m);
      if(p.is_rectangle&&q.is_rectangle){inner++;innerW=Math.max(innerW,dw);innerL=Math.max(innerL,dl);}else{boundary++;boundaryW=Math.max(boundaryW,dw);boundaryL=Math.max(boundaryL,dl);}
    }
    const sides=nodes.slice(1,-1).map(()=>[[],[]]);
    for(const p of panels){const [i]=p.grid;if(i>0){const x=edgeInterval(p.uv_vertices,0,nodes[i][0]);if(x&&x[1]-x[0]>1e-8)sides[i-1][1].push(x);}if(i+1<nodes.length-1){const x=edgeInterval(p.uv_vertices,0,nodes[i+1][0]);if(x&&x[1]-x[0]>1e-8)sides[i][0].push(x);}}
    let mismatch=0,segments=0,stations=0;const edges=[];
    for(let i=0;i<sides.length;i++){const [a,b]=sides[i];a.sort((u,v)=>u[0]-v[0]);b.sort((u,v)=>u[0]-v[0]);const aligned=a.length===b.length&&a.every((v,j)=>Math.abs(v[0]-b[j][0])<1e-7&&Math.abs(v[1]-b[j][1])<1e-7);if(!aligned)mismatch++;segments+=Math.max(a.length,b.length);stations+=Math.max(0,Math.max(a.length,b.length)-1);edges.push({strip_boundary:i+1,x:nodes[i+1][0],aligned,side_intervals:a,opposite_intervals:b});}
    if(mismatch)throw new Error(`重构褶皱分缝未对齐：${mismatch} 条`);
    if(Math.max(innerW,innerL)>.10000001)throw new Error('标准矩形相邻尺寸差超过 10%');
    return {neighbor:{interior_checked_pairs:inner,boundary_checked_pairs:boundary,interior_width_relative_difference_max:innerW,interior_length_relative_difference_max:innerL,interior_max_relative_difference:Math.max(innerW,innerL),boundary_actual_width_relative_difference_max:boundaryW,boundary_actual_length_relative_difference_max:boundaryL,boundary_actual_max_relative_difference:Math.max(boundaryW,boundaryL),relative_difference_definition:'abs(a-b)/min(a,b)',boundary_exception:'actual_arc_trim_dimensions_reported_separately'},alignment:{method:'actual_matching_panel_intervals_on_both_sides_of_every_rebuilt_strip_ridge',tolerance_m:1e-7,checked_ridge_edges:sides.length,paired_ridge_segments:segments,paired_internal_seam_stations:stations,mismatched_ridge_edges:mismatch,edges}};
  }
  solve(widthMm,lengthMm) {
    const width=widthMm/1000,length=lengthMm/1000,height=this.box[3]-this.box[1];
    if(Math.ceil(this.footprintArea/(width*length))*this.n>MAX_WORLD_PANELS||Math.ceil((this.box[2]-this.box[0])/width)*this.n>MAX_WORLD_PANELS||Math.ceil(height/length)*this.n>MAX_WORLD_PANELS)throw new Error(RESOURCE_ERROR);
    this.progress({stage:'profile',progress:3,message:'按真实空间弦宽求解平行褶皱'});
    const nodes=this.equalChords(width),strips=this.prepareStrips(nodes);this.densifyExterior(nodes);
    this.progress({stage:'grid',progress:15,message:'优化全屋共用分缝，减少圆弧边缘碎板'});
    const row=this.chooseRows(strips,length),cuts=row.cuts,panels=[];
    let area=0,maxW=0,maxL=0,maxU=0,maxV=0,maxDev=0,maxAngle=0,small=0,minArea=Infinity,triCount=0,rectCount=0,minTrimFraction=1;
    for(let i=0;i<strips.length;i++) {
      const s=strips[i],j0=Math.max(0,upperBound(cuts,s.box[1])-1),j1=Math.min(cuts.length-2,lowerBound(cuts,s.box[3]));
      for(let j=j0;j<=j1;j++) {
        const p=this.panel(i,j,clipSide(clipSide(s.poly,1,cuts[j],true),1,cuts[j+1],false),nodes,cuts,strips);if(!p)continue;
        if(p.direction_width_m>width+1e-7||p.direction_length_m>length+1e-7)throw new Error('板块真实方向尺寸超过输入上限');
        panels.push(p);area+=p.area_m2;maxW=Math.max(maxW,p.width_m);maxL=Math.max(maxL,p.length_m);maxU=Math.max(maxU,p.direction_width_m);maxV=Math.max(maxV,p.direction_length_m);maxDev=Math.max(maxDev,p.nonplanarity_mm);minArea=Math.min(minArea,p.area_m2);triCount+=p.faces.length;if(p.is_rectangle){rectCount++;maxAngle=Math.max(maxAngle,p.right_angle_cosine_error);}else minTrimFraction=Math.min(minTrimFraction,p.direction_width_m/p.stock_width_m,p.direction_length_m/p.stock_length_m);if(p.area_m2<.05)small++;
      }
      if(i%32===0)this.progress({stage:'panels',progress:20+Math.round(i/strips.length*50),message:`重构平板 ${i+1} / ${strips.length} 列`});
    }
    let expected=0;for(const s of strips)expected+=polygonArea(s.poly)*s.scale;
    if(Math.abs(area-expected)>1e-6||Math.abs(strips.reduce((v,s)=>v+polygonArea(s.poly),0)-this.footprintArea)>1e-6)throw new Error('重构屋面覆盖面积守恒校核未通过');
    this.progress({stage:'checks',progress:78,message:'校核实际直角、平整度、邻板尺寸和褶皱对缝'});
    const checked=this.checks(panels,nodes,cuts),deviation=this.deviation(nodes),types=[],typeMap=new Map();
    for(const p of panels){const key=p.is_rectangle?`rect:${round(p.width_m,7)}:${round(p.length_m,7)}`:`trim:${p.id}`;let t=typeMap.get(key);if(!t){t={id:`T${String(types.length+1).padStart(4,'0')}`,representative:p.id,width_m:p.width_m,length_m:p.length_m,area_m2:p.area_m2,kind:'planar',layout_shape:p.layout_shape,nonplanarity_mm:p.nonplanarity_mm,template_count:0,handed:false,shape_signature:key};types.push(t);typeMap.set(key,t);}t.template_count++;p.type_id=t.id;}
    const n=this.n,arcCount=panels.length-rectCount,triangles=panels.filter(p=>p.corner_count===3).length,quads=panels.filter(p=>p.corner_count===4).length;
    const roofs=this.instances.map((ins,k)=>({roof_id:ins.roof_id||ins.id||String.fromCharCode(65+k),exterior:this.denseExterior.map(p=>transform(p,ins.matrix)),arc_edge_indices:this.denseArcIds.slice(),source_outline_edge_indices:this.denseSourceIds.slice()}));
    const summary={template_panel_count:panels.length,panel_count:panels.length*n,type_count:types.length,handed_type_count:types.length,surface_area_m2:area*n,template_surface_area_m2:area,area_error_m2:area-expected,
      max_width_m:maxW,max_length_m:maxL,max_surface_u_bound_m:maxU,max_surface_v_bound_m:maxV,max_surface_width_bound_m:maxW,max_surface_length_bound_m:maxL,max_nonplanarity_mm:maxDev,max_first_face_deviation_mm:maxDev,planarity_tolerance_mm:.0001,max_right_angle_cosine_error:maxAngle,min_panel_area_m2:minArea,
      curved_panel_count:0,needs_bend_panel_count:0,planar_panel_count:panels.length*n,strict_planar_panel_count:panels.length*n,triangle_count:triCount*n,planar_quad_panel_count:quads*n,planar_triangle_panel_count:triangles*n,planar_polygon_panel_count:(panels.length-quads-triangles)*n,
      rectangle_panel_count:rectCount*n,surface_rectangle_panel_count:rectCount*n,arc_trim_panel_count:arcCount*n,boundary_trim_panel_count:arcCount*n,template_rectangle_count:rectCount,template_arc_trim_count:arcCount,small_panel_count:small*n,below_500mm_panel_count:panels.filter(p=>p.width_m<.5).length*n,
      neighbor_max_relative_difference:checked.neighbor.interior_max_relative_difference,neighbor_interior_max_relative_difference:checked.neighbor.interior_max_relative_difference,neighbor_boundary_actual_max_relative_difference:checked.neighbor.boundary_actual_max_relative_difference,min_arc_trim_cell_dimension_fraction:minTrimFraction,
      ridge_edge_count:(nodes.length-2)*n,ridge_seam_count:checked.alignment.paired_ridge_segments*n,ridge_internal_seam_station_count:checked.alignment.paired_internal_seam_stations*n,ridge_misalignment_count:0,crease_edge_count_per_template:nodes.length-2,
      nominal_width_mm:widthMm,nominal_length_mm:lengthMm,selected_nominal_width_mm:widthMm,selected_nominal_length_mm:lengthMm,selected_max_width_m:Math.min(width,length),selected_max_length_m:Math.max(width,length),selected_max_u_m:width,selected_max_v_m:length,repeat_ratio:1-types.length/(panels.length*n),
      transverse_local_refinements:0,u_local_refinements:0,v_local_refinements:0,global_grid_refinements:row.rows-Math.ceil(height/length),u_global_refinements:0,v_global_refinements:row.rows-Math.ceil(height/length),max_world_panel_count:MAX_WORLD_PANELS,
      family_grouping:'congruent_rectangles_and_individually_identified_arc_trims',dimension_grouping_is_geometry_identity:false,rectangle_type_grouping:'proved_congruent_rectangles',source_geometry_preserved:false,reconstruction_approved:true,...deviation};
    this.progress({stage:'complete',progress:100,message:`完成 ${summary.panel_count.toLocaleString()} 块：标准矩形与真实外圆弧修边，褶皱分缝对齐`});
    return {id:`rect-rebuild-${widthMm}x${lengthMm}`,name:`矩形重构 · ${widthMm} × ${lengthMm}`,nominal_width_m:width,nominal_length_m:length,panels,types,instances:this.instances,roofs,summary,neighbor_checks:checked.neighbor,ridge_alignment:checked.alignment,
      geometry_rule:{panels:'flat_euclidean_rectangles_except_true_exterior_arc_trims',roof_surface:'approved_reconstructed_parallel_extrusion',source_geometry_preserved:false,source_used_for_deviation_only:true,planarity_tolerance_mm:.0001,ridge_seams:'aligned',interior_neighbor_dimension_ratio_max:1.1,arc_trim_finished_dimensions_may_vary:true},
      grid:{layout:'equal_chord_rectangular_extrusion',profile_nodes:nodes,u_cuts:nodes.map(p=>p[0]),v_cuts:cuts,common_chord_width_m:strips[0].width,row_pitch_m:row.pitch,row_phase_m:row.phase,row_count:row.rows,arc_trim_optimization:{method:'global_row_count_and_phase_search',minimum_cell_dimension_fraction:minTrimFraction,phase_fraction_limit:.047},transverse_local_refinements:0,u_local_refinements:0,v_local_refinements:0,global_grid_refinements:summary.global_grid_refinements}};
  }
}

/* Ear clipping, needed because source arc tessellation contains small dents. */
function triangulatePolygon(poly) {
  if(poly.length<3)return [];
  let signed=0;for(let k=0;k<poly.length;k++){const a=poly[k],b=poly[(k+1)%poly.length];signed+=a[0]*b[1]-a[1]*b[0];}
  const orient=signed>=0?1:-1,indices=poly.map((_,k)=>k),faces=[];
  const turn=(a,b,c)=>(b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]);
  let attempts=0;
  while(indices.length>3&&attempts++<poly.length*poly.length){let found=false;
    for(let k=0;k<indices.length;k++){const ia=indices[(k+indices.length-1)%indices.length],ib=indices[k],ic=indices[(k+1)%indices.length],a=poly[ia],b=poly[ib],c=poly[ic];if(turn(a,b,c)*orient<=1e-14)continue;
      let contains=false;for(const ix of indices){if(ix===ia||ix===ib||ix===ic)continue;const p=poly[ix];if(turn(a,b,p)*orient>=-1e-12&&turn(b,c,p)*orient>=-1e-12&&turn(c,a,p)*orient>=-1e-12){contains=true;break;}}
      if(contains)continue;faces.push(orient>0?[ia,ib,ic]:[ic,ib,ia]);indices.splice(k,1);found=true;break;
    }
    if(!found)throw new Error('圆弧修边多边形三角化失败');
  }
  if(indices.length===3)faces.push(orient>0?indices.slice():indices.slice().reverse());return faces;
}
function generate(data,progress) {
  if(!data||!Number.isInteger(data.widthMm)||data.widthMm<1||data.widthMm>1e9)throw new Error('宽度必须是大于 0 且不超过 1,000,000,000 mm 的整数');
  if(!Number.isInteger(data.lengthMm)||data.lengthMm<1||data.lengthMm>1e9)throw new Error('长度必须是大于 0 且不超过 1,000,000,000 mm 的整数');
  return new RectangleStudy(data.model||{},progress).solve(data.widthMm,data.lengthMm);
}
if(typeof self!=='undefined'&&typeof self.postMessage==='function')self.onmessage=event=>{const data=event.data||{};if(data.type!=='generate')return;try{const candidate=generate(data,p=>self.postMessage({type:'progress',requestId:data.requestId,...p}));self.postMessage({type:'result',requestId:data.requestId,candidate});}catch(error){self.postMessage({type:'error',requestId:data.requestId,message:error&&error.message?error.message:String(error)});}};
if(typeof module!=='undefined'&&module.exports)module.exports={generate,RectangleStudy,Study:RectangleStudy,clipRect,polygonArea,triangulatePolygon};
