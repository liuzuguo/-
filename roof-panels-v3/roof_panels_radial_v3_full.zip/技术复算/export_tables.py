"""Derive delivery CSVs from the same world-space JSON exported by the viewer."""
import collections,csv,json,math
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def main():
    data=json.loads((ROOT/'1102e_V3放射分隔.json').read_text())
    groups=collections.defaultdict(list);sizes=collections.defaultdict(list)
    for p in data['panels']:
        groups[p['type_id']].append(p)
        sizes[(math.ceil(p['width_m']*1000-1e-5),math.ceil(p['length_m']*1000-1e-5))].append(p)
    with (ROOT/'1102e_V3板型汇总.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.writer(f);w.writerow(['几何板型','宽度上界mm','长度上界mm','数量','平均表面面积m2','合计表面面积m2','类别'])
        for key,ps in sorted(groups.items(),key=lambda kv:(-len(kv[1]),kv[0])):
            p=ps[0];a=sum(p['area_m2'] for p in ps)
            w.writerow([key,f"{p['width_m']*1000:.3f}",f"{p['length_m']*1000:.3f}",len(ps),f'{a/len(ps):.6f}',f'{a:.6f}','曲面/复合面' if p['nonplanarity_mm']>.001 else '平面'])
    with (ROOT/'1102e_V3尺寸汇总.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.writer(f);w.writerow(['宽上界向上取整mm','长上界向上取整mm','数量','包含几何板型数','合计表面净面积m2'])
        for (width,length),ps in sorted(sizes.items(),key=lambda kv:-len(kv[1])):
            w.writerow([width,length,len(ps),len(set(p['type_id'] for p in ps)),f"{sum(p['area_m2'] for p in ps):.6f}"])
    small=[p for p in data['panels'] if p['area_m2']<.05]
    with (ROOT/'1102e_V3待深化小板.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.writer(f);w.writerow(['板件编号','屋顶','板型','宽度上界mm','长度上界mm','面积m2'])
        for p in small:
            w.writerow([p['id'],p['roof_id'],p['type_id'],f"{p['width_m']*1000:.3f}",f"{p['length_m']*1000:.3f}",f"{p['area_m2']:.8f}"])
    summary={'panels':len(data['panels']),'geometric_types':len(groups),'dimension_groups':len(sizes),'surface_area_m2':sum(p['area_m2'] for p in data['panels']),'small_panels':len(small),'max_width_m':max(p['width_m'] for p in data['panels']),'max_length_m':max(p['length_m'] for p in data['panels']),'layout':{k:v for k,v in data['layout'].items() if k!='source_uv'}}
    (ROOT/'world_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
    print(json.dumps(summary,ensure_ascii=False))

if __name__=='__main__':main()
