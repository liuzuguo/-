"""V3 exact-source-flow roof panel partition.

Constant source U follows original fan rays; constant V follows transverse
curvilinear rows. Source triangle geometry is never replaced by a smooth fit.
"""
from __future__ import annotations
import collections,hashlib,json,math,sys,time
from pathlib import Path
import numpy as np

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'vendor'))
# Only a runtime convenience in the current prepared machine. A portable install
# uses geometry-requirements.txt; there is no dependency on V2 source code.
sys.path.insert(0,str(ROOT.parent/'roof-panel-studio'/'vendor'))
from shapely.geometry import Polygon
from shapely.ops import unary_union
from shapely import union_all
from planar_rectangle import feasible_rectangle

ANGLE=10.0
EPS=1e-10

def clip(poly,axis,bound,above):
    if not poly:return []
    out=[];a=poly[-1];da=(a[axis]-bound)*(1 if above else -1)
    for b in poly:
        db=(b[axis]-bound)*(1 if above else -1)
        if (da>=-EPS)!=(db>=-EPS):
            out.append(a+(b-a)*(da/(da-db)))
        if db>=-EPS:out.append(b)
        a,da=b,db
    clean=[]
    for p in out:
        if not clean or np.linalg.norm(p-clean[-1])>1e-10:clean.append(p)
    if len(clean)>1 and np.linalg.norm(clean[0]-clean[-1])<1e-10:clean.pop()
    return clean if len(clean)>=3 else []

def clip_rect(poly,rect):
    for axis,bound,above in [(0,rect[0],True),(0,rect[2],False),(1,rect[1],True),(1,rect[3],False)]:
        poly=clip(poly,axis,bound,above)
        if not poly:break
    return poly

def signed_area(poly):
    p=np.asarray(poly)
    return float(abs(np.sum(p[:,0]*np.roll(p[:,1],-1)-p[:,1]*np.roll(p[:,0],-1)))/2) if len(p)>=3 else 0.

def segment_intersects_rect(a,b,rect):
    lo,hi=0.,1.
    for axis,mn,mx in [(0,rect[0],rect[2]),(1,rect[1],rect[3])]:
        delta=b[axis]-a[axis]
        if abs(delta)<1e-12:
            if a[axis]<mn-EPS or a[axis]>mx+EPS:return False
        else:
            p,q=(mn-a[axis])/delta,(mx-a[axis])/delta
            lo=max(lo,min(p,q));hi=min(hi,max(p,q))
    return hi-lo>1e-9 and np.linalg.norm(b-a)*(hi-lo)>1e-9

def components(pieces,adj,sharp,uv,rect):
    parent={f:f for f in pieces};members={f:{f} for f in pieces}
    def find(f):
        while f!=parent[f]:parent[f]=parent[parent[f]];f=parent[f]
        return f
    for f in pieces:
        for other,edge in adj[f]:
            if other not in pieces or other<=f or not segment_intersects_rect(uv[edge[0]],uv[edge[1]],rect):continue
            a,b=find(f),find(other)
            if a==b or any(t in members[b] for s in members[a] for t in sharp[s]):continue
            if len(members[a])>len(members[b]):a,b=b,a
            parent[a]=b;members[b].update(members.pop(a))
    groups=collections.defaultdict(dict)
    for f,poly in pieces.items():groups[find(f)][f]=poly
    return list(groups.values())

def shape_hash(points,faces):
    p=np.asarray(points);d=((p[:,None]-p[None,:])**2).sum(axis=2)
    i,j=np.unravel_index(np.argmax(d),d.shape);keys=[]
    for a,b in [(i,j),(j,i)]:
        q=p-p[a];u=p[b]-p[a];u/=np.linalg.norm(u)
        perp=q-np.outer(q@u,u);v=perp[np.argmax((perp**2).sum(axis=1))]
        if np.linalg.norm(v)<1e-12:continue
        v/=np.linalg.norm(v);n=np.cross(u,v)
        coords=np.round(np.stack([q@u,q@v,q@n],axis=1),6)
        order=sorted(range(len(p)),key=lambda k:tuple(coords[k]));ix={a:b for b,a in enumerate(order)}
        fs=sorted(tuple(sorted(ix[k] for k in f)) for f in faces)
        keys.append(json.dumps([coords[order].tolist(),fs],separators=(',',':')))
    return hashlib.sha256(min(keys).encode()).hexdigest()[:20]

class NeedsSplit(Exception):pass

class Study:
    def __init__(self):
        self.model=json.loads((ROOT/'modelData.json').read_text())
        source=self.model['variants']['0'];self.p=np.asarray(source['vertices'],float);self.f=np.asarray(source['faces'],int)
        chart=ROOT/'source_uv_complete.json'
        if not chart.exists():chart=ROOT/'reference_analysis'/'source_uv_complete.json'
        chart_data=json.loads(chart.read_text());self.uv=np.asarray(chart_data['uv'],float)
        self.source_chart=chart_data
        xyz=self.p[self.f];uv=self.uv[self.f]
        uv_matrix=np.stack([uv[:,1]-uv[:,0],uv[:,2]-uv[:,0]],axis=2)
        self.J=np.stack([xyz[:,1]-xyz[:,0],xyz[:,2]-xyz[:,0]],axis=2)@np.linalg.inv(uv_matrix)
        self.norms=np.linalg.norm(self.J,axis=1)
        self.uv_min=uv.min(axis=1);self.uv_max=uv.max(axis=1)
        cr=np.cross(xyz[:,1]-xyz[:,0],xyz[:,2]-xyz[:,0]);self.source_area=float(np.linalg.norm(cr,axis=1).sum()/2)
        normals=cr/np.linalg.norm(cr,axis=1)[:,None];normals[normals[:,2]<0]*=-1;self.normals=normals
        edges=collections.defaultdict(list)
        for fi,face in enumerate(self.f):
            for a,b in zip(face,np.roll(face,-1)):edges[tuple(sorted((int(a),int(b))))].append(fi)
        self.adj=collections.defaultdict(list);self.sharp=collections.defaultdict(set);self.sharp_count=0
        for e,owners in edges.items():
            if len(owners)==2:
                a,b=owners
                if normals[a]@normals[b]>=math.cos(math.radians(ANGLE)):
                    self.adj[a].append((b,e));self.adj[b].append((a,e))
                else:self.sharp[a].add(b);self.sharp[b].add(a);self.sharp_count+=1
        self.instances=[];self.world_area=0.
        for k,ins in enumerate(self.model['instances']):
            m=np.asarray(ins['matrix']).reshape(4,4).T;wp=self.p@m[:3,:3].T+m[:3,3]
            self.world_area+=float(np.linalg.norm(np.cross(wp[self.f[:,1]]-wp[self.f[:,0]],wp[self.f[:,2]]-wp[self.f[:,0]]),axis=1).sum()/2)
            self.instances.append(dict(ins,roof_id='ABCD'[k//2],half=k%2+1,mirrored=bool(np.linalg.det(m[:3,:3])<0)))

    def lift(self,fi,uv):
        return self.p[self.f[fi,0]]+(np.asarray(uv)-self.uv[self.f[fi,0]])@self.J[fi].T

    def global_cuts(self,width,length):
        # The U-fold rays themselves are retained; subdivisions of each original
        # interval continue across the full roof. Length rows can cross integer
        # V boundaries because those are smooth, not mandatory fold seams.
        u=[0.]
        for integer in range(32):
            mask=(self.uv_max[:,0]>integer+1e-8)&(self.uv_min[:,0]<integer+1-1e-8)
            n=max(1,math.ceil(float(self.norms[mask,0].max())/(width*.98)))
            u.extend(integer+k/n for k in range(1,n+1))
        v=[0.]
        while v[-1]<32-1e-9:
            start=v[-1];low=start;high=min(32.,start+length/float(self.norms[:,1].min()))
            for _ in range(45):
                end=(low+high)/2
                mask=(self.uv_max[:,1]>start+1e-9)&(self.uv_min[:,1]<end-1e-9)
                bound=(end-start)*float(self.norms[mask,1].max()) if mask.any() else 0.
                if bound<=length*.98:low=end
                else:high=end
            end=32. if low>32-1e-8 else low
            # The derivative envelope can change at a source-grid integer.
            # Bisection roundoff must not create a nanometre-wide extra cell
            # beside that exact source boundary.
            source_knots=np.unique(self.uv[:,1])
            nearest=float(source_knots[np.argmin(abs(source_knots-end))])
            if abs(end-nearest)<1e-7:end=nearest
            if end-start<1e-7:raise RuntimeError('Transverse grid did not advance')
            v.append(end)
        return np.asarray(u),np.asarray(v)

    def make_panel(self,pieces,grid,rect):
        vertices=[];uvs=[];faces=[];lookup={};used=set()
        for fi,poly in pieces.items():
            ids=[]
            for uv in poly:
                key=tuple(np.round(uv,10))
                if key not in lookup:
                    lookup[key]=len(vertices);vertices.append(self.lift(fi,uv).tolist());uvs.append(np.asarray(uv).tolist())
                ids.append(lookup[key])
            for i in range(1,len(ids)-1):
                face=[ids[0],ids[i],ids[i+1]];a,b,c=np.asarray([vertices[k] for k in face])
                if np.linalg.norm(np.cross(b-a,c-a))>2e-11:faces.append(face);used.add(fi)
        if not faces:return None
        points=np.asarray(vertices);uvs_np=np.asarray(uvs)
        area=float(sum(np.linalg.norm(np.cross(points[b]-points[a],points[c]-points[a]))/2 for a,b,c in faces))
        if area<1e-10:return None
        span=np.ptp(uvs_np,axis=0);dims=np.sort(span*self.norms[sorted(used)].max(axis=0))
        if dims[0]>1.5-1e-7 or dims[1]>3.-1e-7:raise NeedsSplit('surface paths')
        centered=points-points.mean(axis=0);_,_,basis=np.linalg.svd(centered,full_matrices=False)
        dev=float(np.max(np.abs(centered@basis[-1]))*1000)
        planar=dev<.001
        panel={'id':'','type_id':'','vertices':np.round(points,9).tolist(),'uv_vertices':np.round(uvs_np,12).tolist(),
            'faces':faces,'area_m2':round(area,10),'width_m':round(float(dims[0]),9),'length_m':round(float(dims[1]),9),
            'surface_width_bound_m':round(float(dims[0]),9),'surface_length_bound_m':round(float(dims[1]),9),
            'kind':'planar' if planar else 'curved_mesh','nonplanarity_mm':round(dev,6),
            'source_face_ids':sorted(used),'source_face_count':len(used),'grid':list(grid),
            'uv_bounds':[round(float(x),12) for x in rect],
            'dimension_method':'source_uv_jacobian_surface_path_bound'}
        if planar:
            box=feasible_rectangle(centered@basis[:2].T,width=1.5-1e-6,length=3.-1e-6)
            if box is None:raise NeedsSplit('planar rectangle')
            short,long,angle=box
            axis_long=basis[0]*math.cos(angle)+basis[1]*math.sin(angle)
            axis_short=-basis[0]*math.sin(angle)+basis[1]*math.cos(angle)
            panel.update(planar_box_width_m=round(short,9),planar_box_length_m=round(long,9),
                planar_box_axes=[axis_long.tolist(),axis_short.tolist()])
            panel['width_m']=max(panel['width_m'],panel['planar_box_width_m'])
            panel['length_m']=max(panel['length_m'],panel['planar_box_length_m'])
            panel['dimension_method']='max_source_uv_path_and_feasible_orthogonal_planar_box'
        # Neighbouring clipped triangles can differ by ~1e-15 at an identical
        # edge intersection. Normalize only the outline union on a 1e-9 UV grid;
        # the saved source-surface vertices/triangles retain their exact values.
        geometry=union_all([Polygon(poly) for fi,poly in pieces.items() if fi in used],grid_size=1e-9)
        if geometry.geom_type!='Polygon':
            raise RuntimeError(f'A panel is not connected in its source chart: grid={grid}, rect={rect}, source={sorted(used)}, geometry={geometry.wkt}')
        rings=[]
        for ring in [geometry.exterior,*geometry.interiors]:
            coords=[]
            for uv in list(ring.coords)[:-1]:
                d=np.linalg.norm(uvs_np-uv,axis=1);nearest=int(np.argmin(d))
                if d[nearest]<1e-7:xyz=points[nearest]
                else:
                    xyz=None
                    for fi in used:
                        tri_uv=self.uv[self.f[fi]]
                        bary=np.linalg.solve(np.column_stack([tri_uv[1]-tri_uv[0],tri_uv[2]-tri_uv[0]]),np.asarray(uv)-tri_uv[0])
                        if bary.min()>-1e-6 and bary.sum()<1+1e-6:xyz=self.lift(fi,uv);break
                    if xyz is None:raise RuntimeError('Unable to lift boundary')
                coords.append(np.round(xyz,9).tolist())
            rings.append(coords)
        panel['outlines']=rings
        panel['_shape']=shape_hash(panel['vertices'],faces)
        return panel

    def solve(self,width,length):
        uc,vc=self.global_cuts(width,length)
        print('Grid:',len(uc)-1,'continuous fan intervals;',len(vc)-1,'curving transverse rows',flush=True)
        cells=collections.defaultdict(dict)
        for fi,face in enumerate(self.f):
            tri=[self.uv[k] for k in face];lo=self.uv_min[fi];hi=self.uv_max[fi]
            i0=max(0,int(np.searchsorted(uc,lo[0],side='right'))-1);i1=min(len(uc)-2,int(np.searchsorted(uc,hi[0],side='left')))
            j0=max(0,int(np.searchsorted(vc,lo[1],side='right'))-1);j1=min(len(vc)-2,int(np.searchsorted(vc,hi[1],side='left')))
            for i in range(i0,i1+1):
                for j in range(j0,j1+1):
                    poly=clip_rect(tri,(uc[i],vc[j],uc[i+1],vc[j+1]))
                    if poly and signed_area(poly)>1e-12:cells[(i,j)][fi]=poly
        panels=[];refinements=0
        def refine(pieces,rect,grid,depth=0):
            nonlocal refinements
            for comp in components(pieces,self.adj,self.sharp,self.uv,rect):
                try:
                    panel=self.make_panel(comp,grid,rect)
                    if panel:panels.append(panel)
                except NeedsSplit:
                    if depth>8:raise RuntimeError('Panel did not satisfy surface/planar bounds after refinement')
                    # Transverse splitting retains continuous main U-ray seams.
                    refinements+=1;mid=(rect[1]+rect[3])/2
                    for child in [(rect[0],rect[1],rect[2],mid),(rect[0],mid,rect[2],rect[3])]:
                        sub={}
                        for fi,poly in comp.items():
                            cp=clip_rect(poly,child)
                            if cp and signed_area(cp)>1e-12:sub[fi]=cp
                        if sub:refine(sub,child,grid,depth+1)
        for (i,j),pieces in sorted(cells.items()):refine(pieces,(uc[i],vc[j],uc[i+1],vc[j+1]),(i,j))
        types=[];type_ids={}
        for i,panel in enumerate(panels):
            panel['id']=f'P{i+1:05d}';sig=panel.pop('_shape')
            if sig not in type_ids:
                tid=f'T{len(types)+1:05d}';type_ids[sig]=tid
                types.append({'id':tid,'representative':panel['id'],'width_m':panel['width_m'],'length_m':panel['length_m'],
                    'area_m2':panel['area_m2'],'kind':panel['kind'],'nonplanarity_mm':panel['nonplanarity_mm'],
                    'template_count':0,'shape_signature':sig,'handed':panel['kind']=='curved_mesh'})
            panel['type_id']=type_ids[sig];types[int(panel['type_id'][1:])-1]['template_count']+=1
        return panels,types,{'u_cuts':uc.tolist(),'v_cuts':vc.tolist(),'transverse_local_refinements':refinements}

    def output(self):
        return {'format':'roof-panel-study-1','unit':'m','source':{'model_name':'1102e','reference':'1027EX 原始屋面；用户确认与 1102e 一致',
                'template_triangle_count':len(self.f),'template_surface_area_m2':self.source_area,'instance_count':8,'confirmed_same_roof':True},
            'max_width_m':1.5,'max_length_m':3.,'crease_angle_deg':ANGLE,
            'layout':{'type':'exact-source-curvilinear-fan','description':'按原始屋面恢复的角部放射导向曲线及横向随形曲线重分格',
                'source_uv':self.uv.tolist(),'angular_axis':0,'radial_axis':1,'reconstruction':self.source_chart.get('method'),
                'fillet_vertex_ids':self.source_chart.get('fillet_vertex_ids'),
                'continuity':'主放射方向采用全域连续导向线；少量平面板超包络处局部增设横向接缝'},
            'method':{'dimensions':'在原始曲面参数域中按每片区最大三维雅可比导数包络，计算两个方向表面路径上界；平面板另核1.5×3m正交矩形。曲面路径上界不是制造下料展开。',
                'creases':'相邻原三角面夹角大于10°时分片；原三维面保持不变。',
                'optimization':'优先保持参考图连续放射曲线；在三种尺寸基准中比较，不声称全局最优。',
                'gaps':'净覆盖分格，未扣板缝、未计折边、厚度、搭接或龙骨。'},
            'instances':self.instances,'center':self.model['center'],'targetZ':self.model['targetZ'],'candidates':[],
            'recommended_id':'fan-1500x3000'}

def main():
    study=Study();out=study.output()
    for ident,name,w,l in [('fan-1500x3000','连续放射 · 1500 × 3000',1.5,3.),('fan-1200x3000','连续放射 · 1200 × 3000',1.2,3.),('fan-1500x2400','连续放射 · 1500 × 2400',1.5,2.4)]:
        start=time.time();panels,types,grid=study.solve(w,l)
        area=sum(p['area_m2'] for p in panels)
        if abs(area-study.source_area)>1e-5:raise RuntimeError(f'Area mismatch {area-study.source_area}')
        summary={'template_panel_count':len(panels),'panel_count':len(panels)*8,'type_count':len(types),
            'handed_type_count':sum(2 if t['handed'] else 1 for t in types),'surface_area_m2':study.world_area,
            'template_surface_area_m2':area,'area_error_m2':area-study.source_area,
            'max_width_m':max(p['width_m'] for p in panels),'max_length_m':max(p['length_m'] for p in panels),
            'max_nonplanarity_mm':max(p['nonplanarity_mm'] for p in panels),'min_panel_area_m2':min(p['area_m2'] for p in panels),
            'max_surface_width_bound_m':max(p['surface_width_bound_m'] for p in panels),'max_surface_length_bound_m':max(p['surface_length_bound_m'] for p in panels),
            'curved_panel_count':sum(p['kind']=='curved_mesh' for p in panels)*8,'planar_panel_count':sum(p['kind']=='planar' for p in panels)*8,
            'triangle_count':sum(len(p['faces']) for p in panels)*8,'small_panel_count':sum(p['area_m2']<.05 for p in panels)*8,
            'crease_edge_count_per_template':study.sharp_count,'repeat_ratio':1-len(types)/(len(panels)*8),
            'transverse_local_refinements':grid['transverse_local_refinements']*8}
        out['candidates'].append({'id':ident,'name':name,'nominal_width_m':w,'nominal_length_m':l,'panels':panels,'types':types,'summary':summary,'grid':grid})
        temporary=ROOT/'panels.json.tmp'
        temporary.write_text(json.dumps(out,ensure_ascii=False,separators=(',',':')))
        temporary.replace(ROOT/'panels.json')
        print(ident,summary,'seconds',round(time.time()-start,2),flush=True)
        print('Saved',ROOT/'panels.json',flush=True)

if __name__=='__main__':main()
