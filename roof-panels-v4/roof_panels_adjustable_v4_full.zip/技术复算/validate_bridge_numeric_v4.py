"""Numerical mirror of V4 SketchUp preflight; no SketchUp/Ruby execution.

The main case is the real browser's world-coordinate 1500 x 4500 mm export.
When /tmp/v4-validation-W.json snapshots exist, also check every local-template
panel at W=500/873/1000/1500. Those supplementary cases do not claim to execute
the SketchUp API or revalidate all eight instance transforms.
"""
import hashlib
import json
import math
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EXPORT = ROOT / '1102e_V4可调分隔.json'
BRIDGE = ROOT / 'sketchup_bridge.rb'
EPS_M = 0.00001


def sub(a, b):
    return [a[k] - b[k] for k in range(3)]


def dot(a, b):
    return sum(a[k] * b[k] for k in range(3))


def cross(a, b):
    return [a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0]]


def norm(a):
    return math.sqrt(dot(a, a))


def unit(a):
    size = norm(a)
    if size < 1.0e-10:
        raise ValueError('degenerate unit vector')
    return [v / size for v in a]


def polygon_area(points):
    total = [0., 0., 0.]
    for i, p in enumerate(points):
        cr = cross(p, points[(i+1) % len(points)])
        for k in range(3):
            total[k] += cr[k]
    return norm(total) * .5


def fits_planar_envelope(local, width, length):
    # Same critical angles and interval midpoints as fits_planar_envelope?.
    points = [p[:2] for p in local]
    angles = [0.]
    limits = [length + EPS_M, width + EPS_M]
    for i, p in enumerate(points):
        for q in points[i+1:]:
            dx, dy = q[0] - p[0], q[1] - p[1]
            radius = math.sqrt(dx*dx + dy*dy)
            if radius > math.sqrt(limits[0]**2 + limits[1]**2) + 1.0e-9:
                return False
            if radius < 1.0e-10:
                continue
            alpha = math.atan2(dy, dx)
            for k, limit in enumerate(limits):
                if radius <= limit:
                    continue
                center = alpha + (0. if k == 0 else math.pi / 2.)
                delta = math.acos(max(-1., min(1., limit / radius)))
                angles.extend([(center-delta) % math.pi, (center+delta) % math.pi])
    angles = sorted(set(angles))
    candidates = angles.copy()
    for i, a in enumerate(angles):
        b = angles[0] + math.pi if i == len(angles)-1 else angles[i+1]
        candidates.append(((a+b)*.5) % math.pi)
    for angle in candidates:
        c, si = math.cos(angle), math.sin(angle)
        xs = [q[0]*c+q[1]*si for q in points]
        ys = [-q[0]*si+q[1]*c for q in points]
        if max(xs)-min(xs) <= limits[0]+1.0e-9 and max(ys)-min(ys) <= limits[1]+1.0e-9:
            return True
    return False


def check(raw, max_width=1.5, max_length=3.):
    points = raw['vertices']
    assert 3 <= len(points) <= 20000, 'invalid vertices'
    assert all(len(p) == 3 and all(isinstance(v, (int, float)) and math.isfinite(v) and abs(v) <= 1e6 for v in p) for p in points), 'invalid coordinate'
    faces = raw.get('faces', [list(range(len(points)))])
    assert faces and all(len(f) >= 3 and len(set(f)) == len(f) and all(type(i) is int and 0 <= i < len(points) for i in f) for f in faces), 'invalid faces'
    origin = points[faces[0][0]]
    axis_x = axis_z = None
    for f in faces:
        a = points[f[0]]
        for j in range(1, len(f)-1):
            edge = sub(points[f[j]], a)
            normal = cross(edge, sub(points[f[j+1]], a))
            if norm(normal) > 1.0e-10:
                axis_x, axis_z = unit(edge), unit(normal)
                break
        if axis_x:
            break
    assert axis_x, 'degenerate panel'
    axis_y = unit(cross(axis_z, axis_x))
    local = [[dot(sub(p, origin), axis) for axis in (axis_x, axis_y, axis_z)] for p in points]
    area = 0.
    for f in faces:
        fp = [points[i] for i in f]
        if len(fp) > 3:
            normal = None
            for j in range(1, len(fp)-1):
                n = cross(sub(fp[j], fp[0]), sub(fp[j+1], fp[0]))
                if norm(n) > 1.0e-10:
                    normal = unit(n)
                    break
            assert normal, 'degenerate polygon'
            assert all(abs(dot(sub(p, fp[0]), normal)) <= .0001 for p in fp), 'nonplanar polygon requires triangulation'
        area += polygon_area(fp)
    assert area >= 1e-10, 'zero area'
    width, length, reported = [raw[k] for k in ('width_m', 'length_m', 'area_m2')]
    assert all(isinstance(v, (int, float)) and math.isfinite(v) for v in (width, length, reported)), 'invalid metadata'
    assert 0 < width <= max_width+EPS_M and 0 < length <= max_length+EPS_M, 'dimension limit'
    assert abs(area-reported) <= max(.0001, area*.001), 'area mismatch'
    assert area <= width*length*1.001+.00001, 'area greater than envelope'
    height = max(abs(p[2]) for p in local)
    planar = height < .000001
    fitted_by = None
    if planar:
        edges = sorted({tuple(sorted((a, f[(j+1) % len(f)]))) for f in faces for j, a in enumerate(f)})
        for a, b in edges:
            edge = sub(points[b], points[a])
            if norm(edge) < 1e-10:
                continue
            u = unit(edge)
            v = unit(cross(axis_z, u))
            us = [dot(sub(q, origin), u) for q in points]
            vs = [dot(sub(q, origin), v) for q in points]
            dims = sorted((max(us)-min(us), max(vs)-min(vs)))
            if dims[0] <= max_width+EPS_M and dims[1] <= max_length+EPS_M:
                fitted_by = 'face_edge'
                # Ruby continues all edges even after finding a fit.
        if not fitted_by and fits_planar_envelope(local, max_width, max_length):
            fitted_by = 'critical_angular_intervals'
        assert fitted_by, 'actual planar envelope exceeds selected caps'
    return dict(below_nominal_min_width=width < .5-EPS_M, planar=planar, first_plane_deviation_m=height, area=area,
                area_error_m2=abs(area-reported), fitted_by=fitted_by,
                engine_curved=raw.get('nonplanarity_mm', 0) >= .001)


def finite_number(value):
    assert type(value) in (int, float) and math.isfinite(value), 'not a finite number'
    return float(value)


def sizing_limits(data):
    """Mirror Ruby sizing_limits: V4 declared rule, otherwise legacy caps."""
    rule = data.get('sizing_rule')
    v4 = str(data.get('panel_study_version', '')).lower().startswith('v4') or rule is not None
    if not v4:
        for key, cap in [('max_width_m', 1.5), ('max_length_m', 3.)]:
            if key in data:
                value = finite_number(data[key])
                assert 0 < value <= cap+EPS_M, 'legacy declared cap'
        return 1.5, 3.
    assert isinstance(rule, dict), 'V4 sizing_rule required'
    width = finite_number(rule['nominal_width_mm'])
    length = finite_number(rule['nominal_length_mm'])
    ratio = finite_number(rule['ratio'])
    low = finite_number(rule['min_width_mm'])
    high = finite_number(rule['max_width_mm'])
    assert 500.-1e-6 <= width <= 1500.+1e-6, 'nominal width range'
    assert abs(ratio-3.) <= 1e-9 and abs(length-width*3.) <= 1e-6, 'length/width ratio'
    assert abs(low-500.) <= 1e-6 and abs(high-1500.) <= 1e-6, 'nominal range declaration'
    caps = width/1000., length/1000.
    for key, expected in zip(('max_width_m', 'max_length_m'), caps):
        assert abs(finite_number(data[key])-expected) <= 1e-6, 'selected cap inconsistency'
    for key, expected in zip(('nominal_width_m', 'nominal_length_m'), caps):
        if key in data:
            assert abs(finite_number(data[key])-expected) <= 1e-6, 'nominal inconsistency'
    return caps


def fixture_cases():
    def panel(width, length):
        return dict(id='TEST', width_m=width, length_m=length, area_m2=width*length,
                    vertices=[[0, 0, 0], [width, 0, 0], [width, length, 0], [0, length, 0]],
                    faces=[[0, 1, 2], [0, 2, 3]])

    def metadata(width):
        return dict(panel_study_version='v4-adjustable', max_width_m=width/1000.,
                    max_length_m=width*3./1000., sizing_rule=dict(nominal_width_mm=width,
                    nominal_length_mm=width*3., ratio=3, min_width_mm=500, max_width_mm=1500))

    passed = []
    for width in (500, 873, 1000, 1500):
        caps = sizing_limits(metadata(width))
        assert check(panel(*caps), *caps)['planar']
        passed.append('accept_full_%dx%d_mm' % (width, width*3))
    assert check(panel(.2, 1.2), .5, 1.5)['below_nominal_min_width']
    passed.append('accept_and_flag_clipped_200_mm_edge')
    invalids = [('reject_4500_mm_in_legacy', lambda: check(panel(1.5, 4.5))),
                ('reject_selected_width_overflow', lambda: check(panel(.51, 1.5), .5, 1.5)),
                ('reject_selected_length_overflow', lambda: check(panel(.5, 1.6), .5, 1.5)),
                ('reject_V4_missing_rule', lambda: sizing_limits({'panel_study_version':'v4-adjustable'}))]
    for width in (499, 1501):
        invalids.append(('reject_nominal_%d_mm' % width, lambda w=width: sizing_limits(metadata(w))))
    bad_ratio = metadata(1000)
    bad_ratio['sizing_rule']['nominal_length_mm'] = 3001
    invalids.append(('reject_wrong_ratio', lambda: sizing_limits(bad_ratio)))
    bad_cap = metadata(1000)
    bad_cap['max_length_m'] = 4.5
    invalids.append(('reject_inconsistent_declared_cap', lambda: sizing_limits(bad_cap)))
    for label, invoke in invalids:
        try:
            invoke()
        except (AssertionError, KeyError, ValueError):
            passed.append(label)
        else:
            raise AssertionError(label+' unexpectedly accepted')
    return passed


def validate_panels(panels, caps):
    failures, counts = [], Counter()
    max_area_error = total_area = max_planar_height = 0.
    nearplanar_examples = []
    for raw in panels:
        try:
            result = check(raw, *caps)
            counts['checked_panels'] += 1
            total_area += result['area']
            max_area_error = max(max_area_error, result['area_error_m2'])
            if result['below_nominal_min_width']:
                counts['below_nominal_min_width'] += 1
            if result['planar']:
                counts['bridge_planar_panels'] += 1
                counts['planar_fitted_by_'+result['fitted_by']] += 1
                max_planar_height = max(max_planar_height, result['first_plane_deviation_m'])
                if result['engine_curved']:
                    counts['engine_curved_but_bridge_planar'] += 1
                    if len(nearplanar_examples) < 12:
                        nearplanar_examples.append(dict(id=raw['id'], engine_svd_nonplanarity_mm=raw['nonplanarity_mm'],
                            bridge_first_face_deviation_mm=result['first_plane_deviation_m']*1000))
            else:
                counts['bridge_curved_panels'] += 1
        except (AssertionError, ValueError, KeyError) as exc:
            failures.append(dict(id=raw.get('id'), error=str(exc), nonplanarity_mm=raw.get('nonplanarity_mm')))
    return dict(all_passed=not failures, selected_max_width_m=caps[0], selected_max_length_m=caps[1],
                expected_panel_count=len(panels), counts=dict(counts), total_newell_area_m2=total_area,
                max_panel_area_error_m2=max_area_error, max_bridge_planar_first_face_deviation_mm=max_planar_height*1000,
                nearplanar_examples=nearplanar_examples, failed_panels=len(failures), failures=failures)


def main():
    data = json.loads(EXPORT.read_text())
    assert data['format']=='roof-panels-1' and data['unit']=='m'
    assert isinstance(data['panels'], list) and 0 < len(data['panels']) <= 300000
    assert len(set(p['id'] for p in data['panels']))==len(data['panels']), 'duplicate ID'
    fixtures = fixture_cases()
    report = validate_panels(data['panels'], sizing_limits(data))
    report.update(format='roof-bridge-numeric-validation-2',
                  method='Python numerical mirror of V4 Ruby canonical_panel and sizing_limits; no SketchUp runtime execution',
                  bridge_sha256=hashlib.sha256(BRIDGE.read_bytes()).hexdigest(),
                  export_sha256=hashlib.sha256(EXPORT.read_bytes()).hexdigest(),
                  export_file=EXPORT.name, sizing_rule=data['sizing_rule'], fixture_cases_passed=fixtures,
                  supplemental_template_checks=[])
    for width in (500, 873, 1000, 1500):
        path = Path('/tmp/v4-validation-%d.json' % width)
        if path.exists():
            template = json.loads(path.read_text())
            panels = template['candidates'][0]['panels']
            result = validate_panels(panels, (width/1000., width*3./1000.))
            result.update(nominal_width_mm=width, input_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                          scope='All local template panels before eight instance world transforms')
            report['supplemental_template_checks'].append(result)
            report['all_passed'] = report['all_passed'] and result['all_passed']
    (ROOT / 'bridge_numeric_validation.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k not in ('failures','nearplanar_examples','supplemental_template_checks')}, ensure_ascii=False))
    for result in report['supplemental_template_checks']:
        print(json.dumps({k:v for k,v in result.items() if k not in ('failures','nearplanar_examples')}, ensure_ascii=False))
    if not report['all_passed']:
        print(json.dumps(report['failures'][:20], ensure_ascii=False, indent=2))
        raise SystemExit(1)


if __name__ == '__main__':
    main()

