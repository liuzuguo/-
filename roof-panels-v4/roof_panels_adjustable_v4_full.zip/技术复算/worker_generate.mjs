#!/usr/bin/env node
/** Run the real browser geometry worker in a Node VM for independent validation.
 *
 * Example:
 * node worker_generate.mjs --width 873 --output validation_reports/873.json
 */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import crypto from 'node:crypto';
import { performance } from 'node:perf_hooks';
import { fileURLToPath } from 'node:url';

const root = path.dirname(fileURLToPath(import.meta.url));
const args = process.argv.slice(2);
const options = {};
for (let i = 0; i < args.length; i++) {
  if (!args[i].startsWith('--') || i + 1 >= args.length) {
    throw new Error(`Expected --name value, received ${args[i]}`);
  }
  options[args[i].slice(2)] = args[++i];
}
const widthMm = Number(options.width ?? 1000);
if (!Number.isInteger(widthMm) || widthMm < 500 || widthMm > 1500) {
  throw new Error('Width must be an integer from 500 to 1500 mm');
}
function fallbackFile(name) {
  const local = path.join(root, name);
  return fs.existsSync(local) ? local : path.join(root, '..', 'roof-panel-studio-v3', name);
}
const sourcePath = options.source ?? fallbackFile('modelData.json');
const uvPath = options.uv ?? fallbackFile('source_uv_complete.json');
const workerPath = options.worker ?? path.join(root, 'panel-worker.js');
const outputPath = options.output ?? path.join(root, 'validation_reports', `${widthMm}.json`);
const source = JSON.parse(fs.readFileSync(sourcePath, 'utf8'));
const sourceUv = JSON.parse(fs.readFileSync(uvPath, 'utf8'));
const uv = Array.isArray(sourceUv) ? sourceUv : sourceUv.uv;
const workerCode = fs.readFileSync(workerPath, 'utf8');
const workerSha256 = crypto.createHash('sha256').update(workerCode).digest('hex');
const started = performance.now();
const requestId = `validation-${widthMm}`;

let resolveResult;
let rejectResult;
const resultPromise = new Promise((resolve, reject) => {
  resolveResult = resolve;
  rejectResult = reject;
});
let lastProgress = '';
const sandbox = {
  console,
  performance,
  setTimeout,
  clearTimeout,
  setInterval,
  clearInterval,
  structuredClone,
  TextEncoder,
  TextDecoder,
  postMessage(message) {
    if (message.type === 'result') {
      if (message.requestId !== requestId) {
        rejectResult(new Error(`Wrong worker requestId: ${message.requestId}`));
      } else {
        resolveResult(message.candidate);
      }
    } else if (message.type === 'error') {
      rejectResult(new Error(message.error ?? message.message ?? JSON.stringify(message)));
    } else if (message.type === 'progress') {
      // Keep the generation log concise, without changing the real worker.
      const progress = message.phase ?? message.stage ?? message.message ?? '';
      if (progress !== lastProgress) {
        process.stderr.write(`${JSON.stringify(message)}\n`);
        lastProgress = progress;
      }
    }
  },
};
sandbox.self = sandbox;
const context = vm.createContext(sandbox);
vm.runInContext(workerCode, context, { filename: workerPath });
if (typeof context.onmessage !== 'function') {
  throw new Error('The worker did not install an onmessage handler');
}
const input = {
  type: 'generate', requestId, widthMm,
  model: { ...source.variants['0'], uv, instances: source.instances },
};
try {
  await context.onmessage({ data: input });
} catch (error) {
  rejectResult(error);
}
const candidate = await resultPromise;
if (!candidate || !Array.isArray(candidate.panels) || !candidate.panels.length) {
  throw new Error('The worker returned no panel geometry');
}
const generationSeconds = (performance.now() - started) / 1000;
const data = {
  format: 'roof-panel-dynamic-study-4',
  unit: 'm',
  max_width_m: widthMm / 1000,
  max_length_m: widthMm * 3 / 1000,
  crease_angle_deg: 10,
  layout: { source_uv: uv },
  instances: source.instances,
  center: source.center,
  targetZ: source.targetZ,
  recommended_id: candidate.id,
  candidates: [candidate],
  validation_generation: {
    selected_width_mm: widthMm,
    worker_sha256: workerSha256,
    generation_seconds: generationSeconds,
    generated_at: new Date().toISOString(),
    implementation: 'Real browser worker executed unchanged in a Node VM',
  },
};
fs.mkdirSync(path.dirname(outputPath), { recursive: true });
fs.writeFileSync(outputPath, JSON.stringify(data));
process.stdout.write(`${JSON.stringify({
  width_mm: widthMm,
  length_mm: widthMm * 3,
  template_panels: candidate.panels.length,
  template_types: candidate.types?.length,
  full_panels: candidate.summary?.panel_count,
  surface_area_m2: candidate.summary?.surface_area_m2,
  generation_seconds: generationSeconds,
  worker_sha256: workerSha256,
  bytes: fs.statSync(outputPath).size,
  output: outputPath,
})}\n`);
