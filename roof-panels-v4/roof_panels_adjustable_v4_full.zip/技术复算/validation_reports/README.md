# 动态分隔几何验证

`../dynamic_geometry_validation.json` 汇总 500、873、1000、1500 mm 四个任意整数宽度设置的独立检查；对应长度分别为 1500、2619、3000、4500 mm。

测试直接执行正式 `panel-worker.js`，没有使用预设宽度的模型。检查器不导入分隔引擎，而从输出三角形重新核算原始曲面与 UV 来源、每个原始三角片的完整覆盖、面积、尺寸上限、平面板矩形包络、折线约束和数量统计。它也逐块检查 8 个实例的真实变换面积。

复现单个设置（需要 Node.js、Python、NumPy、Shapely）：

```bash
node worker_generate.mjs --width 873 --output /tmp/roof-873.json
python validate_dynamic_geometry.py --data /tmp/roof-873.json --output validation_reports/873_report.json
```

500–1500 mm 是尺寸调节器的名义宽度范围。曲面分带、边界和折线裁切后的实际板件可以更小；报告明确记录小于 500 mm 的实际板件数量。报告没有把名义最小值当成每块成品的最小值保证。

这些是几何与数值检查；SketchUp 的导入行为由交付包中的 Ruby 桥接器及其专项检查覆盖。
