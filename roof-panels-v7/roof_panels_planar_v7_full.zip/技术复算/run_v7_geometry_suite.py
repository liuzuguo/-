"""Run final unchanged V7 worker outputs through independent geometry checks."""
from pathlib import Path
import concurrent.futures
import datetime
import hashlib
import json
import subprocess

ROOT=Path(__file__).resolve().parent
REPORTS=ROOT/'validation_reports'
CASES=[(1000,3000,None),(2500,6000,None),(400,6000,None),
       (2500,6875,2.75),(5000,3000,None)]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check_case(case):
    width,length,ratio=case
    name=f'v7-{width}x{length}'+('-ratio' if ratio else '')
    data=REPORTS/(name+'.json')
    report=REPORTS/(name+'_report.json')
    args=['node','worker_generate.mjs','--width',str(width),'--length',str(length),
          '--output',str(data)]
    if ratio:
        args += ['--ratio',str(ratio)]
    with (REPORTS/(name+'_generation.log')).open('w') as log:
        subprocess.run(args,cwd=ROOT,check=True,stdout=log,stderr=log)
    with (REPORTS/(name+'_validation.log')).open('w') as log:
        subprocess.run(['python3','validate_dynamic_geometry_v7.py','--data',str(data),
                        '--output',str(report)],cwd=ROOT,check=True,stdout=log,stderr=log)
    result=json.loads(report.read_text())
    assert result['all_passed']
    record=result['candidates'][0]
    record['data_file']=data.name
    record['data_sha256']=sha(data)
    record['report_file']=report.name
    record['report_sha256']=sha(report)
    return record


def main():
    REPORTS.mkdir(exist_ok=True)
    worker=sha(ROOT/'panel-worker.js')
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
        cases=list(executor.map(check_case,CASES))
    assert worker==sha(ROOT/'panel-worker.js'),'Worker changed during independent validation'
    for case in cases:
        assert case['generation']['worker_sha256']==worker
    subprocess.run(['node','validate_resource_guards_v7.mjs'],cwd=ROOT,check=True,
                   stdout=(REPORTS/'resource_validation.log').open('w'))
    guard=json.loads((ROOT/'resource_guard_validation.json').read_text())
    negative=json.loads((ROOT/'v7_validator_negative_control.json').read_text())
    assert guard['passed'] and guard['worker_sha256']==worker and negative['passed']
    default=json.loads((ROOT/'default-study.json').read_text())
    assert default['validation_generation']['worker_sha256']==worker
    assert default['candidates'][0]['summary']['panel_count']==cases[0]['full_panels']
    report={'format':'roof-panel-dynamic-validation-7-suite','all_passed':True,
            'generated_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'worker_sha256':worker,'validator_sha256':sha(ROOT/'validate_dynamic_geometry_v7.py'),
            'harness_sha256':sha(ROOT/'worker_generate.mjs'),
            'source_model_sha256':sha(ROOT/'modelData.json'),
            'source_uv_sha256':sha(ROOT/'source_uv_complete.json'),
            'checks':['Every plate truly planar from saved XYZ, no bend or folded internal facet',
                      'Paired true panel-change seams agree across all original sharp ridge edges',
                      'Original source XYZ and every source facet fully covered without overlap',
                      'Independent directional size bounds and planar rectangle stock-envelope fit',
                      'All eight exact model transforms and actual world-coordinate areas',
                      'Positive unrestricted dimensions, custom ratio, and directional resource guards',
                      'Negative controls reject actual V6 folded panels and misaligned ridge seams'],
            'cases':cases,'resource_guard_checks':len(guard['checks']),
            'negative_control_checks':negative['checks']}
    (ROOT/'dynamic_geometry_validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
    print(json.dumps({'all_passed':True,'worker_sha256':worker,
                      'cases':[{k:c[k] for k in ['selected_width_mm','selected_length_mm','full_panels',
                                                'max_planarity_deviation_m','ridge_alignment']} for c in cases],
                      'resource_guard_checks':len(guard['checks'])},ensure_ascii=False,indent=2))


if __name__=='__main__':
    main()
