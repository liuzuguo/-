/* Offline, exact-source roof segmentation. No network or external libraries.
 * Constant U follows the supplied fan rays; constant V follows cross rows.
 * V7 creates strictly planar plates from the original planar source facets.
 * Every slope uses one shared U/V grid so ridge joints remain aligned.
 * All new vertices are affine points on the original source triangles.
 * A nominal size is an upper bound, not an assertion that edge pieces are full.
 */
'use strict';

const EPS = 1e-10;
const CREASE_COS = Math.cos(10 * Math.PI / 180);
// This is a memory/work limit, not a fabrication dimension or aspect ratio.
const MAX_WORLD_PANELS = 500000;
const RESOURCE_ERROR = '尺寸过小，预计板块过多；请增大尺寸后重新计算（单次最多 500,000 块实例板）';
const round = (n, digits) => { const s = 10 ** digits; return Math.round(n * s) / s; };
const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const norm = a => Math.hypot(a[0], a[1], a[2]);
const normalize = a => { const n = norm(a); return n > 0 ? a.map(x => x / n) : [0, 0, 1]; };
const area3 = (a, b, c) => norm(cross(sub(b, a), sub(c, a))) * .5;
const uvKey = p => `${Math.round(p[0] * 1e10)},${Math.round(p[1] * 1e10)}`;

function polygonArea(poly) {
  let a = 0;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) a += poly[j][0] * poly[i][1] - poly[i][0] * poly[j][1];
  return Math.abs(a) * .5;
}

function clipSide(poly, axis, bound, above) {
  if (poly.length < 3) return [];
  const out = [], sign = above ? 1 : -1;
  let a = poly[poly.length - 1], da = (a[axis] - bound) * sign;
  for (const b of poly) {
    const db = (b[axis] - bound) * sign;
    if ((da >= -EPS) !== (db >= -EPS)) {
      const t = da / (da - db), p = [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t];
      p[axis] = bound;
      out.push(p);
    }
    if (db >= -EPS) out.push(b);
    a = b; da = db;
  }
  const clean = [];
  for (const p of out) {
    const last = clean[clean.length - 1];
    if (!last || Math.hypot(p[0] - last[0], p[1] - last[1]) > EPS) clean.push(p);
  }
  if (clean.length > 1 && Math.hypot(clean[0][0] - clean[clean.length - 1][0], clean[0][1] - clean[clean.length - 1][1]) < EPS) clean.pop();
  return clean.length >= 3 ? clean : [];
}

function clipRect(poly, r) {
  let p = clipSide(poly, 0, r[0], true);
  p = clipSide(p, 0, r[2], false);
  p = clipSide(p, 1, r[1], true);
  return clipSide(p, 1, r[3], false);
}

function segmentIntersectsRect(a, b, r) {
  let lo = 0, hi = 1;
  for (let axis = 0; axis < 2; axis++) {
    const mn = r[axis], mx = r[axis + 2], d = b[axis] - a[axis];
    if (Math.abs(d) < 1e-12) {
      if (a[axis] < mn - EPS || a[axis] > mx + EPS) return false;
    } else {
      const p = (mn - a[axis]) / d, q = (mx - a[axis]) / d;
      lo = Math.max(lo, Math.min(p, q)); hi = Math.min(hi, Math.max(p, q));
    }
  }
  return hi - lo > 1e-9 && Math.hypot(b[0] - a[0], b[1] - a[1]) * (hi - lo) > 1e-9;
}

function lowerBound(a, value) {
  let lo = 0, hi = a.length;
  while (lo < hi) { const m = (lo + hi) >>> 1; if (a[m] < value) lo = m + 1; else hi = m; }
  return lo;
}
function upperBound(a, value) {
  let lo = 0, hi = a.length;
  while (lo < hi) { const m = (lo + hi) >>> 1; if (a[m] <= value) lo = m + 1; else hi = m; }
  return lo;
}

/* Full critical-angle search for fitting a fixed orthogonal stock rectangle.
 * Merely choosing the minimum-area hull-edge rectangle would miss diagonal fits.
 */
function feasibleRectangle(points, width, length) {
  const wLimit = width + 1e-8, lLimit = length + 1e-8;
  const angles = [0], pi = Math.PI, mod = a => ((a % pi) + pi) % pi;
  for (let i = 0; i < points.length; i++) for (let j = i + 1; j < points.length; j++) {
    const dx = points[j][0] - points[i][0], dy = points[j][1] - points[i][1], r = Math.hypot(dx, dy);
    if (r > Math.hypot(lLimit, wLimit) + 1e-10) return null;
    if (r < 1e-12) continue;
    const alpha = Math.atan2(dy, dx);
    angles.push(mod(alpha), mod(alpha + pi / 2));
    for (let k = 0; k < 2; k++) {
      const limit = k ? wLimit : lLimit;
      if (r > limit) {
        const center = alpha + (k ? pi / 2 : 0), delta = Math.acos(Math.min(1, Math.max(-1, limit / r)));
        angles.push(mod(center - delta), mod(center + delta));
      }
    }
  }
  angles.sort((a, b) => a - b);
  const candidates = angles.slice();
  for (let i = 0; i < angles.length; i++) candidates.push(mod((angles[i] + (i + 1 < angles.length ? angles[i + 1] : angles[0] + pi)) / 2));
  let best = null;
  for (const angle of candidates) {
    const c = Math.cos(angle), s = Math.sin(angle);
    let u0 = Infinity, u1 = -Infinity, v0 = Infinity, v1 = -Infinity;
    for (const p of points) {
      const u = p[0] * c + p[1] * s, v = -p[0] * s + p[1] * c;
      u0 = Math.min(u0, u); u1 = Math.max(u1, u); v0 = Math.min(v0, v); v1 = Math.max(v1, v);
    }
    const du = u1 - u0, dv = v1 - v0;
    if (du <= lLimit + 1e-10 && dv <= wLimit + 1e-10) {
      const short = Math.min(du, dv), long = Math.max(du, dv), axis = du >= dv ? angle : mod(angle + pi / 2);
      if (!best || short * long < best[0] * best[1] - 1e-14 || (Math.abs(short * long - best[0] * best[1]) < 1e-14 && short + long < best[0] + best[1])) best = [short, long, axis];
    }
  }
  return best;
}

/* Jacobi diagonalization of the symmetric 3x3 point covariance matrix. */
function planeBasis(points) {
  const mean = [0, 0, 0];
  for (const p of points) for (let k = 0; k < 3; k++) mean[k] += p[k] / points.length;
  const a = [[0, 0, 0], [0, 0, 0], [0, 0, 0]], v = [[1, 0, 0], [0, 1, 0], [0, 0, 1]];
  for (const p of points) {
    const d = sub(p, mean);
    for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++) a[i][j] += d[i] * d[j];
  }
  for (let iter = 0; iter < 32; iter++) {
    let p = 0, q = 1;
    if (Math.abs(a[0][2]) > Math.abs(a[p][q])) { p = 0; q = 2; }
    if (Math.abs(a[1][2]) > Math.abs(a[p][q])) { p = 1; q = 2; }
    if (Math.abs(a[p][q]) < 1e-16 * Math.max(1, Math.abs(a[0][0]) + Math.abs(a[1][1]) + Math.abs(a[2][2]))) break;
    const phi = .5 * Math.atan2(2 * a[p][q], a[q][q] - a[p][p]), c = Math.cos(phi), s = Math.sin(phi);
    const app = a[p][p], aqq = a[q][q], apq = a[p][q];
    for (let k = 0; k < 3; k++) if (k !== p && k !== q) {
      const akp = a[k][p], akq = a[k][q];
      a[k][p] = a[p][k] = c * akp - s * akq;
      a[k][q] = a[q][k] = s * akp + c * akq;
    }
    a[p][p] = c * c * app - 2 * s * c * apq + s * s * aqq;
    a[q][q] = s * s * app + 2 * s * c * apq + c * c * aqq;
    a[p][q] = a[q][p] = 0;
    for (let k = 0; k < 3; k++) {
      const vp = v[k][p], vq = v[k][q];
      v[k][p] = c * vp - s * vq; v[k][q] = s * vp + c * vq;
    }
  }
  const order = [0, 1, 2].sort((i, j) => a[j][j] - a[i][i]);
  const basis = order.map(i => normalize([v[0][i], v[1][i], v[2][i]]));
  let deviation = 0;
  for (const p of points) deviation = Math.max(deviation, Math.abs(dot(sub(p, mean), basis[2])) * 1000);
  return { mean, basis, deviation };
}

class NeedsSplit extends Error {
  constructor(message, axis = null) { super(message); this.axis = axis; }
}

/* Every finished plate belongs to one original planar source facet. A shared
 * grid is clipped on both sides of every ridge; no local refinement is allowed.
 */
class Study {
  constructor(model, progress) {
    this.p = model.vertices; this.f = model.faces; this.uv = model.uv;
    if (!Array.isArray(this.p) || !Array.isArray(this.f) || !Array.isArray(this.uv) || this.uv.length !== this.p.length || !this.f.length) throw new Error('原始屋面或参数网格不完整');
    for (const p of this.p) if (!Array.isArray(p) || p.length !== 3 || !p.every(Number.isFinite)) throw new Error('原始屋面坐标无效');
    for (const p of this.uv) if (!Array.isArray(p) || p.length !== 2 || !p.every(Number.isFinite)) throw new Error('原始屋面 UV 坐标无效');
    this.progress = progress || (() => {});
    this.instances = Array.isArray(model.instances) && model.instances.length ? model.instances : null;
    this.instanceCount = this.instances ? this.instances.length : Number.isInteger(model.instance_count) && model.instance_count > 0 ? model.instance_count : 8;
    this.cofactors = this.instances ? this.instances.map(instance => {
      const m = instance.matrix;
      if (!Array.isArray(m) || m.length !== 16 || !m.every(Number.isFinite)) throw new Error('屋面实例变换矩阵无效');
      return [cross([m[4], m[5], m[6]], [m[8], m[9], m[10]]), cross([m[8], m[9], m[10]], [m[0], m[1], m[2]]), cross([m[0], m[1], m[2]], [m[4], m[5], m[6]])];
    }) : null;
    this.info = []; this.sourceArea = 0; this.edgeMap = new Map(); this.sharpEdges = [];
    this.umin = Infinity; this.umax = -Infinity; this.vmin = Infinity; this.vmax = -Infinity;
    for (const q of this.uv) { this.umin = Math.min(this.umin, q[0]); this.umax = Math.max(this.umax, q[0]); this.vmin = Math.min(this.vmin, q[1]); this.vmax = Math.max(this.vmax, q[1]); }
    for (let fi = 0; fi < this.f.length; fi++) {
      const face = this.f[fi];
      if (!Array.isArray(face) || face.length !== 3 || !face.every(k => Number.isInteger(k) && k >= 0 && k < this.p.length)) throw new Error('原始三角面索引无效');
      const uv = face.map(k => this.uv[k]), xyz = face.map(k => this.p[k]);
      const a = uv[1][0] - uv[0][0], b = uv[2][0] - uv[0][0], c = uv[1][1] - uv[0][1], d = uv[2][1] - uv[0][1], determinant = a * d - b * c;
      if (determinant <= 1e-12) throw new Error('原始参数域三角面退化或方向错误');
      const e = sub(xyz[1], xyz[0]), g = sub(xyz[2], xyz[0]);
      const ju = e.map((x, k) => (x * d - g[k] * c) / determinant), jv = e.map((x, k) => (-x * b + g[k] * a) / determinant), cr = cross(e, g), magnitude = norm(cr);
      if (!(magnitude > 1e-12)) throw new Error('原始屋面存在退化三角面');
      this.sourceArea += magnitude * .5;
      this.info.push({ju, jv, nu:norm(ju), nv:norm(jv), n:normalize(cr),
        lo:[Math.min(...uv.map(p => p[0])), Math.min(...uv.map(p => p[1]))], hi:[Math.max(...uv.map(p => p[0])), Math.max(...uv.map(p => p[1]))]});
      for (let k = 0; k < 3; k++) {
        const a = face[k], b = face[(k + 1) % 3], key = a < b ? `${a},${b}` : `${b},${a}`;
        if (!this.edgeMap.has(key)) this.edgeMap.set(key, {vertices:[a,b],owners:[]});
        const record = this.edgeMap.get(key); record.owners.push(fi);
        if (record.owners.length > 2) throw new Error('原始屋面存在非流形边');
      }
    }
    for (const edge of this.edgeMap.values()) if (edge.owners.length === 2 && Math.abs(dot(this.info[edge.owners[0]].n, this.info[edge.owners[1]].n)) < CREASE_COS) this.sharpEdges.push(edge);
    this.sharpCount = this.sharpEdges.length;
    this.sourceKnots = Array.from(new Set(this.uv.map(p => p[1]))).sort((a,b) => a-b);
    this.worldArea = this.computeWorldArea();
  }

  computeWorldArea() {
    if (!this.instances) return this.sourceArea * this.instanceCount;
    let area = 0;
    for (const ins of this.instances) {
      const m = ins.matrix, points = this.p.map(q => [m[0]*q[0]+m[4]*q[1]+m[8]*q[2]+m[12],m[1]*q[0]+m[5]*q[1]+m[9]*q[2]+m[13],m[2]*q[0]+m[6]*q[1]+m[10]*q[2]+m[14]]);
      for (const f of this.f) area += area3(points[f[0]],points[f[1]],points[f[2]]);
    }
    return area;
  }

  lift(fi, q) {
    const k = this.f[fi][0], origin = this.p[k], chart = this.uv[k], t = this.info[fi], u = q[0] - chart[0], v = q[1] - chart[1];
    return [origin[0]+t.ju[0]*u+t.jv[0]*v,origin[1]+t.ju[1]*u+t.jv[1]*v,origin[2]+t.ju[2]*u+t.jv[2]*v];
  }

  cuts(width, length) {
    const metricIntegral = axis => {
      const lo = axis ? this.vmin : this.umin, hi = axis ? this.vmax : this.umax;
      const knots = Array.from(new Set([lo,hi,...this.info.flatMap(t => [t.lo[axis],t.hi[axis]])])).sort((a,b) => a-b);
      let value = 0;
      for (let k = 0; k + 1 < knots.length; k++) {
        let bound = 0;
        for (const t of this.info) if (t.hi[axis] > knots[k]+1e-10 && t.lo[axis] < knots[k+1]-1e-10) bound = Math.max(bound,axis ? t.nv : t.nu);
        value += (knots[k+1]-knots[k])*bound;
      }
      return value;
    };
    if (Math.ceil(metricIntegral(0)/(width*.98))*this.instanceCount > MAX_WORLD_PANELS || Math.ceil(metricIntegral(1)/(length*.98))*this.instanceCount > MAX_WORLD_PANELS) throw new Error(RESOURCE_ERROR);
    // Keep every existing integer fan ray. Every roof slope uses these same
    // U cuts and V cuts, so a joint crossing a ridge meets its opposite joint.
    const knots = Array.from(new Set([this.umin,this.umax,...this.uv.map(q => q[0]).filter(u => Math.abs(u-Math.round(u)) < 1e-8).map(Math.round)])).sort((a,b) => a-b);
    const u = [this.umin];
    for (let k = 0; k + 1 < knots.length; k++) {
      const a = knots[k], b = knots[k+1]; let bound = 0;
      for (const t of this.info) if (t.hi[0] > a+1e-9 && t.lo[0] < b-1e-9) bound = Math.max(bound,t.nu);
      const n = Math.max(1,Math.ceil((b-a)*bound/(width*.98)));
      if ((u.length+n)*this.instanceCount > MAX_WORLD_PANELS) throw new Error(RESOURCE_ERROR);
      for (let j = 1; j <= n; j++) u.push(a+(b-a)*j/n);
    }
    const v = [this.vmin], minNorm = Math.min(...this.info.map(t => t.nv));
    while (v[v.length-1] < this.vmax-1e-9) {
      const start = v[v.length-1]; let lo = start, hi = Math.min(this.vmax,start+length/minNorm);
      for (let k = 0; k < 45; k++) {
        const end = (lo+hi)/2; let bound = 0;
        for (const t of this.info) if (t.hi[1] > start+1e-9 && t.lo[1] < end-1e-9) bound = Math.max(bound,t.nv);
        if ((end-start)*bound <= length*.98) lo = end; else hi = end;
      }
      let end = lo > this.vmax-1e-8 ? this.vmax : lo;
      for (const knot of this.sourceKnots) if (Math.abs(knot-end) < 1e-7) { end = knot; break; }
      if (end-start < 1e-8) throw new Error('共用分缝网格未推进');
      v.push(end);
      if ((u.length-1)*(v.length-1)*this.instanceCount > MAX_WORLD_PANELS) throw new Error(RESOURCE_ERROR);
    }
    return [u,v];
  }

  makeFlatPanel(fi, poly, grid, rect, width, length) {
    // Lift to exactly one source plane. Serialization is performed before
    // triangulation so no zero-area exported face survives rounding.
    const uv = [], vertices = [];
    for (const p of poly) {
      const xyz = this.lift(fi,p).map(x => round(x,9));
      if (vertices.length && norm(sub(xyz,vertices[vertices.length-1])) < 1e-10) continue;
      uv.push(p); vertices.push(xyz);
    }
    if (vertices.length > 2 && norm(sub(vertices[0],vertices[vertices.length-1])) < 1e-10) { vertices.pop(); uv.pop(); }
    if (vertices.length < 3) return null;
    const faces = [];
    for (let i = 1; i + 1 < vertices.length; i++) if (area3(vertices[0],vertices[i],vertices[i+1]) > 1e-11) faces.push([0,i,i+1]);
    if (!faces.length) return null;
    faces.sort((a,b) => area3(vertices[b[0]],vertices[b[1]],vertices[b[2]])-area3(vertices[a[0]],vertices[a[1]],vertices[a[2]]));
    let area = 0; const worldAreas = this.cofactors ? this.cofactors.map(() => 0) : null;
    for (const f of faces) {
      const cr = cross(sub(vertices[f[1]],vertices[f[0]]),sub(vertices[f[2]],vertices[f[0]])); area += norm(cr)*.5;
      if (worldAreas) for (let k = 0; k < this.cofactors.length; k++) { const c = this.cofactors[k]; worldAreas[k] += Math.hypot(c[0][0]*cr[0]+c[1][0]*cr[1]+c[2][0]*cr[2],c[0][1]*cr[0]+c[1][1]*cr[1]+c[2][1]*cr[2],c[0][2]*cr[0]+c[1][2]*cr[1]+c[2][2]*cr[2])*.5; }
    }
    if (area < 1e-10) return null;
    const first = faces[0], anchor = vertices[first[0]], normal = normalize(cross(sub(vertices[first[1]],anchor),sub(vertices[first[2]],anchor)));
    const firstDeviation = Math.max(...vertices.map(p => Math.abs(dot(sub(p,anchor),normal))));
    if (firstDeviation > 1e-7) throw new Error('平板共面校核未通过');
    const fit = planeBasis(vertices), projected = vertices.map(p => {const d = sub(p,fit.mean);return [dot(d,fit.basis[0]),dot(d,fit.basis[1])];});
    const box = feasibleRectangle(projected,Math.min(width,length)-1e-6,Math.max(width,length)-1e-6);
    if (!box) throw new NeedsSplit('平板矩形包络',width >= length ? 0 : 1);
    const us = uv.map(p => p[0]), vs = uv.map(p => p[1]), u0 = Math.min(...us), u1 = Math.max(...us), v0 = Math.min(...vs), v1 = Math.max(...vs);
    const du = (u1-u0)*this.info[fi].nu, dv = (v1-v0)*this.info[fi].nv;
    if (du > width-1e-7 || dv > length-1e-7) throw new NeedsSplit('平板方向尺寸',du/width >= dv/length ? 0 : 1);
    // Classify actual physical boundary corners, ignoring merely collinear
    // tessellation points. A four-sided plate is not automatically rectangular.
    const corners = [];
    for (let i = 0; i < vertices.length; i++) {
      const a = sub(vertices[i],vertices[(i+vertices.length-1)%vertices.length]), b = sub(vertices[(i+1)%vertices.length],vertices[i]);
      if (norm(cross(a,b)) > 1e-8*norm(a)*norm(b)) corners.push(i);
    }
    const count = corners.length;
    let rectangle = count === 4;
    if (rectangle) for (let i = 0; i < count; i++) { const a = normalize(sub(vertices[corners[(i+count-1)%count]],vertices[corners[i]])), b = normalize(sub(vertices[corners[(i+1)%count]],vertices[corners[i]])); if (Math.abs(dot(a,b)) > 1e-7) rectangle = false; }
    const [bw,bl,angle] = box, c = Math.cos(angle), s = Math.sin(angle), a = fit.basis[0], b = fit.basis[1];
    return {id:'',type_id:'',vertices,uv_vertices:uv.map(p => p.map(x => round(x,12))),faces, outlines:[vertices],
      area_m2:area,world_areas_m2:worldAreas||Array(this.instanceCount).fill(area),
      width_m:round(Math.max(Math.min(du,dv),bw),9),length_m:round(Math.max(Math.max(du,dv),bl),9),
      planar_box_width_m:round(bw,9),planar_box_length_m:round(bl,9),planar_box_axes:[a.map((x,k) => x*c+b[k]*s),a.map((x,k) => -x*s+b[k]*c)],
      surface_width_bound_m:round(Math.min(du,dv),9),surface_length_bound_m:round(Math.max(du,dv),9),surface_u_bound_m:round(du,9),surface_v_bound_m:round(dv,9),
      kind:'planar',nonplanarity_mm:round(firstDeviation*1000,9),first_face_deviation_mm:firstDeviation*1000,source_face_ids:[fi],source_face_count:1,planar_patch_id:fi,
      grid:grid.slice(),uv_bounds:[u0,v0,u1,v1].map(x => round(x,12)),uv_area:round(polygonArea(uv),12),
      dimension_method:'max_source_uv_path_and_feasible_orthogonal_planar_box',
      layout_shape:count===3?'planar_triangle':count===4?'planar_quad':'planar_polygon',corner_count:count,is_rectangle:rectangle,is_surface_rectangle:false,
      needs_bend:false,crease_count:0,fabrication_shape:'flat_planar_polygon',ridge_seams_aligned:true};
  }

  ridgeAlignment(panels) {
    const byFace = this.f.map(() => []);
    panels.forEach((p,i) => byFace[p.source_face_ids[0]].push([p,i]));
    const records = []; let mismatches = 0, segments = 0, stations = 0;
    for (const edge of this.sharpEdges) {
      const a = this.uv[edge.vertices[0]], b = this.uv[edge.vertices[1]], d = [b[0]-a[0],b[1]-a[1]], l2 = d[0]*d[0]+d[1]*d[1];
      const sideIntervals = edge.owners.map(fi => {
        const out = [];
        for (const [p,pi] of byFace[fi]) {
          const ts = [];
          for (const q of p.uv_vertices) {
            const x = q[0]-a[0], y = q[1]-a[1], t = (x*d[0]+y*d[1])/l2;
            if (t >= -1e-8 && t <= 1+1e-8 && Math.abs(d[0]*y-d[1]*x) <= 2e-9*Math.sqrt(l2)) ts.push(Math.max(0,Math.min(1,t)));
          }
          if (ts.length >= 2) {const lo = Math.min(...ts),hi = Math.max(...ts);if (hi-lo > 1e-9) out.push([lo,hi,pi]);}
        }
        return out.sort((x,y) => x[0]-y[0]||x[1]-y[1]);
      });
      const [left,right] = sideIntervals; let okay = left.length===right.length && left.length>0;
      if (okay) for (let i = 0; i < left.length; i++) if (Math.abs(left[i][0]-right[i][0]) > 1e-8 || Math.abs(left[i][1]-right[i][1]) > 1e-8) okay=false;
      if (!okay) mismatches++;
      segments += Math.max(left.length,right.length); stations += Math.max(0,Math.max(left.length,right.length)-1);
      records.push({vertices:edge.vertices.slice(),source_faces:edge.owners.slice(),aligned:okay,
        side_intervals:left.map(q => q.slice(0,2).map(x => round(x,12))),opposite_intervals:right.map(q => q.slice(0,2).map(x => round(x,12)))});
    }
    return {method:'actual_panel_change_intervals_on_both_source_ridge_slopes',tolerance_m:1e-7,
      checked_ridge_edges:this.sharpEdges.length,paired_ridge_segments:segments,paired_internal_seam_stations:stations,mismatched_ridge_edges:mismatches,edges:records};
  }

  solve(widthMm, lengthMm) {
    const width = widthMm/1000, length = lengthMm/1000;
    if (Math.ceil(this.sourceArea/(width*length))*this.instanceCount > MAX_WORLD_PANELS) throw new Error(RESOURCE_ERROR);
    let [uc,vc] = this.cuts(width,length), refinements = 0, uRefinements = 0, vRefinements = 0, panels;
    // A feasibility refinement is inserted into the entire shared grid. It is
    // never applied to only one slope/one plate, which would stagger ridge seams.
    for (let pass = 0; pass < 12; pass++) {
      panels = []; const addU = new Set(), addV = new Set();
      if ((uc.length-1)*(vc.length-1)*this.instanceCount > MAX_WORLD_PANELS) throw new Error(RESOURCE_ERROR);
      this.progress({stage:'grid',progress:4,message:`生成 ${uc.length-1} × ${vc.length-1} 共用对缝网格，逐平面分板`});
      for (let fi = 0; fi < this.f.length; fi++) {
        const tri = this.f[fi].map(k => this.uv[k]), info = this.info[fi];
        const i0 = Math.max(0,upperBound(uc,info.lo[0])-1), i1 = Math.min(uc.length-2,lowerBound(uc,info.hi[0]));
        const j0 = Math.max(0,upperBound(vc,info.lo[1])-1), j1 = Math.min(vc.length-2,lowerBound(vc,info.hi[1]));
        for (let i = i0; i <= i1; i++) for (let j = j0; j <= j1; j++) {
          const rect = [uc[i],vc[j],uc[i+1],vc[j+1]], poly = clipRect(tri,rect);
          if (poly.length < 3 || polygonArea(poly) <= 1e-12) continue;
          try {
            const panel = this.makeFlatPanel(fi,poly,[i,j],rect,width,length);
            if (panel) {panels.push(panel);if (panels.length*this.instanceCount > MAX_WORLD_PANELS) throw new Error(RESOURCE_ERROR);}
          } catch (e) {
            if (!(e instanceof NeedsSplit)) throw e;
            const axis = e.axis===0?0:1;
            if (axis===0) addU.add((rect[0]+rect[2])/2); else addV.add((rect[1]+rect[3])/2);
          }
        }
        if (fi%128===0) this.progress({stage:'planes',progress:5+Math.round(fi/this.f.length*80),message:`平板/对缝校核 ${fi.toLocaleString()} / ${this.f.length.toLocaleString()}`});
      }
      if (!addU.size && !addV.size) break;
      if (pass===11) throw new Error('平板包络对缝全局细分未收敛');
      refinements += addU.size+addV.size; uRefinements += addU.size; vRefinements += addV.size;
      uc = Array.from(new Set([...uc,...addU])).sort((a,b) => a-b); vc = Array.from(new Set([...vc,...addV])).sort((a,b) => a-b);
    }
    let area=0,maxW=0,maxL=0,maxSU=0,maxSV=0,maxSW=0,maxSL=0,maxDev=0,minArea=Infinity,triangleCount=0,small=0,below500=0;
    const types = [];
    for (let i = 0; i < panels.length; i++) {
      const p = panels[i], id = String(i+1).padStart(5,'0');p.id=`P${id}`;p.type_id=`T${widthMm}x${lengthMm}-${id}`;
      types.push({id:p.type_id,representative:p.id,width_m:p.width_m,length_m:p.length_m,area_m2:p.area_m2,kind:'planar',nonplanarity_mm:p.nonplanarity_mm,template_count:1,handed:false,shape_signature:`source-flat-grid-${widthMm}x${lengthMm}-${i+1}`});
      area+=p.area_m2;maxW=Math.max(maxW,p.width_m);maxL=Math.max(maxL,p.length_m);maxSU=Math.max(maxSU,p.surface_u_bound_m);maxSV=Math.max(maxSV,p.surface_v_bound_m);maxSW=Math.max(maxSW,p.surface_width_bound_m);maxSL=Math.max(maxSL,p.surface_length_bound_m);maxDev=Math.max(maxDev,p.first_face_deviation_mm);minArea=Math.min(minArea,p.area_m2);triangleCount+=p.faces.length;if(p.area_m2<.05)small++;if(p.width_m<.5)below500++;
    }
    if (Math.abs(area-this.sourceArea)>1e-5) throw new Error(`原始屋面面积守恒校核未通过：${area-this.sourceArea} m²`);
    const alignment = this.ridgeAlignment(panels);
    if (alignment.mismatched_ridge_edges) throw new Error(`褶皱顶边存在未对齐分缝：${alignment.mismatched_ridge_edges} 条`);
    const n=this.instanceCount, quads=panels.filter(p=>p.corner_count===4).length, triangles=panels.filter(p=>p.corner_count===3).length;
    const summary={template_panel_count:panels.length,panel_count:panels.length*n,type_count:types.length,handed_type_count:types.length,
      surface_area_m2:this.worldArea,template_surface_area_m2:area,area_error_m2:area-this.sourceArea,max_width_m:maxW,max_length_m:maxL,
      max_nonplanarity_mm:maxDev,max_first_face_deviation_mm:maxDev,planarity_tolerance_mm:0.0001,min_panel_area_m2:minArea,
      max_surface_width_bound_m:maxSW,max_surface_length_bound_m:maxSL,max_surface_u_bound_m:maxSU,max_surface_v_bound_m:maxSV,
      curved_panel_count:0,needs_bend_panel_count:0,planar_panel_count:panels.length*n,strict_planar_panel_count:panels.length*n,triangle_count:triangleCount*n,
      planar_quad_panel_count:quads*n,planar_triangle_panel_count:triangles*n,planar_polygon_panel_count:(panels.length-quads-triangles)*n,
      rectangle_panel_count:panels.filter(p=>p.is_rectangle).length*n,surface_rectangle_panel_count:0,boundary_trim_panel_count:0,
      small_panel_count:small*n,below_500mm_panel_count:below500*n,crease_edge_count_per_template:this.sharpCount,
      ridge_edge_count:this.sharpCount*n,ridge_seam_count:alignment.paired_ridge_segments*n,ridge_internal_seam_station_count:alignment.paired_internal_seam_stations*n,ridge_misalignment_count:0,
      repeat_ratio:1-types.length/(panels.length*n),transverse_local_refinements:0,global_grid_refinements:refinements,
      nominal_width_mm:widthMm,nominal_length_mm:lengthMm,selected_nominal_width_mm:widthMm,selected_nominal_length_mm:lengthMm,
      selected_max_width_m:Math.min(width,length),selected_max_length_m:Math.max(width,length),selected_max_u_m:width,selected_max_v_m:length,
      u_local_refinements:0,v_local_refinements:0,u_global_refinements:uRefinements,v_global_refinements:vRefinements,max_world_panel_count:MAX_WORLD_PANELS,
      family_grouping:'conservative_exact_source_flat_location',dimension_grouping_is_geometry_identity:false};
    this.progress({stage:'complete',progress:100,message:`完成 ${summary.panel_count.toLocaleString()} 块平板，褶皱顶边对缝一致`});
    return {id:`flat-aligned-${widthMm}x${lengthMm}`,name:`平板对缝 · ${widthMm} × ${lengthMm}`,nominal_width_m:width,nominal_length_m:length,
      panels,types,summary,ridge_alignment:alignment,geometry_rule:{panels:'planar',planarity_tolerance_mm:0.0001,ridge_seams:'aligned'},
      grid:{layout:'global_aligned_grid_clipped_to_source_planes',u_cuts:uc,v_cuts:vc,transverse_local_refinements:0,u_local_refinements:0,v_local_refinements:0,global_grid_refinements:refinements}};
  }
}

function generate(data, progress) {
  if (!data || !Number.isInteger(data.widthMm) || data.widthMm < 1 || data.widthMm > 1e9) throw new Error('宽度必须是大于 0 且不超过 1,000,000,000 mm 的整数');
  if (!Number.isInteger(data.lengthMm) || data.lengthMm < 1 || data.lengthMm > 1e9) throw new Error('长度必须是大于 0 且不超过 1,000,000,000 mm 的整数');
  return new Study(data.model || {}, progress).solve(data.widthMm, data.lengthMm);
}

if (typeof self !== 'undefined' && typeof self.postMessage === 'function') {
  self.onmessage = event => {
    const data = event.data || {}; if (data.type !== 'generate') return;
    try {
      const candidate = generate(data, p => self.postMessage({ type: 'progress', requestId: data.requestId, ...p }));
      self.postMessage({ type: 'result', requestId: data.requestId, candidate });
    } catch (error) { self.postMessage({ type: 'error', requestId: data.requestId, message: error && error.message ? error.message : String(error) }); }
  };
}
if (typeof module !== 'undefined' && module.exports) module.exports = { generate, Study, feasibleRectangle, planeBasis, clipRect };
