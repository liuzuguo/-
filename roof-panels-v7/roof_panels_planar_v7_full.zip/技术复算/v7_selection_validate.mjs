import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';

const source = fs.readFileSync(new URL('./renderer-v7.js', import.meta.url), 'utf8');
const identity = [1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1];
const panel = (type,w,l) => ({type_id:type,width_m:w,length_m:l,area_m2:w*l,nonplanarity_mm:0,
 vertices:[[0,0,0],[w,0,0],[w,l,0],[0,l,0]],faces:[[0,1,2],[0,2,3]],
 outlines:[[[0,0,0],[w,0,0],[w,l,0],[0,l,0]]]});
const panels=[panel('shape-A',1,2),panel('shape-B',1,2),panel('shape-C',1.00001,2),panel('shape-D',.999999999,2)];
const original={center:[0,0,0],instances:Array.from({length:8},(_,k)=>({matrix:k%2?[-1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1]:identity}))};
const world=original.instances.flatMap((ins,k)=>panels.map((p,j)=>({...p,index:k*panels.length+j,instance:k,template:j,roof_id:'ABCD'[k>>1],colorIndex:j,
 type_id:p.type_id+(k%2?'-R':'-L'),width_m:k===3&&j===0?1.1:p.width_m})));
const controls={roof:{value:'all'}};
const context={console,Float32Array,Uint8Array,Map,Set,Math,Number,String,Array,
 candidate:{panels},original,world,selected:null,typeFilter:null,dirty:false,
 mm:n=>Math.ceil(n*1000-1e-5),curved:p=>false,det:m=>m[0],$:(id)=>controls[id],
 renderDetail:()=>{},renderTable:()=>{}};
vm.createContext(context);
vm.runInContext(source+'\nglobalThis.TestRenderer=Renderer;',context);
const r=Object.create(context.TestRenderer.prototype);let uploads=0;const data=[];
r.buf=(array,stride=20)=>{uploads++;data.push(array);return{count:array.length/stride,bytes:array.byteLength,stride}};
r.dispose=()=>{};r.rebuild();
const same=(p,q)=>context.mm(p.width_m)===context.mm(q.width_m)&&context.mm(p.length_m)===context.mm(q.length_m);
const checkSelection=(index,scope)=>{
 context.selected=world[index];controls.roof.value=scope;
 const state=r.getHighlightState();
 const matches=world.filter(p=>(scope==='all'||p.roof_id===scope)&&same(p,world[index])).map(p=>p.index);
 assert.deepEqual([...state.matchingIndices],matches);
 assert.deepEqual([...state.redIndices],matches.filter(i=>i!==index));
 assert.equal(state.count,matches.length);
 assert.equal(r.selectionState().count,matches.length);
 assert.equal(r.selectionState().others,matches.filter(i=>i!==index).length);
};
for(const scope of ['all','A','B','C','D'])for(let i=0;i<world.length;i++)checkSelection(i,scope);
controls.roof.value='all';context.selected=world[0];
assert(r.getHighlightState().redIndices.includes(1),'Different geometry with equal dimensions must match');
assert(r.getHighlightState().redIndices.includes(4),'Mirrored same dimension plate must match');
assert(!r.getHighlightState().redIndices.includes(12),'Different actual instance size must not match');
assert(!r.getHighlightState().redIndices.includes(2),'Different 1mm upper-bound size must not match');
assert(r.getHighlightState().redIndices.includes(3),'Same 1mm upper-bound size must match');
for(let pi=0;pi<panels.length;pi++)for(let k=0;k<8;k++){
 // Six triangle vertices per panel,20 floats per vertex; test actual uploaded columns.
 assert.equal(data[0][pi*6*20+12+k],r.sizeGroups.get(r.sizeKey(world[k*panels.length+pi])).index);
}
const before=uploads;r.rebuild();assert.equal(uploads,before,'Selection must not upload the mesh again');
context.selected=null;assert.equal(r.getHighlightState().group,-1);assert.equal(r.getHighlightState().count,0);
// Validate 24-bit RGB picking: this reaches the third channel and selects an
// individual instance above the old 16-bit limit.
const bigIndex=70003, selectedBig={index:bigIndex,instance:7,template:0,type_id:'large'};
context.world=Array(bigIndex+1);context.world[bigIndex]=selectedBig;
const pickGL={RGBA:1,UNSIGNED_BYTE:2,readPixels(_x,_y,_w,_h,_fmt,_type,pixel){
 const id=bigIndex+1;pixel[0]=id%256;pixel[1]=Math.floor(id/256)%256;pixel[2]=Math.floor(id/65536);pixel[3]=255;
}};
r.gl=pickGL;r.render=()=>{};r.rebuild=()=>{};
controls.model={width:100,height:100,getBoundingClientRect:()=>({left:0,bottom:100,width:100,height:100})};
assert.equal(r.pick(50,50),bigIndex);assert.equal(context.selected,selectedBig);
assert(source.includes('if (sameSize) C = vec3(.91, .16, .14);'));
assert(source.includes('if (abs(panelIndex - selectedIndex) < .5) C = vec3(1., .53, .12);'));
const report={passed:true,selection_fixtures:32*5,mismatch_instance_dimensions:true,different_geometry_same_size:true,
 mirrored_same_size:true,one_mm_upper_bound_groups:true,uploaded_id_columns:32,selection_reuploads:false,rgb_24bit_picking:true,
 note:'Numerical mapping and picking fixtures; actual browser shader compilation/pixel checks performed separately.'};
fs.writeFileSync(new URL('./v7_selection_validation.json',import.meta.url),JSON.stringify(report,null,2));
console.log(JSON.stringify(report,null,2));
