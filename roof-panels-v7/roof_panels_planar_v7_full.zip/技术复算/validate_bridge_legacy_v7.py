"""Check the V7 bridge's preserved V3–V6 geometry rules on real saved exports."""
from pathlib import Path
import hashlib,json
import validate_bridge_numeric_v7 as v
ROOT=Path(__file__).resolve().parent

def main():
    versions=[('v3','1102e_V3放射分隔.json'),('v4','1102e_V4可调分隔.json'),('v5','1102e_V5自由尺寸分隔.json'),('v6','1102e_V6自由尺寸分隔.json')]
    results=[]
    for version,name in versions:
        p=ROOT.parent/('roof-panel-studio-'+version)/name
        data=json.loads(p.read_text())
        result=v.validate_panels(data['panels'],v.sizing_limits(data),strict_planar=v.geometry_limits(data))
        assert result['all_passed'],result['failures'][:3]
        results.append({'file':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'expected_panel_count':len(data['panels']),'all_passed':result['all_passed'],'failed_panels':result['failed_panels'],'counts':result['counts']})
    report={'format':'roof-bridge-legacy-validation-2','all_passed':all(r['all_passed'] for r in results),'bridge_sha256':hashlib.sha256((ROOT/'sketchup_bridge.rb').read_bytes()).hexdigest(),'method':'Numerical mirror of V7 import preflight on real V3/V4/V5/V6 world-coordinate exports; no SketchUp runtime','legacy_exports':results}
    (ROOT/'bridge_legacy_validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
    print(json.dumps({'all_passed':report['all_passed'],'bridge_sha256':report['bridge_sha256'],'total_panels':sum(r['expected_panel_count'] for r in results),'versions':[r['expected_panel_count'] for r in results]},ensure_ascii=False))

if __name__=='__main__':main()
