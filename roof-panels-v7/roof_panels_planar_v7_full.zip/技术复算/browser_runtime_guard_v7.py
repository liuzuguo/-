"""One negative browser case: bent XYZ cannot pass by claiming planar metadata."""
from pathlib import Path
from functools import partial
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
import threading,json,hashlib
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parent

class QuietHandler(SimpleHTTPRequestHandler):
    def log_message(self,*args): pass


def main():
    server=ThreadingHTTPServer(('127.0.0.1',8054),partial(QuietHandler,directory=str(ROOT)))
    threading.Thread(target=server.serve_forever,daemon=True).start()
    try:
        with sync_playwright() as p:
            browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'])
            page=browser.new_page(viewport={'width':1780,'height':1220});page.set_default_timeout(120000)
            page.goto('http://127.0.0.1:8054/app.html');page.wait_for_function('window.ROOF_PANEL_TEST')
            result=page.evaluate('''()=>{
              const t=ROOF_PANEL_TEST,before=t.candidate,beforeWorld=t.world,fake=structuredClone(before);
              fake.id='intentional-bent-negative-control';
              fake.panels[0].vertices=[[0,0,0],[1,0,0],[1,1,.01],[0,1,0]];
              fake.panels[0].faces=[[0,1,2],[0,2,3]];
              fake.panels[0].kind='planar';fake.panels[0].nonplanarity_mm=0;fake.panels[0].needs_bend=false;
              t.data.candidates.push(fake);let rejected=false,message='';
              try{t.choose(fake.id)}catch(error){rejected=true;message=error.message}
              finally{t.data.candidates=t.data.candidates.filter(c=>c.id!==fake.id)}
              return {rejected,message,unchanged_candidate:t.candidate===before,unchanged_world:t.world===beforeWorld,retained_count:t.world.length};
            }''')
            assert result['rejected'] and result['unchanged_candidate'] and result['unchanged_world'],result
            browser.close()
        report={'passed':True,'actual_xyz_guard_negative_control':result,'html_sha256':hashlib.sha256((ROOT/'app.html').read_bytes()).hexdigest(),'worker_sha256':hashlib.sha256((ROOT/'panel-worker.js').read_bytes()).hexdigest()}
        (ROOT/'browser_runtime_guard_validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
        print(json.dumps(report,ensure_ascii=False,indent=2))
    finally:
        server.shutdown();server.server_close()


if __name__=='__main__':main()
