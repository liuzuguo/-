"""Package the checked V7 flat-plate system with shared ridge seams."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import hashlib,json,shutil

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'releases'

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def package():
    geo=json.loads((ROOT/'dynamic_geometry_validation.json').read_text())
    browser=json.loads((ROOT/'browser_validation.json').read_text())
    bridge=json.loads((ROOT/'bridge_numeric_validation.json').read_text())
    manifest=json.loads((ROOT/'build_manifest.json').read_text())
    assert geo['all_passed'] and bridge['all_passed'] and not browser['errors']
    assert geo['worker_sha256']==manifest['worker_sha256']==browser['worker_sha256']==bridge['worker_sha256']==sha(ROOT/'panel-worker.js')
    assert manifest['html_sha256']==browser['html_sha256']==sha(ROOT/'app.html')
    assert bridge['export_sha256']==sha(ROOT/'1102e_V7平直铝板分隔.json')
    data=json.loads((ROOT/'default-study.json').read_text())
    summary=data['candidates'][0]['summary']
    assert summary['curved_panel_count']==0 and summary['ridge_misalignment_count']==0
    OUT.mkdir(exist_ok=True)
    guide=f'''# 1102e 屋面铝板 V7 · 平直板与褶皱顶边对缝

## 打开

解压后用新版 Edge 或 Chrome 打开根目录 **app.html**。屋面、背景、计算程序和 SketchUp 导入脚本全部内嵌，可离线运行；单独HTML与压缩包内app.html相同。

## 本次两项修改

1. **每块铝板平直，不弯不折。** 沿原模型的实际平面变化拆分，单块不再跨越屋面褶皱或弯曲多个面。实际顶点离平面误差必须小于0.0001mm；网页应用方案和V7桥接导入均检查实际坐标，不能仅靠“平面”标签通过。
2. **褶皱顶边两侧分缝对齐。** 使用统一U/V分格定位，尺寸包络需要细分时全局同步添加切线；两侧在同一位置收缝。独立校核逐段比较两侧真正换板的位置，不以添加一个共线顶点冒充对缝。

原屋面起伏、原坐标和外轮廓保留。原模型四边网格多数不共面，因此保持原屋面又要求每块平直时，必须保留相应的四边形、梯形、三角形或多边形板，不能全部当成平直长方形。V7不再沿用V6“跨原折线保留一整块曲面板”的处理方式。

默认1000×3000mm：全屋面{summary['panel_count']:,}块，全部为平直板，弯折板为0，顶边错缝为0。430段模板褶皱边的两侧分缝均已校核。更细的平面拆分会增加板数，不能将V6的合并曲面板数量直接与V7平板数量等同。

## 保留的尺寸、联选与移动功能

宽、长可分别输入正数，按1mm取整，保留取消1500mm上限后的自由输入。需要联动时勾选“锁定长宽比”，输入 `2.5`、`5:2`、`4:5` 等正比例（长度÷宽度）；改宽带长、改长带宽。取消勾选后恢复独立输入。

输入的宽长是两方向分格及平板矩形包络的上界。因原平面边界和外轮廓裁切，实际单块尺寸可能更小，实际形状不一定为长方形。修改后点击“应用尺寸”，真实重算模型、数量和尺寸。

数值输入保护范围为1–1,000,000,000mm，并非加工规格限制。预计超过500,000块的过小尺寸会提示调整，保留上次成功方案。

点选板橘色、其余同尺寸板红色，模型角标与右侧详情显示总数及其他板数。按实际短边/长边上界，上取整到1mm分组，可包含不同形状的板件；同尺寸不代表同一加工板型。显示范围和数量随屋顶范围更新，可隔离同尺寸组和取消高亮。

保留上下左右移动、长按、1/5/10m步长、回中、单屋顶顶视和截图。移动只改视图，不改变导出坐标。

## 保存、导出与SketchUp

保存V7方案记录长宽、比例锁、自定义比例及相机；可打开V5/V6参数文件，按V7平直对缝规则重算。旧V6曲面板模型不会直接当作V7平板结果载入。

CSV、JSON、DAE均使用当前应用的尺寸及屋顶范围。逐板清单标注平直板形状及实际离平面误差。JSON和DAE保持原模型世界坐标，DAE坐标保留9位小数，避免低精度导出使平板翘曲。

完整包 `示例_2500x6000_平直对缝` 是2500×6000mm的实际导出；网页默认仍是1000×3000mm，其他尺寸请重新应用后导出。

SketchUp桥接新增V7实际平面检查，导入新分组及 `RP_V7平直铝板_顶边对缝` 图层。旧V3–V6格式仍兼容其原有规则，旧版并不因此具有V7的平直保证。导入不会自动删除原屋面或旧分隔。

## 校核与加工边界

独立校核包括每块板实际XYZ共面性、面法向一致、没有板跨源折线、原源三角面的完整覆盖及无重叠、8个实例的真实面积、平面矩形包络尺寸，以及全部430段原褶皱边两侧真实换板位置一致。原屋面净面积约41,612.70m²。

网页、JSON和DAE的实际坐标均已校核；浏览器还验证自由尺寸、比例联动、橘红联选、数量、保存恢复、移动和离线运行。桥接已作Ruby语法及逐板数值预检；本环境未安装SketchUp，未在SketchUp Pro 2018中实机运行。

本系统尚未计入板缝、折边、板厚、搭接、龙骨和开孔，导出用于深化和复核，不是直接下料文件。
'''
    (OUT/'使用说明.md').write_text(guide)
    (OUT/'打开说明.txt').write_text('1102e 屋面铝板 V7\n\n解压后用新版Edge或Chrome打开 app.html。\n每块板均平直，不跨折线折弯；褶皱顶边两侧分缝对齐。\n为保留原屋面，允许必要的梯形、三角形及多边形平板。\n保留长宽自由输入、可选比例锁、橘红同尺寸联选、移动与统计导出。\n',encoding='utf-8-sig')
    shutil.copy2(ROOT/'app.html',OUT/'roof_panels_planar_v7.html')
    for src,dst in [('1102e_V7平直板预览.png','roof_panels_planar_v7_preview.png'),('1102e_V7顶边对缝预览.png','roof_panels_planar_v7_ridge.png'),('1102e_V7同尺寸联选预览.png','roof_panels_planar_v7_selection.png')]:
        shutil.copy2(ROOT/src,OUT/dst)
    basic={'app.html':ROOT/'app.html','使用说明.md':OUT/'使用说明.md','打开说明.txt':OUT/'打开说明.txt','sketchup_bridge.rb':ROOT/'sketchup_bridge.rb','SKETCHUP使用说明.md':ROOT/'SKETCHUP使用说明.md'}
    full=dict(basic)
    for name in ['1102e_V7平直铝板分隔.json','1102e_V7平直铝板分隔.dae','1102e_V7逐板统计.csv']:
        full['示例_2500x6000_平直对缝/'+name]=ROOT/name
    for name in ['1102e_V7平直板预览.png','1102e_V7顶边对缝预览.png','1102e_V7同尺寸联选预览.png']:
        full[name]=ROOT/name
    technical=['app.template.html.txt','renderer-v7.js','panel-worker.js','build_delivery.py','default-study.json',
               'modelData.json','source_uv_complete.json','context_lite.bin.gz','context_lite.meta.json','worker_generate.mjs',
               'planar_rectangle.py','validate_dynamic_geometry_v7.py','run_v7_geometry_suite.py','dynamic_geometry_validation.json',
               'v7_validator_negative_control.json',
               'validate_resource_guards_v7.mjs','resource_guard_validation.json','browser_smoke_v7.py','browser_validation.json',
               'validate_bridge_numeric_v7.py','bridge_numeric_validation.json','bridge_legacy_validation.json',
               'bridge_syntax_validation.json','validate_bridge_legacy_v7.py','v7_selection_validate.mjs','v7_selection_validation.json',
               'build_manifest.json','package_delivery_v7.py','validate_delivery_v7.py',
               'browser_runtime_guard_v7.py','browser_runtime_guard_validation.json']
    for name in technical:full['技术复算/'+name]=ROOT/name
    for p in sorted((ROOT/'validation_reports').glob('*')):
        if p.is_file() and p.name.endswith('_report.json'):full['技术复算/validation_reports/'+p.name]=p
    full['技术复算/geometry-requirements.txt']=ROOT.parent/'roof-panel-studio-v3/geometry-requirements.txt'
    for kind,files in [('web',basic),('full',full)]:
        path=OUT/f'roof_panels_planar_v7_{kind}.zip'
        with ZipFile(path,'w',ZIP_DEFLATED,compresslevel=9) as z:
            for name,p in files.items():
                assert p.is_file(),p
                z.write(p,name)
        with ZipFile(path) as z:assert z.testzip() is None
    checksums=[]
    for p in sorted(OUT.iterdir()):
        if p.is_file() and p.name!='checksums.json':checksums.append({'file':p.name,'bytes':p.stat().st_size,'sha256':sha(p)})
    (OUT/'checksums.json').write_text(json.dumps(checksums,ensure_ascii=False,indent=2))
    print(json.dumps(checksums,ensure_ascii=False,indent=2))

if __name__=='__main__':package()
