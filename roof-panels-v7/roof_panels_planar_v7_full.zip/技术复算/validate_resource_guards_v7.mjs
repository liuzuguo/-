/** Public-input and resource guard tests against the unchanged real V7 worker. */
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
import crypto from 'node:crypto';
const root=path.dirname(fileURLToPath(import.meta.url));
const require=createRequire(import.meta.url);
const {generate}=require(path.join(root,'panel-worker.js'));
const identity=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1];
const model={vertices:[[0,0,0],[1,0,0],[1,1,0],[0,1,0]],faces:[[0,1,2],[0,2,3]],uv:[[0,0],[1,0],[1,1],[0,1]],instances:Array.from({length:8},()=>({matrix:identity.slice()}))};
const checks=[];
function expectReject(widthMm,lengthMm,label,pattern,fixtureModel=model){
  let reason='';
  try{generate({widthMm,lengthMm,model:fixtureModel});}catch(e){reason=String(e.message);}
  if(!reason||pattern&&!pattern.test(reason))throw Error(`Unexpected acceptance/rejection for ${label}: ${reason}`);
  checks.push({label,passed:true,reason});
}
for(const width of [0,-1,.5,500.5,NaN,Infinity,1000000001,'2500',undefined])expectReject(width,3000,`invalid width ${String(width)}`,/宽度/);
for(const length of [0,-1,.5,3000.5,NaN,Infinity,1000000001,'6000',undefined])expectReject(2500,length,`invalid length ${String(length)}`,/长度/);
expectReject(1,1,'tiny size exceeds500000 world-panel resource guard',/过多|500,000/);
for(const [widthMm,lengthMm] of [[2500,6000],[400,6000],[1e9,1e9],[5000,3000],[5000,1]]){
  const result=generate({widthMm,lengthMm,model});
  if(!result?.panels?.length)throw Error('No generated panels');
  const worldCount=result.panels.length*8;
  if(worldCount>500000)throw Error('Resource count exceeded');
  const area=result.panels.reduce((sum,p)=>sum+p.area_m2,0);
  if(Math.abs(area-1)>1e-7)throw Error('Fixture surface not preserved');
  if(result.nominal_width_m!==widthMm/1000||result.nominal_length_m!==lengthMm/1000)throw Error('Input was silently clamped');
  checks.push({label:`accept unrestricted ${widthMm}x${lengthMm}`,passed:true,template_panels:result.panels.length,world_panels:worldCount,area_m2:area});
}
const source=JSON.parse(fs.readFileSync(path.join(root,'modelData.json'),'utf8'));
const uv=JSON.parse(fs.readFileSync(path.join(root,'source_uv_complete.json'),'utf8')).uv;
const realModel={...source.variants['0'],uv,instances:source.instances};
for(const [widthMm,lengthMm] of [[1,1e9],[1e9,1]]){
  const started=performance.now();
  expectReject(widthMm,lengthMm,`real roof directional resource guard ${widthMm}x${lengthMm}`,/过多|500,000/,realModel);
  checks[checks.length-1].elapsed_ms=performance.now()-started;
  if(checks[checks.length-1].elapsed_ms>3000)throw Error('Directional resource guard is not prompt');
}
const report={passed:true,worker_sha256:crypto.createHash('sha256').update(fs.readFileSync(path.join(root,'panel-worker.js'))).digest('hex'),checks};
fs.writeFileSync(path.join(root,'resource_guard_validation.json'),JSON.stringify(report,null,2));
process.stdout.write(JSON.stringify(report,null,2)+'\n');
