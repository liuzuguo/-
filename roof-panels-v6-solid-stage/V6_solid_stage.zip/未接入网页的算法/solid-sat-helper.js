/* Actual solid intersection checks. No roof mesh modification or panel cutting. */
(function (root) {
  'use strict';
  const sub=(a,b)=>[a[0]-b[0],a[1]-b[1],a[2]-b[2]];
  const dot=(a,b)=>a[0]*b[0]+a[1]*b[1]+a[2]*b[2];
  const cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
  const norm=a=>Math.hypot(a[0],a[1],a[2]);
  const unit=a=>{const n=norm(a);return n>1e-14?a.map(x=>x/n):null;};
  const transform=(p,m)=>m?[m[0]*p[0]+m[4]*p[1]+m[8]*p[2]+m[12],m[1]*p[0]+m[5]*p[1]+m[9]*p[2]+m[13],m[2]*p[0]+m[6]*p[1]+m[10]*p[2]+m[14]]:p.slice();
  const boxFaces=[[0,3,2,1],[4,5,6,7],[0,1,5,4],[1,2,6,5],[2,3,7,6],[3,0,4,7]];
  function bounds(vertices) {
    const lo=[Infinity,Infinity,Infinity],hi=[-Infinity,-Infinity,-Infinity];
    for(const p of vertices)for(let d=0;d<3;d++){if(p[d]<lo[d])lo[d]=p[d];if(p[d]>hi[d])hi[d]=p[d];}
    return {lo,hi};
  }
  function makeOBB(panel,matrix) {
    const v=(panel.vertices||panel).map(p=>transform(p,matrix));
    if(v.length!==8)throw Error('OBB requires eight vertices');
    const e=[sub(v[1],v[0]),sub(v[3],v[0]),sub(v[4],v[0])],h=e.map(x=>norm(x)/2),axes=e.map(unit);
    if(axes.some(x=>!x))throw Error('Degenerate cuboid in intersection check');
    const center=[0,0,0];for(const p of v)for(let d=0;d<3;d++)center[d]+=p[d]/8;
    const orthogonality=Math.max(Math.abs(dot(axes[0],axes[1])),Math.abs(dot(axes[0],axes[2])),Math.abs(dot(axes[1],axes[2])));
    return {vertices:v,center,axes,half:h,orthogonality,...bounds(v),kind:'obb'};
  }
  function addAxis(list,a) {
    const u=unit(a);if(!u)return;
    for(const q of list)if(Math.abs(dot(q,u))>1-1e-10)return;
    list.push(u);
  }
  function makeConvex(panel,matrix) {
    const vertices=panel.vertices.map(p=>transform(p,matrix)),faces=panel.solid_faces||panel.rectangular_faces||panel.faces;
    const normals=[],edges=[];let convex=true;
    if(!faces?.length)throw Error('Solid faces required for intersection check');
    for(const f of faces){
      if(f.length<3)continue;
      const a=vertices[f[0]],n=unit(cross(sub(vertices[f[1]],a),sub(vertices[f[2]],a)));if(!n)continue;
      let pos=false,neg=false;for(const p of vertices){const d=dot(sub(p,a),n);if(d>1e-7)pos=true;if(d< -1e-7)neg=true;}
      if(pos&&neg)convex=false;
      addAxis(normals,n);
      for(let i=0;i<f.length;i++)addAxis(edges,sub(vertices[f[(i+1)%f.length]],vertices[f[i]]));
    }
    const center=[0,0,0];for(const p of vertices)for(let d=0;d<3;d++)center[d]+=p[d]/vertices.length;
    return {vertices,center,normals,edges,convex,...bounds(vertices),kind:'convex'};
  }
  function satOBB(a,b,tol) {
    // A nearly orthogonal instance is handled as its exact parallelepiped.
    if(a.orthogonality>1e-8||b.orthogonality>1e-8)return satParallelepiped(a,b,tol);
    const A=a.axes,B=b.axes,ah=a.half,bh=b.half,tv=sub(b.center,a.center),t=A.map(x=>dot(tv,x));
    const r=[[dot(A[0],B[0]),dot(A[0],B[1]),dot(A[0],B[2])],[dot(A[1],B[0]),dot(A[1],B[1]),dot(A[1],B[2])],[dot(A[2],B[0]),dot(A[2],B[1]),dot(A[2],B[2])]];
    const ar=r.map(row=>row.map(Math.abs));let depth=Infinity,axis=null;
    for(let i=0;i<3;i++){
      const overlap=ah[i]+bh[0]*ar[i][0]+bh[1]*ar[i][1]+bh[2]*ar[i][2]-Math.abs(t[i]);
      if(overlap<=tol)return null;if(overlap<depth){depth=overlap;axis=A[i];}
    }
    for(let j=0;j<3;j++){
      const overlap=bh[j]+ah[0]*ar[0][j]+ah[1]*ar[1][j]+ah[2]*ar[2][j]-Math.abs(t[0]*r[0][j]+t[1]*r[1][j]+t[2]*r[2][j]);
      if(overlap<=tol)return null;if(overlap<depth){depth=overlap;axis=B[j];}
    }
    for(let i=0;i<3;i++)for(let j=0;j<3;j++){
      const k=(i+1)%3,l=(i+2)%3,p=(j+1)%3,q=(j+2)%3;
      const len=Math.sqrt(Math.max(0,1-r[i][j]*r[i][j]));if(len<1e-8)continue;
      const overlap=(ah[k]*ar[l][j]+ah[l]*ar[k][j]+bh[p]*ar[i][q]+bh[q]*ar[i][p]-Math.abs(t[l]*r[k][j]-t[k]*r[l][j]))/len;
      if(overlap<=tol)return null;if(overlap<depth){depth=overlap;axis=unit(cross(A[i],B[j]));}
    }
    return {penetration_m:depth,axis};
  }
  function satParallelepiped(a,b,tol) {
    if(!a.normals)a.normals=[unit(cross(a.axes[1],a.axes[2])),unit(cross(a.axes[2],a.axes[0])),unit(cross(a.axes[0],a.axes[1]))];
    if(!b.normals)b.normals=[unit(cross(b.axes[1],b.axes[2])),unit(cross(b.axes[2],b.axes[0])),unit(cross(b.axes[0],b.axes[1]))];
    const axes=[...a.normals,...b.normals],delta=sub(b.center,a.center);let depth=Infinity,axis=null;
    for(const x of a.axes)for(const y of b.axes){const n=unit(cross(x,y));if(n)axes.push(n);}
    for(const n of axes){
      let radius=0;for(let d=0;d<3;d++)radius+=a.half[d]*Math.abs(dot(a.axes[d],n))+b.half[d]*Math.abs(dot(b.axes[d],n));
      const overlap=radius-Math.abs(dot(delta,n));if(overlap<=tol)return null;
      if(overlap<depth){depth=overlap;axis=n;}
    }
    return {penetration_m:depth,axis};
  }
  function obbVertices(b) {
    if(b.vertices)return b.vertices;
    const v=[];
    for(const signs of [[-1,-1,-1],[1,-1,-1],[1,1,-1],[-1,1,-1],[-1,-1,1],[1,-1,1],[1,1,1],[-1,1,1]]){
      const p=b.center.slice();for(let e=0;e<3;e++)for(let d=0;d<3;d++)p[d]+=signs[e]*b.half[e]*b.axes[e][d];v.push(p);
    }
    return v;
  }
  function asConvex(b) {
    if(b.kind==='convex')return b;
    if(!b._convex)b._convex=makeConvex({vertices:obbVertices(b),solid_faces:boxFaces});
    return b._convex;
  }
  function satConvex(a,b,tol) {
    const axes=[...a.normals,...b.normals];
    for(const ea of a.edges)for(const eb of b.edges){const x=unit(cross(ea,eb));if(x)axes.push(x);}
    let depth=Infinity,axis=null;
    for(const n of axes){
      let amin=Infinity,amax=-Infinity,bmin=Infinity,bmax=-Infinity;
      for(const p of a.vertices){const d=dot(p,n);if(d<amin)amin=d;if(d>amax)amax=d;}
      for(const p of b.vertices){const d=dot(p,n);if(d<bmin)bmin=d;if(d>bmax)bmax=d;}
      const overlap=Math.min(amax-bmin,bmax-amin);
      if(overlap<=tol)return null;if(overlap<depth){depth=overlap;axis=n;}
    }
    return {penetration_m:depth,axis};
  }
  function satOverlap(a,b,tol=1e-8) {
    for(let d=0;d<3;d++)if(Math.min(a.hi[d]-b.lo[d],b.hi[d]-a.lo[d])<=tol)return null;
    return a.kind==='obb'&&b.kind==='obb'?satOBB(a,b,tol):satConvex(asConvex(a),asConvex(b),tol);
  }
  function validate(panels,instances,options={}) {
    const started=Date.now(),matrices=instances?.length?instances.map(x=>x.matrix||x):[null];
    // Disjoint instance bounding boxes cannot contain intersecting solids.
    // Validate their connected groups separately so four independent roofs do
    // not require four copies of every transformed frame in memory at once.
    if(matrices.length>1&&!options._component){
      const allBounds=bounds(panels.flatMap(p=>p.vertices)),corners=[];
      for(const x of [allBounds.lo[0],allBounds.hi[0]])for(const y of [allBounds.lo[1],allBounds.hi[1]])for(const z of [allBounds.lo[2],allBounds.hi[2]])corners.push([x,y,z]);
      const bb=matrices.map(m=>bounds(corners.map(p=>transform(p,m)))),groups=[],visited=new Set();
      for(let i=0;i<matrices.length;i++)if(!visited.has(i)){
        const group=[i];visited.add(i);
        for(let k=0;k<group.length;k++)for(let j=0;j<matrices.length;j++)if(!visited.has(j)){
          let overlap=true;for(let d=0;d<3;d++)if(bb[group[k]].hi[d]<bb[j].lo[d]||bb[j].hi[d]<bb[group[k]].lo[d]){overlap=false;break;}
          if(overlap){visited.add(j);group.push(j);}
        }
        groups.push(group);
      }
      if(groups.length>1){
        let offset=0;const result={method:'spatial_hash_15_axis_actual_solid_SAT',solid_count:0,candidate_pairs:0,sat_tests:0,intersection_count:0,intersections:[],details_truncated:false,nonconvex_uncertified_count:0,max_frame_orthogonality_cos_error:0,tolerance_m:options.tolerance??1e-8,passed:true,disjoint_instance_groups:groups};
        for(const group of groups){
          const base=offset,part=validate(panels,group.map(i=>matrices[i]),{...options,_component:true,onProgress:options.onProgress?p=>options.onProgress({...p,checked:p.checked+base,total:panels.length*matrices.length}):undefined});
          for(const key of ['solid_count','candidate_pairs','sat_tests','intersection_count','nonconvex_uncertified_count'])result[key]+=part[key];
          result.max_frame_orthogonality_cos_error=Math.max(result.max_frame_orthogonality_cos_error,part.max_frame_orthogonality_cos_error);
          result.passed=result.passed&&part.passed;
          for(const detail of part.intersections)if(result.intersections.length<(options.maxDetails??200))result.intersections.push({...detail,a:{...detail.a,instance:group[detail.a.instance]},b:{...detail.b,instance:group[detail.b.instance]}});
          offset+=part.solid_count;
        }
        result.details_truncated=result.intersection_count>result.intersections.length;result.elapsed_ms=Date.now()-started;return result;
      }
    }
    const cell=options.cellSize??1.5,tol=options.tolerance??1e-8,maxDetails=options.maxDetails??200;
    const total=panels.length*matrices.length,seen=new Int32Array(total),grid=new Map(),solids=[],intersections=[];
    let intersectionCount=0,candidatePairs=0,satTests=0,nonconvexCount=0,maxOrthogonality=0;
    for(let ii=0;ii<matrices.length;ii++)for(let pi=0;pi<panels.length;pi++){
      const panel=panels[pi],id=solids.length,m=matrices[ii];
      const b=panel.vertices.length===8&&panel.kind!=='arc_trim_solid'?makeOBB(panel,m):makeConvex(panel,m);
      b.instance=ii;b.panel=pi;b.id=id;
      if(b.kind==='obb')maxOrthogonality=Math.max(maxOrthogonality,b.orthogonality);
      else if(!b.convex)nonconvexCount++;
      // All eight corners are redundant for a box. Keep compact frames in the
      // world hash; convex conversion reconstructs corners only when required.
      if(b.kind==='obb'&&!options.retainVertices)delete b.vertices;
      const lo=b.lo.map(x=>Math.floor(x/cell)),hi=b.hi.map(x=>Math.floor(x/cell)),keys=[];
      for(let x=lo[0];x<=hi[0];x++)for(let y=lo[1];y<=hi[1];y++)for(let z=lo[2];z<=hi[2];z++){
        const key=x+','+y+','+z;keys.push(key);const bucket=grid.get(key);if(!bucket)continue;
        for(const otherId of bucket){
          if(seen[otherId]===id+1)continue;seen[otherId]=id+1;candidatePairs++;
          const a=solids[otherId];let overlap=true;
          for(let d=0;d<3;d++)if(Math.min(a.hi[d]-b.lo[d],b.hi[d]-a.lo[d])<=tol){overlap=false;break;}
          if(!overlap)continue;
          if((a.kind==='convex'&&!a.convex)||(b.kind==='convex'&&!b.convex))continue;
          satTests++;const result=satOverlap(a,b,tol);
          if(result){intersectionCount++;if(intersections.length<maxDetails)intersections.push({a:{instance:a.instance,panel:a.panel},b:{instance:ii,panel:pi},...result});}
        }
      }
      solids.push(b);
      for(const key of keys){let bucket=grid.get(key);if(!bucket){bucket=[];grid.set(key,bucket);}bucket.push(id);}
      if(options.onProgress&&((id+1)%10000===0||id+1===total))options.onProgress({checked:id+1,total,intersections:intersectionCount});
      if(options.shouldCancel?.())throw Error('Intersection check cancelled');
    }
    return {method:'spatial_hash_15_axis_actual_solid_SAT',solid_count:total,candidate_pairs:candidatePairs,sat_tests:satTests,intersection_count:intersectionCount,intersections,details_truncated:intersectionCount>intersections.length,nonconvex_uncertified_count:nonconvexCount,max_frame_orthogonality_cos_error:maxOrthogonality,tolerance_m:tol,passed:intersectionCount===0&&nonconvexCount===0,elapsed_ms:Date.now()-started};
  }
  const api={makeOBB,makeConvex,satOverlap,validate};
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
  root.V6SolidSAT=api;
})(typeof globalThis!=='undefined'?globalThis:this);
